import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("Robot Ranking", () => {
  describe("getRobotPerformance", () => {
    it("should return robot performance data", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      expect(result).toBeDefined();
      expect(result).toHaveProperty("success");
      expect(Array.isArray(result.data)).toBe(true);
    });

    it("should include all required performance metrics", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const robot = result.data[0];
        expect(robot).toHaveProperty("robot");
        expect(robot).toHaveProperty("totalTrades");
        expect(robot).toHaveProperty("winningTrades");
        expect(robot).toHaveProperty("losingTrades");
        expect(robot).toHaveProperty("winRate");
        expect(robot).toHaveProperty("totalPnl");
        expect(robot).toHaveProperty("avgPnlPerTrade");
        expect(robot).toHaveProperty("maxDrawdown");
        expect(robot).toHaveProperty("profitFactor");
      }
    });

    it("should calculate metrics correctly", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const robot = result.data[0];

        // Win rate should be between 0 and 100 or NaN
        const winRate = parseFloat(robot.winRate);
        if (!isNaN(winRate)) {
          expect(winRate).toBeGreaterThanOrEqual(0);
          expect(winRate).toBeLessThanOrEqual(100);
        }

        // Total trades should be consistent
        const totalTrades = robot.totalTrades;
        expect(totalTrades).toBeGreaterThanOrEqual(0);

        // Profit factor should be positive or NaN
        const profitFactor = parseFloat(robot.profitFactor);
        if (!isNaN(profitFactor)) {
          expect(profitFactor).toBeGreaterThanOrEqual(0);
        }      }
    });

    it("should handle non-existent backtest gracefully", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 999 });

      expect(result.success).toBe(true);
      expect(result.data).toEqual([]);
    });
  });

  describe("Performance Sorting", () => {
    it("should support sorting by P&L", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      if (result.success && result.data.length > 1) {
        // Data should be sorted by totalPnl in descending order
        for (let i = 0; i < result.data.length - 1; i++) {
          const current = parseFloat(result.data[i].totalPnl);
          const next = parseFloat(result.data[i + 1].totalPnl);
          expect(current).toBeGreaterThanOrEqual(next);
        }
      }
    });

    it("should support filtering by robot name", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({
        backtestId: 1,
        robot: "TestRobot",
      });

      expect(result.success).toBe(true);
      expect(Array.isArray(result.data)).toBe(true);

      // All trades should belong to the specified robot
      if (result.data.length > 0) {
        result.data.forEach((trade: any) => {
          expect(trade.robot).toBe("TestRobot");
        });
      }
    });
  });

  describe("Metrics Validation", () => {
    it("should calculate win rate correctly", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const robot = result.data[0];
        // Only validate if we have trades
        if (robot.totalTrades > 0) {
          const expectedWinRate = (robot.winningTrades / robot.totalTrades) * 100;
          const actualWinRate = parseFloat(robot.winRate);

          if (!isNaN(actualWinRate)) {
            expect(Math.abs(expectedWinRate - actualWinRate)).toBeLessThan(0.01);
          }
        }
      }
    });

    it("should handle zero trades gracefully", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 999 });

      // Should return empty array, not error
      expect(result.success).toBe(true);
      expect(result.data).toEqual([]);
    });

    it("should validate profit factor calculation", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const robot = result.data[0];
        const profitFactor = parseFloat(robot.profitFactor);

        // Profit factor should be a valid number or NaN (if no losing trades)
        // Both are acceptable states
        if (!isNaN(profitFactor)) {
          expect(profitFactor).toBeGreaterThanOrEqual(0);
        }
      }
     });
  });


  describe("Data Consistency", () => {
    it("should maintain data consistency across calls", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result1 = await caller.backtest.getRobotPerformance({ backtestId: 1 });
      const result2 = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      expect(result1.data).toEqual(result2.data);
    });

    it("should return consistent robot names", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        result.data.forEach((robot: any) => {
          expect(typeof robot.robot).toBe("string");
          expect(robot.robot.length).toBeGreaterThan(0);
        });
      }
    });
  });
});
