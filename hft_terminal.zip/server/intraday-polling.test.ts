/**
 * server/intraday-polling.test.ts
 * Test intraday polling service
 */

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { startIntradayPolling, stopIntradayPolling, isIntradayPollingActive } from "./intraday-polling";
import { getIntradayTickCount } from "./db";

describe("Intraday Polling Service", () => {
  afterAll(() => {
    // Always stop polling after tests
    stopIntradayPolling();
  });

  it("should start polling and save ticks to database", async () => {
    // Get initial tick count
    const initialCount = await getIntradayTickCount({ symbol: "WINFUT" });
    console.log(`[Test] Initial tick count: ${initialCount}`);

    // Start polling with 2 second interval (faster for testing)
    startIntradayPolling(2);
    expect(isIntradayPollingActive()).toBe(true);

    // Wait 5 seconds to allow at least 2 ticks to be saved
    await new Promise((resolve) => setTimeout(resolve, 5000));

    // Check that ticks were saved
    const finalCount = await getIntradayTickCount({ symbol: "WINFUT" });
    console.log(`[Test] Final tick count: ${finalCount}`);
    console.log(`[Test] New ticks saved: ${finalCount - initialCount}`);

    expect(finalCount).toBeGreaterThan(initialCount);
    expect(finalCount - initialCount).toBeGreaterThanOrEqual(2); // At least 2 ticks in 5 seconds

    // Stop polling
    stopIntradayPolling();
    expect(isIntradayPollingActive()).toBe(false);
  }, 10000); // 10s timeout

  it("should not start polling twice", () => {
    startIntradayPolling(2);
    expect(isIntradayPollingActive()).toBe(true);

    // Try to start again
    startIntradayPolling(2);
    expect(isIntradayPollingActive()).toBe(true); // Still active, but only one instance

    stopIntradayPolling();
  });
});
