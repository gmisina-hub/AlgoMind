import axios from "axios";

export interface DiscordAlert {
  title: string;
  description: string;
  color?: number; // Cor em formato decimal (ex: 0xff0000 para vermelho)
  fields?: Array<{
    name: string;
    value: string;
    inline?: boolean;
  }>;
  timestamp?: boolean;
}

const DISCORD_WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL || "";

/**
 * Enviar alerta para Discord via Webhook
 */
export async function sendDiscordAlert(alert: DiscordAlert): Promise<boolean> {
  if (!DISCORD_WEBHOOK_URL) {
    console.warn("[Discord Service] DISCORD_WEBHOOK_URL não configurada");
    return false;
  }

  try {
    const embed = {
      title: alert.title,
      description: alert.description,
      color: alert.color || 0x06b6d4, // Cyan por padrão
      fields: alert.fields || [],
      timestamp: alert.timestamp ? new Date().toISOString() : undefined,
      footer: {
        text: "HFT Terminal - Algomind Control Center",
        icon_url: "https://img.icons8.com/color/96/000000/bot.png",
      },
    };

    const payload = {
      embeds: [embed],
      username: "HFT Terminal Bot",
    };

    const response = await axios.post(DISCORD_WEBHOOK_URL, payload, {
      timeout: 5000,
      headers: {
        "Content-Type": "application/json",
      },
    });

    return response.status === 204 || response.status === 200;
  } catch (error) {
    console.error("[Discord Service] Erro ao enviar alerta:", error instanceof Error ? error.message : String(error));
    return false;
  }
}

/**
 * Alerta de Win Rate baixo
 */
export async function alertLowWinRate(robotName: string, winRate: number, threshold: number): Promise<boolean> {
  return sendDiscordAlert({
    title: "⚠️ Win Rate Baixo",
    description: `O robô **${robotName}** atingiu uma taxa de acerto abaixo do limite.`,
    color: 0xf59e0b, // Amarelo
    fields: [
      {
        name: "Robô",
        value: robotName,
        inline: true,
      },
      {
        name: "Win Rate Atual",
        value: `${winRate.toFixed(2)}%`,
        inline: true,
      },
      {
        name: "Limite",
        value: `${threshold.toFixed(2)}%`,
        inline: true,
      },
    ],
    timestamp: true,
  });
}

/**
 * Alerta de Drawdown alto
 */
export async function alertHighDrawdown(robotName: string, drawdown: number, threshold: number): Promise<boolean> {
  return sendDiscordAlert({
    title: "🔴 Drawdown Alto",
    description: `O robô **${robotName}** ultrapassou o limite de drawdown máximo.`,
    color: 0xef4444, // Vermelho
    fields: [
      {
        name: "Robô",
        value: robotName,
        inline: true,
      },
      {
        name: "Drawdown Atual",
        value: `${drawdown.toFixed(2)}%`,
        inline: true,
      },
      {
        name: "Limite",
        value: `${threshold.toFixed(2)}%`,
        inline: true,
      },
    ],
    timestamp: true,
  });
}

/**
 * Alerta de novo trade executado
 */
export async function alertNewTrade(
  robotName: string,
  asset: string,
  side: string,
  pnl: number,
  quantity: number
): Promise<boolean> {
  return sendDiscordAlert({
    title: "📊 Novo Trade Executado",
    description: `O robô **${robotName}** executou um novo trade.`,
    color: pnl >= 0 ? 0x10b981 : 0xef4444, // Verde se lucro, vermelho se prejuízo
    fields: [
      {
        name: "Robô",
        value: robotName,
        inline: true,
      },
      {
        name: "Ativo",
        value: asset,
        inline: true,
      },
      {
        name: "Lado",
        value: side.toUpperCase(),
        inline: true,
      },
      {
        name: "Quantidade",
        value: quantity.toString(),
        inline: true,
      },
      {
        name: "P&L",
        value: `R$ ${pnl.toFixed(2)}`,
        inline: true,
      },
    ],
    timestamp: true,
  });
}

/**
 * Alerta de status geral do sistema
 */
export async function alertSystemStatus(status: "online" | "offline" | "warning", message: string): Promise<boolean> {
  const colors = {
    online: 0x10b981, // Verde
    offline: 0xef4444, // Vermelho
    warning: 0xf59e0b, // Amarelo
  };

  return sendDiscordAlert({
    title: `🔔 Status do Sistema - ${status.toUpperCase()}`,
    description: message,
    color: colors[status],
    timestamp: true,
  });
}
