/**
 * server/ai-history.test.ts
 * Testes para histórico de recomendações AI
 */

import { describe, it, expect, beforeAll } from "vitest";
import { saveAIRecommendation, getLatestRecommendations, calculateAIKPIs } from "./db-ai-history";
import { getDb } from "./db";
import { aiRecommendationsHistory } from "../drizzle/schema";

describe("AI Recommendations History", () => {
  beforeAll(async () => {
    // Limpar tabela antes dos testes
    const db = await getDb();
    if (db) {
      await db.delete(aiRecommendationsHistory);
    }
  });

  it("deve salvar recomendação AI no banco", async () => {
    await saveAIRecommendation({
      recommendation: "LONG",
      confidence: 75,
      entry: 127450,
      stopLoss: 127350,
      takeProfit: 127550,
      context: "RSI oversold + preço acima do VWAP + macro bullish",
      currentPrice: 127450,
      rsi: 35,
      vwap: 127400,
      volumeProfilePoc: 127420,
      macroCascadeSignal: "BULLISH",
      darkPoolDetected: false,
    });

    const recommendations = await getLatestRecommendations(1);
    expect(recommendations).toHaveLength(1);
    expect(recommendations[0].recommendation).toBe("LONG");
    expect(recommendations[0].confidence).toBe(75);
  });

  it("deve buscar últimas N recomendações ordenadas por timestamp", async () => {
    // Salvar 3 recomendações
    await saveAIRecommendation({
      recommendation: "SHORT",
      confidence: 80,
      entry: 127500,
      stopLoss: 127600,
      takeProfit: 127400,
      context: "RSI overbought + resistência R2",
      currentPrice: 127500,
      rsi: 75,
      vwap: 127450,
      volumeProfilePoc: 127480,
      macroCascadeSignal: "BEARISH",
      darkPoolDetected: true,
    });

    await saveAIRecommendation({
      recommendation: "NEUTRO",
      confidence: 50,
      entry: 127450,
      stopLoss: 127350,
      takeProfit: 127550,
      context: "Sinais conflitantes",
      currentPrice: 127450,
      rsi: 50,
      vwap: 127450,
      volumeProfilePoc: 127450,
      macroCascadeSignal: "NEUTRAL",
      darkPoolDetected: false,
    });

    const recommendations = await getLatestRecommendations(3);
    expect(recommendations.length).toBeGreaterThanOrEqual(3);
    
    // Verificar que está ordenado por timestamp (mais recente primeiro)
    const timestamps = recommendations.map(r => new Date(r.timestamp).getTime());
    for (let i = 0; i < timestamps.length - 1; i++) {
      expect(timestamps[i]).toBeGreaterThanOrEqual(timestamps[i + 1]);
    }
  });

  it("deve calcular KPIs corretamente", async () => {
    const kpis = await calculateAIKPIs();
    
    expect(kpis.totalRecommendations).toBeGreaterThanOrEqual(3);
    expect(kpis.longCount).toBeGreaterThanOrEqual(1);
    expect(kpis.shortCount).toBeGreaterThanOrEqual(1);
    expect(kpis.neutralCount).toBeGreaterThanOrEqual(1);
    expect(kpis.avgConfidence).toBeGreaterThan(0);
    expect(kpis.avgConfidence).toBeLessThanOrEqual(100);
    
    // Validar que KPIs de backtest estão presentes
    expect(kpis).toHaveProperty("winRate");
    expect(kpis).toHaveProperty("profitFactor");
    expect(kpis).toHaveProperty("sharpeRatio");
    expect(kpis).toHaveProperty("maxDrawdown");
    expect(kpis).toHaveProperty("totalPnL");
    
    // Validar ranges
    expect(kpis.winRate).toBeGreaterThanOrEqual(0);
    expect(kpis.winRate).toBeLessThanOrEqual(100);
    expect(kpis.profitFactor).toBeGreaterThanOrEqual(0);
    expect(kpis.maxDrawdown).toBeGreaterThanOrEqual(0);
  });

  it("deve retornar array vazio quando não há recomendações", async () => {
    // Limpar tabela
    const db = await getDb();
    if (db) {
      await db.delete(aiRecommendationsHistory);
    }

    const recommendations = await getLatestRecommendations(10);
    expect(recommendations).toHaveLength(0);
  });

  it("deve retornar KPIs zerados quando não há recomendações", async () => {
    const kpis = await calculateAIKPIs();
    
    expect(kpis.totalRecommendations).toBe(0);
    expect(kpis.longCount).toBe(0);
    expect(kpis.shortCount).toBe(0);
    expect(kpis.neutralCount).toBe(0);
    expect(kpis.avgConfidence).toBe(0);
    expect(kpis.winRate).toBe(0);
    expect(kpis.profitFactor).toBe(0);
    expect(kpis.sharpeRatio).toBe(0);
    expect(kpis.maxDrawdown).toBe(0);
    expect(kpis.totalPnL).toBe(0);
  });
});
