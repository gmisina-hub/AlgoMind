/**
 * server/technical-indicators.ts
 * Technical analysis indicators: Fair Value, Pivot Points, Fibonacci
 */

export interface FairValue {
  fairValue: number; // Valor justo calculado
  premium: number; // Prêmio/Desconto em pontos (WINFUT - Valor Justo)
  spreadPct: number; // Spread percentual
}

export interface PivotPoints {
  pp: number; // Pivot Point
  r1: number; // Resistência 1
  r2: number; // Resistência 2
  s1: number; // Suporte 1
  s2: number; // Suporte 2
}

export interface FibonacciLevels {
  high: number; // Máxima do período
  low: number; // Mínima do período
  fib236: number; // 23.6%
  fib382: number; // 38.2%
  fib500: number; // 50%
  fib618: number; // 61.8%
  fib786: number; // 78.6%
}

/**
 * Calculate Fair Value of Index Future
 * Formula: Fair Value = Spot Index × (1 + DI Rate × Days to Expiry / 252)
 * 
 * @param spotIndex - Índice à vista (IBOV spot)
 * @param futurePrice - Preço do futuro (WINFUT)
 * @param diRate - Taxa DI anualizada (ex: 0.1475 para 14.75%)
 * @param daysToExpiry - Dias corridos até vencimento
 * @returns Fair value metrics
 */
export function calculateFairValue(
  spotIndex: number,
  futurePrice: number,
  diRate: number = 0.1475, // Default: 14.75% ao ano
  daysToExpiry: number = 30 // Default: 30 dias
): FairValue {
  // Fair Value = Spot × (1 + Taxa × Dias / 252)
  const fairValue = spotIndex * (1 + (diRate * daysToExpiry) / 252);

  // Premium/Discount = Future - Fair Value
  const premium = futurePrice - fairValue;

  // Spread % = (Future - Fair Value) / Fair Value × 100
  const spreadPct = (premium / fairValue) * 100;

  return {
    fairValue,
    premium,
    spreadPct,
  };
}

/**
 * Calculate Pivot Points (Classic)
 * PP = (High + Low + Close) / 3
 * R1 = 2×PP - Low
 * R2 = PP + (High - Low)
 * S1 = 2×PP - High
 * S2 = PP - (High - Low)
 * 
 * @param high - Máxima do período anterior
 * @param low - Mínima do período anterior
 * @param close - Fechamento do período anterior
 * @returns Pivot points
 */
export function calculatePivotPoints(
  high: number,
  low: number,
  close: number
): PivotPoints {
  const pp = (high + low + close) / 3;
  const r1 = 2 * pp - low;
  const r2 = pp + (high - low);
  const s1 = 2 * pp - high;
  const s2 = pp - (high - low);

  return { pp, r1, r2, s1, s2 };
}

/**
 * Calculate Fibonacci Retracement Levels
 * Based on swing high and swing low
 * 
 * @param high - Máxima do swing
 * @param low - Mínima do swing
 * @returns Fibonacci levels
 */
export function calculateFibonacci(high: number, low: number): FibonacciLevels {
  const range = high - low;

  return {
    high,
    low,
    fib236: high - range * 0.236,
    fib382: high - range * 0.382,
    fib500: high - range * 0.5,
    fib618: high - range * 0.618,
    fib786: high - range * 0.786,
  };
}

/**
 * Calculate all technical indicators at once
 */
export function calculateTechnicalIndicators(data: {
  spotIndex: number;
  futurePrice: number;
  high: number;
  low: number;
  close: number;
  diRate?: number;
  daysToExpiry?: number;
}) {
  const fairValue = calculateFairValue(
    data.spotIndex,
    data.futurePrice,
    data.diRate,
    data.daysToExpiry
  );

  const pivotPoints = calculatePivotPoints(data.high, data.low, data.close);

  const fibonacci = calculateFibonacci(data.high, data.low);

  return {
    fairValue,
    pivotPoints,
    fibonacci,
  };
}

/**
 * Linear Regression with Confidence Bands
 */

export interface LinearRegressionResult {
  slope: number; // Inclinação da reta
  intercept: number; // Intercepto
  projections: number[]; // Valores projetados
  upperBand: number[]; // Banda superior (95%)
  lowerBand: number[]; // Banda inferior (95%)
  isBullish: boolean; // true se slope > 0
}

/**
 * Calculate Linear Regression with 95% confidence bands
 * 
 * @param prices - Array of historical prices
 * @param projectSteps - Number of future steps to project
 * @returns Linear regression with confidence bands
 */
export function calculateLinearRegression(
  prices: number[],
  projectSteps: number = 10
): LinearRegressionResult {
  const n = prices.length;
  
  // Calculate means
  const xMean = (n - 1) / 2;
  const yMean = prices.reduce((sum, p) => sum + p, 0) / n;
  
  // Calculate slope and intercept
  let numerator = 0;
  let denominator = 0;
  
  for (let i = 0; i < n; i++) {
    numerator += (i - xMean) * (prices[i] - yMean);
    denominator += Math.pow(i - xMean, 2);
  }
  
  const slope = numerator / denominator;
  const intercept = yMean - slope * xMean;
  
  // Calculate standard error
  let sumSquaredResiduals = 0;
  for (let i = 0; i < n; i++) {
    const predicted = slope * i + intercept;
    sumSquaredResiduals += Math.pow(prices[i] - predicted, 2);
  }
  
  const standardError = Math.sqrt(sumSquaredResiduals / (n - 2));
  
  // Z-score for 95% confidence interval
  const zScore = 1.96;
  
  // Generate projections
  const projections: number[] = [];
  const upperBand: number[] = [];
  const lowerBand: number[] = [];
  
  for (let i = 0; i < projectSteps; i++) {
    const x = n + i;
    const y = slope * x + intercept;
    const margin = zScore * standardError * Math.sqrt(1 + 1 / n + Math.pow(x - xMean, 2) / denominator);
    
    projections.push(y);
    upperBand.push(y + margin);
    lowerBand.push(y - margin);
  }
  
  return {
    slope,
    intercept,
    projections,
    upperBand,
    lowerBand,
    isBullish: slope > 0,
  };
}
