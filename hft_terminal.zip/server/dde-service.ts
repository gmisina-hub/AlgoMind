import axios from "axios";

export interface DDEPrice {
  asset: string;
  last: number;
  change: number;
  changePercent: number;
  open: number;
  high: number;
  low: number;
  volume: number;
  vwap: number;
  rsi: number;
  close: number;
  timestamp: number;
}

export interface DDEData {
  [key: string]: DDEPrice;
}

const DDE_API_URL = process.env.DDE_API_URL || "http://127.0.0.1:5000";
const CACHE_DURATION = 3000; // 3 segundos

let cachedData: DDEData = {};
let lastFetchTime = 0;

/**
 * Buscar dados de preços do DDE com cache
 */
export async function fetchDDEData(): Promise<DDEData> {
  const now = Date.now();

  // Retornar cache se ainda válido
  if (now - lastFetchTime < CACHE_DURATION && Object.keys(cachedData).length > 0) {
    return cachedData;
  }

  try {
    const response = await axios.get(`${DDE_API_URL}/prices`, {
      timeout: 5000,
    });

    if (response.data && typeof response.data === "object") {
      cachedData = response.data;
      lastFetchTime = now;
      return cachedData;
    }

    return {};
  } catch (error) {
    console.error("[DDE Service] Erro ao buscar dados:", error instanceof Error ? error.message : String(error));
    // Retornar cache mesmo que expirado em caso de erro
    return cachedData;
  }
}

/**
 * Buscar dados de um ativo específico
 */
export async function fetchAssetPrice(asset: string): Promise<DDEPrice | null> {
  try {
    const data = await fetchDDEData();
    return data[asset] || null;
  } catch (error) {
    console.error(`[DDE Service] Erro ao buscar ${asset}:`, error);
    return null;
  }
}

/**
 * Validar conexão com DDE
 */
export async function validateDDEConnection(): Promise<boolean> {
  try {
    const response = await axios.get(`${DDE_API_URL}/health`, {
      timeout: 3000,
    });
    return response.status === 200;
  } catch (error) {
    console.error("[DDE Service] Conexão com DDE falhou:", error instanceof Error ? error.message : String(error));
    return false;
  }
}

/**
 * Obter lista de ativos disponíveis
 */
export async function getAvailableAssets(): Promise<string[]> {
  try {
    const data = await fetchDDEData();
    return Object.keys(data);
  } catch (error) {
    console.error("[DDE Service] Erro ao obter ativos:", error);
    return [];
  }
}
