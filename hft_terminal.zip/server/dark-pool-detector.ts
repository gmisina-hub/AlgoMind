/**
 * Dark Pool Detector Service
 * 
 * Detecta atividade institucional (dark pool) via inferência de volume spikes.
 * 
 * Algoritmo:
 * 1. Calcula média móvel de volume (últimos 30 ticks)
 * 2. Detecta spikes >200% acima da média
 * 3. Classifica direção (BUY/SELL) baseado em preço (acima/abaixo do VWAP)
 * 4. Calcula confiança baseado na magnitude do spike
 * 
 * Nota: Não é detecção real de dark pool (dados não disponíveis publicamente),
 * mas inferência estatística baseada em padrões de volume institucional.
 */

interface DarkPoolDetection {
  detected: boolean;
  direction: "BUY" | "SELL" | "NEUTRAL";
  confidence: number; // 0-100%
  volumeSpike: number; // Múltiplo da média (ex: 2.5x)
  timestamp: number;
  price: number;
  volume: number;
  avgVolume: number;
}

class DarkPoolDetectorService {
  private volumeHistory: Array<{ volume: number; price: number; timestamp: number }> = [];
  private maxHistorySize = 100; // Últimos 100 ticks
  private spikeThreshold = 2.0; // 200% acima da média

  /**
   * Adiciona novo tick ao histórico de volume
   */
  addTick(volume: number, price: number): void {
    this.volumeHistory.push({
      volume,
      price,
      timestamp: Date.now(),
    });

    // Manter apenas os últimos maxHistorySize ticks
    if (this.volumeHistory.length > this.maxHistorySize) {
      this.volumeHistory.shift();
    }
  }

  /**
   * Calcula média móvel de volume (últimos N ticks)
   */
  private calculateAverageVolume(windowSize: number = 30): number {
    if (this.volumeHistory.length === 0) return 0;

    const recentTicks = this.volumeHistory.slice(-windowSize);
    const totalVolume = recentTicks.reduce((sum, tick) => sum + tick.volume, 0);
    return totalVolume / recentTicks.length;
  }

  /**
   * Detecta dark pool activity baseado em volume spike
   */
  detectDarkPool(currentVolume: number, currentPrice: number, vwap: number): DarkPoolDetection {
    // Adicionar tick atual ao histórico
    this.addTick(currentVolume, currentPrice);

    // Calcular média móvel de volume
    const avgVolume = this.calculateAverageVolume(30);

    // Calcular spike ratio
    const volumeSpike = avgVolume > 0 ? currentVolume / avgVolume : 1;

    // Detectar spike
    const detected = volumeSpike >= this.spikeThreshold;

    // Classificar direção (BUY se preço > VWAP, SELL se preço < VWAP)
    let direction: "BUY" | "SELL" | "NEUTRAL" = "NEUTRAL";
    if (detected) {
      if (currentPrice > vwap) {
        direction = "BUY"; // Institutional buying (preço acima do VWAP)
      } else if (currentPrice < vwap) {
        direction = "SELL"; // Institutional selling (preço abaixo do VWAP)
      }
    }

    // Calcular confiança (quanto maior o spike, maior a confiança)
    // Spike de 2x = 50% confiança, 3x = 75%, 4x = 87.5%, etc
    const confidence = detected ? Math.min(100, (1 - 1 / volumeSpike) * 100) : 0;

    return {
      detected,
      direction,
      confidence: Math.round(confidence),
      volumeSpike: Math.round(volumeSpike * 100) / 100, // 2 casas decimais
      timestamp: Date.now(),
      price: currentPrice,
      volume: currentVolume,
      avgVolume: Math.round(avgVolume),
    };
  }

  /**
   * Retorna estatísticas do histórico de volume
   */
  getVolumeStats() {
    if (this.volumeHistory.length === 0) {
      return {
        tickCount: 0,
        avgVolume: 0,
        maxVolume: 0,
        minVolume: 0,
      };
    }

    const volumes = this.volumeHistory.map(t => t.volume);
    const avgVolume = volumes.reduce((sum, v) => sum + v, 0) / volumes.length;
    const maxVolume = Math.max(...volumes);
    const minVolume = Math.min(...volumes);

    return {
      tickCount: this.volumeHistory.length,
      avgVolume: Math.round(avgVolume),
      maxVolume,
      minVolume,
    };
  }

  /**
   * Limpa histórico (útil para testes)
   */
  clearHistory(): void {
    this.volumeHistory = [];
  }
}

// Singleton instance
export const darkPoolDetectorService = new DarkPoolDetectorService();
