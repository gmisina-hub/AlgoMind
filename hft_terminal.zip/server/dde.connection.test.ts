import { describe, it, expect } from "vitest";
import { ENV } from "./_core/env";

describe("DDE Connection Test", () => {
  it("should connect to DDE.py via ngrok and fetch WINFUT data", async () => {
    const ddeUrl = ENV.ddeApiUrl;
    const endpoint = `${ddeUrl}/prices`;

    console.log(`[DDE Test] Connecting to: ${endpoint}`);

    const response = await fetch(endpoint, {
      headers: {
        "ngrok-skip-browser-warning": "true", // Skip ngrok browser warning
      },
    });

    expect(response.ok).toBe(true);

    const data = await response.json();
    console.log("[DDE Test] Response:", JSON.stringify(data, null, 2));

    // Validate structure (real DDE format)
    expect(data).toHaveProperty("marketSnapshot");
    expect(data.marketSnapshot).toHaveProperty("last");
    expect(data.marketSnapshot).toHaveProperty("open");
    expect(data.marketSnapshot).toHaveProperty("high");
    expect(data.marketSnapshot).toHaveProperty("low");
    expect(data.marketSnapshot).toHaveProperty("volume");
    expect(data.marketSnapshot).toHaveProperty("vwap");
    expect(data.marketSnapshot).toHaveProperty("vwapMonthly");
    expect(data.marketSnapshot).toHaveProperty("rsi");
    expect(data.marketSnapshot).toHaveProperty("accumBalance");
    expect(data.marketSnapshot).toHaveProperty("trueRange");
    expect(data.marketSnapshot).toHaveProperty("timestamp");

    // Validate types
    expect(typeof data.marketSnapshot.last).toBe("number");
    expect(typeof data.marketSnapshot.volume).toBe("number");
    expect(typeof data.marketSnapshot.rsi).toBe("number");
    expect(typeof data.marketSnapshot.accumBalance).toBe("number");

    console.log("[DDE Test] ✅ Connection successful!");
  }, 10000); // 10s timeout
});
