/**
 * Volume Profile Service
 * 
 * Mantém buffer de ticks em memória (rolling window) e calcula:
 * - POC (Point of Control): Preço com maior volume negociado
 * - HVN (High Volume Nodes): Zonas de alta concentração de volume
 * - LVN (Low Volume Nodes): Zonas de baixa concentração de volume
 * 
 * Não grava ticks no banco (apenas em RAM)
 */

interface Tick {
  price: number;
  volume: number;
  timestamp: number;
  buyVolume?: number;
  sellVolume?: number;
}

interface VolumeNode {
  price: number;
  volume: number;
  percentage: number; // % do volume total
}

interface VolumeProfile {
  poc: number; // Point of Control (preço com maior volume)
  pocVolume: number;
  hvns: VolumeNode[]; // High Volume Nodes (top 20% de volume)
  lvns: VolumeNode[]; // Low Volume Nodes (bottom 20% de volume)
  totalVolume: number;
  priceRange: {
    min: number;
    max: number;
  };
  tickCount: number;
}

class VolumeProfileService {
  private tickBuffer: Tick[] = [];
  private maxBufferSize = 5000; // Últimos 5.000 ticks (rolling window)
  private priceStep = 5; // Agregar preços a cada 5 pontos

  /**
   * Adiciona novo tick ao buffer
   */
  addTick(tick: Tick): void {
    this.tickBuffer.push(tick);

    // Manter apenas os últimos maxBufferSize ticks (rolling window)
    if (this.tickBuffer.length > this.maxBufferSize) {
      this.tickBuffer.shift(); // Remove o mais antigo
    }
  }

  /**
   * Calcula Volume Profile a partir dos ticks em memória
   */
  calculateVolumeProfile(): VolumeProfile | null {
    if (this.tickBuffer.length === 0) {
      return null;
    }

    // 1. Encontrar range de preços
    const prices = this.tickBuffer.map(t => t.price);
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);

    // 2. Criar bins de preço (agregar a cada priceStep pontos)
    const priceBins = new Map<number, number>(); // price -> volume

    for (const tick of this.tickBuffer) {
      // Arredondar preço para o bin mais próximo
      const binPrice = Math.round(tick.price / this.priceStep) * this.priceStep;
      const currentVolume = priceBins.get(binPrice) || 0;
      priceBins.set(binPrice, currentVolume + tick.volume);
    }

    // 3. Converter para array e ordenar por volume
    const volumeNodes: VolumeNode[] = [];
    let totalVolume = 0;

    priceBins.forEach((volume, price) => {
      totalVolume += volume;
      volumeNodes.push({ price, volume, percentage: 0 }); // percentage será calculado depois
    });

    // Calcular percentuais e validar
    for (const node of volumeNodes) {
      const percentage = (node.volume / totalVolume) * 100;
      // Validar percentage (deve ser 0-100)
      node.percentage = isFinite(percentage) && percentage >= 0 && percentage <= 100 
        ? percentage 
        : 0;
      
      // Validar volume (limitar a valores razoáveis)
      if (!isFinite(node.volume) || node.volume < 0) {
        console.warn('[VolumeProfile] Invalid volume:', node.volume, 'for price:', node.price);
        node.volume = 0;
      }
    }

    // Ordenar por volume (decrescente)
    volumeNodes.sort((a, b) => b.volume - a.volume);

    // 4. Identificar POC (maior volume)
    const poc = volumeNodes[0];

    // 5. Identificar HVNs (top 20% de volume)
    const hvnThreshold = totalVolume * 0.05; // Nós com >5% do volume total
    const hvns = volumeNodes.filter(node => node.volume >= hvnThreshold);

    // 6. Identificar LVNs (bottom 20% de volume)
    const lvnThreshold = totalVolume * 0.01; // Nós com <1% do volume total
    const lvns = volumeNodes.filter(node => node.volume <= lvnThreshold);

    // Validar POC
    if (!poc || !isFinite(poc.price) || !isFinite(poc.volume)) {
      console.error('[VolumeProfile] Invalid POC data');
      return null;
    }

    return {
      poc: poc.price,
      pocVolume: poc.volume,
      hvns: hvns.slice(0, 10).filter(node => isFinite(node.price) && isFinite(node.volume)), // Top 10 HVNs válidos
      lvns: lvns.slice(0, 10).filter(node => isFinite(node.price) && isFinite(node.volume)), // Top 10 LVNs válidos
      totalVolume: isFinite(totalVolume) ? totalVolume : 0,
      priceRange: {
        min: isFinite(minPrice) ? minPrice : 0,
        max: isFinite(maxPrice) ? maxPrice : 0,
      },
      tickCount: this.tickBuffer.length,
    };
  }

  /**
   * Retorna distância do preço atual ao POC
   */
  getDistanceToPOC(currentPrice: number): number | null {
    const profile = this.calculateVolumeProfile();
    if (!profile) return null;

    return currentPrice - profile.poc;
  }

  /**
   * Verifica se preço está próximo de um HVN (zona de suporte/resistência)
   */
  isNearHVN(currentPrice: number, tolerance: number = 50): VolumeNode | null {
    const profile = this.calculateVolumeProfile();
    if (!profile) return null;

    for (const hvn of profile.hvns) {
      if (Math.abs(currentPrice - hvn.price) <= tolerance) {
        return hvn;
      }
    }

    return null;
  }

  /**
   * Verifica se preço está em LVN (zona de baixa liquidez = risco)
   */
  isInLVN(currentPrice: number, tolerance: number = 50): boolean {
    const profile = this.calculateVolumeProfile();
    if (!profile) return false;

    for (const lvn of profile.lvns) {
      if (Math.abs(currentPrice - lvn.price) <= tolerance) {
        return true;
      }
    }

    return false;
  }

  /**
   * Limpa buffer (útil para testes ou reset)
   */
  clearBuffer(): void {
    this.tickBuffer = [];
  }

  /**
   * Retorna estatísticas do buffer
   */
  getBufferStats() {
    return {
      tickCount: this.tickBuffer.length,
      maxSize: this.maxBufferSize,
      utilizationPercent: (this.tickBuffer.length / this.maxBufferSize) * 100,
      oldestTick: this.tickBuffer[0]?.timestamp || null,
      newestTick: this.tickBuffer[this.tickBuffer.length - 1]?.timestamp || null,
    };
  }
}

// Singleton instance
export const volumeProfileService = new VolumeProfileService();
