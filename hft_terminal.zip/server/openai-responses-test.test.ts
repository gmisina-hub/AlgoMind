/**
 * server/openai-responses-test.test.ts
 * Teste usando responses.create() sugerido pelo ChatGPT
 */

import { describe, it, expect } from "vitest";
import OpenAI from "openai";

describe("OpenAI Responses API Test", () => {
  it("deve testar responses.create() sugerido pelo ChatGPT", async () => {
    const apiKey = process.env.OPENAI_API_KEY;
    
    expect(apiKey).toBeDefined();
    
    const client = new OpenAI({
      apiKey: apiKey,
    });
    
    // Testar se responses.create() existe
    console.log("[Test] Verificando se client.responses existe...");
    console.log("[Test] client.responses:", (client as any).responses);
    
    // Tentar chamar responses.create()
    try {
      const response = await (client as any).responses.create({
        model: "gpt-4o-mini",
        input: "Diga apenas: API OK"
      });
      
      console.log("[OpenAI Responses] Sucesso!");
      console.log("[OpenAI Responses] Resposta completa:", JSON.stringify(response, null, 2));
      
      // Verificar se a resposta tem algum conteúdo
      expect(response).toBeTruthy();
    } catch (error: any) {
      console.error("[OpenAI Responses] Erro:", error.message);
      console.error("[OpenAI Responses] Stack:", error.stack);
      throw error;
    }
  });
});
