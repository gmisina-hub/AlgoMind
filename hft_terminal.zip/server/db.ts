import { eq, and, gte, lte, asc, lt } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { sql } from "drizzle-orm";
import { InsertUser, users, intradayTicks, InsertIntradayTick } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.

/**
 * Insert a new intraday tick into the database
 */
export async function insertIntradayTick(tick: InsertIntradayTick): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot insert intraday tick: database not available");
    return;
  }

  try {
    await db.insert(intradayTicks).values(tick);
  } catch (error) {
    console.error("[Database] Failed to insert intraday tick:", error);
    throw error;
  }
}

/**
 * Get intraday ticks for a symbol on a specific date
 */
export async function getIntradayTicks(symbol: string, date: Date) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get intraday ticks: database not available");
    return [];
  }

  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);

  try {
    const result = await db
      .select()
      .from(intradayTicks)
      .where(
        and(
          eq(intradayTicks.symbol, symbol),
          gte(intradayTicks.timestamp, startOfDay),
          lte(intradayTicks.timestamp, endOfDay)
        )
      )
      .orderBy(asc(intradayTicks.timestamp));

    return result;
  } catch (error) {
    console.error("[Database] Failed to get intraday ticks:", error);
    return [];
  }
}

/**
 * Get count of intraday ticks for a symbol
 */
export async function getIntradayTickCount(params: { symbol: string }): Promise<number> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get intraday tick count: database not available");
    return 0;
  }

  try {
    const result = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(intradayTicks)
      .where(eq(intradayTicks.symbol, params.symbol));

    return result[0]?.count || 0;
  } catch (error) {
    console.error("[Database] Failed to get intraday tick count:", error);
    return 0;
  }
}

/**
 * Delete old intraday ticks (older than specified days)
 */
export async function deleteOldIntradayTicks(daysToKeep: number = 7): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete old intraday ticks: database not available");
    return;
  }

  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

  try {
    await db.delete(intradayTicks).where(lt(intradayTicks.timestamp, cutoffDate));
    console.log(`[Database] Deleted intraday ticks older than ${daysToKeep} days`);
  } catch (error) {
    console.error("[Database] Failed to delete old intraday ticks:", error);
    throw error;
  }
}
