import { eq, desc } from "drizzle-orm";
import { marketSnapshots, backtests, trades, robotPerformance } from "../drizzle/schema";
import { getDb } from "./db";

/**
 * Get latest market snapshot for a symbol
 */
export async function getLatestMarketSnapshot(symbol: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(marketSnapshots)
    .where(eq(marketSnapshots.symbol, symbol))
    .orderBy(desc(marketSnapshots.timestamp))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

/**
 * Create backtest and return ID
 */
export async function createBacktestWithId(data: {
  userId: number;
  fileName: string;
  fileKey: string;
}) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(backtests).values(data);
  // Get the inserted ID
  const inserted = await db.select().from(backtests).where(eq(backtests.fileKey, data.fileKey)).limit(1);
  return inserted[0]?.id || null;
}

/**
 * Save market snapshot
 */
export async function saveMarketSnapshot(data: {
  symbol: string;
  last?: number | string;
  open?: number | string;
  high?: number | string;
  low?: number | string;
  close?: number | string;
  varPts?: number | string;
  varPct?: number | string;
  volume?: number | string;
  vwap?: number | string;
}) {
  const db = await getDb();
  if (!db) return null;

  return await db.insert(marketSnapshots).values({
    symbol: data.symbol,
    last: data.last ? Number(data.last) : undefined,
    open: data.open ? Number(data.open) : undefined,
    high: data.high ? Number(data.high) : undefined,
    low: data.low ? Number(data.low) : undefined,
    close: data.close ? Number(data.close) : undefined,
    varPts: data.varPts ? Number(data.varPts) : undefined,
    varPct: data.varPct ? Number(data.varPct) : undefined,
    volume: data.volume ? Number(data.volume) : undefined,
    vwap: data.vwap ? Number(data.vwap) : undefined,
    timestamp: new Date(),
  });
}

/**
 * Get backtests for user
 */
export async function getUserBacktests(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(backtests)
    .where(eq(backtests.userId, userId))
    .orderBy(desc(backtests.createdAt));
}

/**
 * Get backtest by ID
 */
export async function getBacktestById(backtestId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(backtests)
    .where(eq(backtests.id, backtestId))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

/**
 * Update backtest status
 */
export async function updateBacktestStatus(
  backtestId: number,
  status: string,
  metadata?: Record<string, any>
) {
  const db = await getDb();
  if (!db) return null;

  return await db
    .update(backtests)
    .set({
      status,
      metadata: metadata ? JSON.stringify(metadata) : undefined,
    })
    .where(eq(backtests.id, backtestId));
}

/**
 * Get robot performance for backtest
 */
export async function getRobotPerformance(backtestId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(robotPerformance)
    .where(eq(robotPerformance.backtestId, backtestId));
}

/**
 * Save robot performance
 */
export async function saveRobotPerformance(data: {
  backtestId: number;
  robot: string;
  account: string;
  totalTrades: number;
  winRate: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  maxDrawdown: number;
  totalPnL: number;
  totalPnLPct: number;
}) {
  const db = await getDb();
  if (!db) return null;

  return await db.insert(robotPerformance).values(data);
}

/**
 * Get trades for backtest
 */
export async function getTrades(backtestId: number, robot?: string) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(trades).where(eq(trades.backtestId, backtestId));

  if (robot) {
    query = query.where(eq(trades.robot, robot));
  }

  return await query;
}

/**
 * Get backtest robot performance (alias)
 */
export async function getBacktestRobotPerformance(backtestId: number) {
  return getRobotPerformance(backtestId);
}

/**
 * Get backtest trades (alias)
 */
export async function getBacktestTrades(backtestId: number, robot?: string) {
  return getTrades(backtestId, robot);
}

/**
 * Create backtest (alias)
 */
export async function createBacktest(data: {
  userId: number;
  fileName: string;
  fileKey: string;
}) {
  return createBacktestWithId(data);
}

/**
 * Save trades
 */
export async function saveTrades(tradesList: Array<{
  backtestId: number;
  robot: string;
  entryTime: Date;
  exitTime?: Date;
  entryPrice: string | number;
  exitPrice?: string | number;
  quantity: number;
  pnl?: string | number;
  pnlPct?: string | number;
  direction: "long" | "short";
  status: "open" | "closed";
}>) {
  const db = await getDb();
  if (!db) {
    console.error('[saveTrades] Database not available');
    return null;
  }

  console.log('[saveTrades] Processing', tradesList.length, 'trades');
  
  const normalizedTrades = tradesList.map(t => ({
    ...t,
    entryPrice: String(t.entryPrice),
    exitPrice: t.exitPrice ? String(t.exitPrice) : undefined,
    pnl: t.pnl ? String(t.pnl) : undefined,
    pnlPct: t.pnlPct ? String(t.pnlPct) : undefined,
  }));

  console.log('[saveTrades] First normalized trade:', normalizedTrades[0]);
  
  try {
    const result = await db.insert(trades).values(normalizedTrades);
    console.log('[saveTrades] Insert successful, result:', result);
    return result;
  } catch (error) {
    console.error('[saveTrades] Error inserting trades:', error);
    if (error instanceof Error) {
      console.error('[saveTrades] Error message:', error.message);
      console.error('[saveTrades] Error stack:', error.stack);
    }
    throw error;
  }
}
