/**
 * B3 Service - Taxa DI e Vencimentos de Contratos Futuros
 * 
 * Como a B3 não tem API pública gratuita, usamos:
 * 1. Taxa DI: Estimativa baseada em SELIC (Banco Central) ou proxy via Yahoo Finance
 * 2. Vencimento WINFUT: Cálculo automático baseado no padrão da B3
 */

/**
 * Calculate next WINFUT contract expiry date
 * 
 * WINFUT vence na primeira quarta-feira do mês de vencimento.
 * Contratos disponíveis: meses pares (fev, abr, jun, ago, out, dez)
 * 
 * @returns Object with expiry date and days until expiry
 */
export function calculateWINFUTExpiry(): { expiryDate: Date; daysToExpiry: number } {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth(); // 0-indexed (0 = Jan, 11 = Dec)
  
  // Meses de vencimento (pares): 1 (fev), 3 (abr), 5 (jun), 7 (ago), 9 (out), 11 (dez)
  const expiryMonths = [1, 3, 5, 7, 9, 11];
  
  // Find next expiry month
  let targetMonth = expiryMonths.find(m => m > currentMonth);
  let targetYear = currentYear;
  
  // Se não encontrou no ano atual, pega o primeiro do próximo ano
  if (!targetMonth) {
    targetMonth = expiryMonths[0];
    targetYear = currentYear + 1;
  }
  
  // Encontrar a primeira quarta-feira do mês
  const firstDayOfMonth = new Date(targetYear, targetMonth, 1);
  const firstDayWeekday = firstDayOfMonth.getDay(); // 0 = Sunday, 3 = Wednesday
  
  // Calcular dias até a primeira quarta-feira
  let daysUntilWednesday = (3 - firstDayWeekday + 7) % 7;
  if (daysUntilWednesday === 0 && firstDayWeekday !== 3) {
    daysUntilWednesday = 7;
  }
  
  const expiryDate = new Date(targetYear, targetMonth, 1 + daysUntilWednesday);
  
  // Calculate days to expiry
  const msPerDay = 1000 * 60 * 60 * 24;
  const daysToExpiry = Math.ceil((expiryDate.getTime() - now.getTime()) / msPerDay);
  
  return {
    expiryDate,
    daysToExpiry: Math.max(0, daysToExpiry),
  };
}

/**
 * Get current DI rate (Taxa DI)
 * 
 * Opções:
 * 1. Usar taxa SELIC do Banco Central (mais preciso, mas requer scraping ou API específica)
 * 2. Usar proxy via Yahoo Finance (^IRX - US Treasury Bill 13 Week)
 * 3. Usar valor fixo atualizado manualmente
 * 
 * Por enquanto, retornamos estimativa baseada em SELIC recente.
 * TODO: Integrar com API do Banco Central ou fonte confiável.
 * 
 * @returns DI rate as decimal (e.g., 0.1475 for 14.75%)
 */
export async function getDIRate(): Promise<number> {
  // SELIC atual (dezembro 2024): ~14.75% a.a.
  // TODO: Buscar de fonte real (Banco Central API ou scraping)
  
  // Estimativa conservadora baseada em SELIC recente
  const selicRate = 0.1475; // 14.75% a.a.
  
  // DI geralmente acompanha SELIC de perto
  const diRate = selicRate;
  
  return diRate;
}

/**
 * Get B3 market parameters for fair value calculation
 */
export async function getB3MarketParams(): Promise<{
  diRate: number;
  daysToExpiry: number;
  expiryDate: Date;
}> {
  const diRate = await getDIRate();
  const { expiryDate, daysToExpiry } = calculateWINFUTExpiry();
  
  return {
    diRate,
    daysToExpiry,
    expiryDate,
  };
}
