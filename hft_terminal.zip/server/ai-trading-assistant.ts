/**
 * AI Trading Assistant Service
 * 
 * Analisa múltiplos indicadores (técnicos, macro, volume profile, dark pool)
 * e gera recomendações contextuais de trading usando LLM.
 * 
 * Output:
 * - Recomendação: LONG / SHORT / NEUTRO
 * - Confiança: 0-100%
 * - Entry, Stop Loss, Take Profit sugeridos
 * - Contexto explicativo (por que essa recomendação)
 */

import { invokeLLM } from "./_core/llm";
import { saveAIRecommendation } from "./db-ai-history";

interface TradingContext {
  // Dados WINFUT
  currentPrice: number;
  varPts: number;
  varPct: number;
  volume: number;
  
  // Indicadores Técnicos
  rsi: number;
  vwap: number;
  trueRange: number;
  accumBalance: number;
  
  // Fibonacci & Pivot
  fibonacci: {
    level_0: number;
    level_236: number;
    level_382: number;
    level_50: number;
    level_618: number;
    level_100: number;
  };
  pivotPoints: {
    r2: number;
    r1: number;
    pp: number;
    s1: number;
    s2: number;
  };
  
  // Volume Profile
  volumeProfile: {
    poc: number;
    distanceToPOC: number;
  } | null;
  
  // Dark Pool
  darkPool: {
    detected: boolean;
    direction: "BUY" | "SELL" | "NEUTRAL";
    confidence: number;
  } | null;
  
  // Macro Cascade
  macro: {
    vixChange: number;
    dxyChange: number;
    sp500Change: number;
    overallSignal: "BULLISH" | "BEARISH" | "NEUTRAL";
    confidence: number;
  } | null;
}

interface AIRecommendation {
  recommendation: "LONG" | "SHORT" | "NEUTRO";
  confidence: number; // 0-100%
  entry: number;
  stopLoss: number;
  takeProfit: number;
  context: string; // Explicação da recomendação
  timestamp: number;
}

class AITradingAssistantService {
  /**
   * Gera recomendação de trading baseado em contexto completo
   */
  async generateRecommendation(context: TradingContext): Promise<AIRecommendation> {
    try {
      // Construir prompt para LLM
      const prompt = this.buildPrompt(context);

      // Chamar LLM (API interna Manus)
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "Você é um trader profissional HFT especializado em WINFUT (mini índice Bovespa). Analise os indicadores fornecidos e gere uma recomendação de trading precisa e contextualizada.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "trading_recommendation",
            strict: true,
            schema: {
              type: "object",
              properties: {
                recommendation: {
                  type: "string",
                  enum: ["LONG", "SHORT", "NEUTRO"],
                  description: "Recomendação de trading",
                },
                confidence: {
                  type: "number",
                  description: "Confiança da recomendação (0-100)",
                },
                entry: {
                  type: "number",
                  description: "Preço de entrada sugerido",
                },
                stopLoss: {
                  type: "number",
                  description: "Stop Loss sugerido",
                },
                takeProfit: {
                  type: "number",
                  description: "Take Profit sugerido",
                },
                context: {
                  type: "string",
                  description: "Explicação contextual da recomendação (2-3 frases)",
                },
              },
              required: ["recommendation", "confidence", "entry", "stopLoss", "takeProfit", "context"],
              additionalProperties: false,
            },
          },
        },
      });

      // Parsear resposta
      const content = response.choices[0].message.content;
      const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
      const parsed: AIRecommendation = JSON.parse(contentStr || "{}");

      const recommendation = {
        ...parsed,
        timestamp: Date.now(),
      };

      // Salvar recomendação no histórico (não aguarda para não bloquear resposta)
      saveAIRecommendation({
        recommendation: recommendation.recommendation,
        confidence: recommendation.confidence,
        entry: recommendation.entry,
        stopLoss: recommendation.stopLoss,
        takeProfit: recommendation.takeProfit,
        context: recommendation.context,
        currentPrice: context.currentPrice,
        rsi: context.rsi,
        vwap: context.vwap,
        volumeProfilePoc: context.volumeProfile?.poc || null,
        macroCascadeSignal: context.macro?.overallSignal || null,
        darkPoolDetected: context.darkPool?.detected || false,
      }).catch(err => console.error("[AI Trading Assistant] Erro ao salvar histórico:", err));

      return recommendation;
    } catch (error: any) {
      console.error("\n========== ERRO OPENAI ===========");
      console.error("[AI Trading Assistant] Error generating recommendation:", error);
      console.error("[AI Trading Assistant] Error message:", error?.message);
      console.error("[AI Trading Assistant] Error stack:", error?.stack);
      console.error("[AI Trading Assistant] Error response:", error?.response?.data);
      console.error("==================================\n");
      
      // Fallback: recomendação neutra
      return {
        recommendation: "NEUTRO",
        confidence: 0,
        entry: context.currentPrice,
        stopLoss: context.currentPrice - 100,
        takeProfit: context.currentPrice + 100,
        context: "Erro ao gerar recomendação. Aguarde próxima análise.",
        timestamp: Date.now(),
      };
    }
  }

  /**
   * Constrói prompt para LLM com todos os indicadores
   */
  private buildPrompt(context: TradingContext): string {
    return `
Analise o contexto de mercado abaixo e gere uma recomendação de trading para WINFUT:

## DADOS ATUAIS
- Preço: ${context.currentPrice} pts
- Variação: ${context.varPts > 0 ? '+' : ''}${context.varPts} pts (${context.varPct.toFixed(2)}%)
- Volume: ${context.volume.toLocaleString('pt-BR')} M

## INDICADORES TÉCNICOS
- RSI: ${context.rsi.toFixed(1)} ${context.rsi > 70 ? '(OVERBOUGHT)' : context.rsi < 30 ? '(OVERSOLD)' : '(NEUTRO)'}
- VWAP: ${context.vwap} pts ${context.currentPrice > context.vwap ? '(Preço ACIMA)' : '(Preço ABAIXO)'}
- True Range: ${context.trueRange} pts
- Agressão Acumulada: ${context.accumBalance > 0 ? '+' : ''}${context.accumBalance}

## FIBONACCI RETRACEMENT
- 0%: ${context.fibonacci.level_0}
- 23.6%: ${context.fibonacci.level_236}
- 38.2%: ${context.fibonacci.level_382}
- 50%: ${context.fibonacci.level_50}
- 61.8%: ${context.fibonacci.level_618}
- 100%: ${context.fibonacci.level_100}

## PIVOT POINTS
- R2: ${context.pivotPoints.r2}
- R1: ${context.pivotPoints.r1}
- PP: ${context.pivotPoints.pp}
- S1: ${context.pivotPoints.s1}
- S2: ${context.pivotPoints.s2}

${context.volumeProfile ? `
## VOLUME PROFILE
- POC (Point of Control): ${context.volumeProfile.poc} pts
- Distância ao POC: ${context.volumeProfile.distanceToPOC > 0 ? '+' : ''}${context.volumeProfile.distanceToPOC} pts
` : ''}

${context.darkPool ? `
## DARK POOL DETECTOR
- Atividade Institucional: ${context.darkPool.detected ? 'DETECTADA' : 'NÃO DETECTADA'}
- Direção: ${context.darkPool.direction}
- Confiança: ${context.darkPool.confidence}%
` : ''}

${context.macro ? `
## MACRO CASCADE
- VIX: ${context.macro.vixChange > 0 ? '+' : ''}${context.macro.vixChange.toFixed(2)}%
- DXY (Dollar Index): ${context.macro.dxyChange > 0 ? '+' : ''}${context.macro.dxyChange.toFixed(2)}%
- S&P500: ${context.macro.sp500Change > 0 ? '+' : ''}${context.macro.sp500Change.toFixed(2)}%
- Sinal Macro: ${context.macro.overallSignal} (${context.macro.confidence}% confiança)
` : ''}

## INSTRUÇÕES
1. Analise TODOS os indicadores acima
2. Identifique confluências (múltiplos sinais alinhados)
3. Gere recomendação: LONG, SHORT ou NEUTRO
4. Calcule confiança (0-100%) baseado na força dos sinais
5. Sugira Entry, Stop Loss e Take Profit realistas
6. Explique o CONTEXTO em 2-3 frases (por que essa recomendação)

Seja PRECISO e OBJETIVO. Priorize confluências de sinais.
`.trim();
  }
}

// Singleton instance
export const aiTradingAssistantService = new AITradingAssistantService();
