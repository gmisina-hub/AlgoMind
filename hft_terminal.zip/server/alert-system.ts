/**
 * Alert System - Visual Alerts for Technical Level Crossings
 * 
 * Detects when price crosses:
 * 1. Pivot Points (R2, R1, PP, S1, S2)
 * 2. Fibonacci Retracement levels
 * 3. Linear Regression confidence bands
 */

import { notifyOwner } from "./_core/notification";

export interface Alert {
  id: string;
  type: "pivot" | "fibonacci" | "projection";
  level: string; // e.g., "R1", "Fib 61.8%", "Upper Band"
  direction: "cross_above" | "cross_below";
  price: number;
  timestamp: Date;
  message: string;
}

/**
 * Check for Pivot Point crossings
 */
export function checkPivotCrossings(
  currentPrice: number,
  previousPrice: number,
  pivotPoints: {
    r2: number;
    r1: number;
    pp: number;
    s1: number;
    s2: number;
  }
): Alert[] {
  const alerts: Alert[] = [];
  
  const levels = [
    { name: "R2", value: pivotPoints.r2 },
    { name: "R1", value: pivotPoints.r1 },
    { name: "PP", value: pivotPoints.pp },
    { name: "S1", value: pivotPoints.s1 },
    { name: "S2", value: pivotPoints.s2 },
  ];
  
  for (const level of levels) {
    // Cross above
    if (previousPrice < level.value && currentPrice >= level.value) {
      alerts.push({
        id: `pivot_${level.name}_${Date.now()}`,
        type: "pivot",
        level: level.name,
        direction: "cross_above",
        price: currentPrice,
        timestamp: new Date(),
        message: `Preço cruzou ACIMA de ${level.name} (${level.value.toFixed(0)})`,
      });
    }
    
    // Cross below
    if (previousPrice > level.value && currentPrice <= level.value) {
      alerts.push({
        id: `pivot_${level.name}_${Date.now()}`,
        type: "pivot",
        level: level.name,
        direction: "cross_below",
        price: currentPrice,
        timestamp: new Date(),
        message: `Preço cruzou ABAIXO de ${level.name} (${level.value.toFixed(0)})`,
      });
    }
  }
  
  return alerts;
}

/**
 * Check for Fibonacci level crossings
 */
export function checkFibonacciCrossings(
  currentPrice: number,
  previousPrice: number,
  fibonacci: {
    fib236: number;
    fib382: number;
    fib500: number;
    fib618: number;
    fib786: number;
  }
): Alert[] {
  const alerts: Alert[] = [];
  
  const levels = [
    { name: "Fib 23.6%", value: fibonacci.fib236 },
    { name: "Fib 38.2%", value: fibonacci.fib382 },
    { name: "Fib 50%", value: fibonacci.fib500 },
    { name: "Fib 61.8%", value: fibonacci.fib618 },
    { name: "Fib 78.6%", value: fibonacci.fib786 },
  ];
  
  for (const level of levels) {
    // Cross above
    if (previousPrice < level.value && currentPrice >= level.value) {
      alerts.push({
        id: `fib_${level.name}_${Date.now()}`,
        type: "fibonacci",
        level: level.name,
        direction: "cross_above",
        price: currentPrice,
        timestamp: new Date(),
        message: `Preço cruzou ACIMA de ${level.name} (${level.value.toFixed(0)})`,
      });
    }
    
    // Cross below
    if (previousPrice > level.value && currentPrice <= level.value) {
      alerts.push({
        id: `fib_${level.name}_${Date.now()}`,
        type: "fibonacci",
        level: level.name,
        direction: "cross_below",
        price: currentPrice,
        timestamp: new Date(),
        message: `Preço cruzou ABAIXO de ${level.name} (${level.value.toFixed(0)})`,
      });
    }
  }
  
  return alerts;
}

/**
 * Check if price exits Linear Regression confidence band
 */
export function checkProjectionBandExit(
  currentPrice: number,
  linearRegression: {
    projections: number[];
    upperBand: number[];
    lowerBand: number[];
  }
): Alert[] {
  const alerts: Alert[] = [];
  
  // Check against first projection point
  const projectedPrice = linearRegression.projections[0];
  const upperBand = linearRegression.upperBand[0];
  const lowerBand = linearRegression.lowerBand[0];
  
  // Exit above upper band
  if (currentPrice > upperBand) {
    alerts.push({
      id: `projection_upper_${Date.now()}`,
      type: "projection",
      level: "Upper Band",
      direction: "cross_above",
      price: currentPrice,
      timestamp: new Date(),
      message: `Preço SAIU da banda superior (95%) da projeção (${upperBand.toFixed(0)})`,
    });
  }
  
  // Exit below lower band
  if (currentPrice < lowerBand) {
    alerts.push({
      id: `projection_lower_${Date.now()}`,
      type: "projection",
      level: "Lower Band",
      direction: "cross_below",
      price: currentPrice,
      timestamp: new Date(),
      message: `Preço SAIU da banda inferior (95%) da projeção (${lowerBand.toFixed(0)})`,
    });
  }
  
  return alerts;
}

/**
 * Check all technical levels and return active alerts
 */
export async function checkAllAlerts(
  currentPrice: number,
  previousPrice: number,
  technicalIndicators: any
): Promise<Alert[]> {
  const alerts: Alert[] = [];
  
  // Check Pivot Points
  if (technicalIndicators.pivotPoints) {
    alerts.push(...checkPivotCrossings(currentPrice, previousPrice, technicalIndicators.pivotPoints));
  }
  
  // Check Fibonacci
  if (technicalIndicators.fibonacci) {
    alerts.push(...checkFibonacciCrossings(currentPrice, previousPrice, technicalIndicators.fibonacci));
  }
  
  // Check Linear Regression bands
  if (technicalIndicators.linearRegression) {
    alerts.push(...checkProjectionBandExit(currentPrice, technicalIndicators.linearRegression));
  }
  
  // Send push notification for critical alerts
  if (alerts.length > 0) {
    const criticalAlerts = alerts.filter(
      (alert) =>
        alert.type === "projection" || // Projection band exits are always critical
        (alert.type === "pivot" && (alert.level === "R2" || alert.level === "S2")) // R2/S2 are critical
    );
    
    if (criticalAlerts.length > 0) {
      const alertMessages = criticalAlerts.map((a) => a.message).join("\n");
      await notifyOwner({
        title: `⚠️ ${criticalAlerts.length} Alerta(s) Crítico(s) - WINFUT`,
        content: alertMessages,
      });
    }
  }
  
  return alerts;
}
