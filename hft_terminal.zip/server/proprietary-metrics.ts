/**
 * server/proprietary-metrics.ts
 * Proprietary quantitative metrics for institutional trading
 */

export interface ProprietaryMetrics {
  zVWAP: number; // VWAP normalizado (z-score)
  flowEfficiency: number; // Eficiência de fluxo (0-100)
  trRatio: number; // True Range ratio
  grs: number; // Global Risk Score (0-100)
}

/**
 * Calculate zVWAP (normalized VWAP)
 * Measures how many standard deviations the current price is from VWAP
 * 
 * @param last - Current price
 * @param vwap - Volume Weighted Average Price
 * @param stdDev - Standard deviation (approximated from True Range)
 * @returns z-score (-3 to +3 typically)
 */
export function calculateZVWAP(last: number, vwap: number, stdDev: number): number {
  if (stdDev === 0) return 0;
  return (last - vwap) / stdDev;
}

/**
 * Calculate Flow Efficiency
 * Measures how efficiently the market is moving (trending vs choppy)
 * 
 * @param accumBalance - Accumulated balance (order flow)
 * @param volume - Total volume
 * @param trueRange - True Range
 * @returns efficiency score (0-100)
 */
export function calculateFlowEfficiency(
  accumBalance: number,
  volume: number,
  trueRange: number
): number {
  if (volume === 0 || trueRange === 0) return 50; // Neutral

  // Normalize accumulated balance by volume
  const normalizedFlow = Math.abs(accumBalance) / volume;

  // Efficiency = (normalized flow / true range) * 100
  // Higher values = more efficient (trending)
  // Lower values = less efficient (choppy)
  const efficiency = (normalizedFlow / trueRange) * 10000;

  // Clamp to 0-100
  return Math.max(0, Math.min(100, efficiency));
}

/**
 * Calculate TR Ratio (True Range Ratio)
 * Measures volatility relative to price level
 * 
 * @param trueRange - True Range
 * @param last - Current price
 * @returns ratio (0-10 typically)
 */
export function calculateTRRatio(trueRange: number, last: number): number {
  if (last === 0) return 0;
  return (trueRange / last) * 100;
}

/**
 * Calculate Global Risk Score (GRS)
 * Composite risk metric combining multiple factors
 * 
 * @param rsi - RSI indicator (0-100)
 * @param zVWAP - Normalized VWAP
 * @param trRatio - True Range Ratio
 * @param flowEfficiency - Flow Efficiency
 * @returns risk score (0-100, higher = more risk)
 */
export function calculateGRS(
  rsi: number,
  zVWAP: number,
  trRatio: number,
  flowEfficiency: number
): number {
  // RSI component (extreme RSI = higher risk)
  const rsiRisk = Math.abs(rsi - 50) / 50; // 0-1

  // zVWAP component (far from VWAP = higher risk)
  const vwapRisk = Math.min(Math.abs(zVWAP) / 3, 1); // 0-1

  // TR Ratio component (high volatility = higher risk)
  const volatilityRisk = Math.min(trRatio / 5, 1); // 0-1

  // Flow Efficiency component (low efficiency = higher risk)
  const flowRisk = 1 - flowEfficiency / 100; // 0-1

  // Weighted average (adjust weights as needed)
  const grs =
    rsiRisk * 0.25 + vwapRisk * 0.3 + volatilityRisk * 0.25 + flowRisk * 0.2;

  // Convert to 0-100 scale
  return grs * 100;
}

/**
 * Calculate all proprietary metrics at once
 */
export function calculateProprietaryMetrics(data: {
  last: number;
  vwap: number;
  trueRange: number;
  accumBalance: number;
  volume: number;
  rsi: number;
}): ProprietaryMetrics {
  // Approximate standard deviation from True Range (TR ≈ 2.66 * σ)
  const stdDev = data.trueRange / 2.66;

  const zVWAP = calculateZVWAP(data.last, data.vwap, stdDev);
  const flowEfficiency = calculateFlowEfficiency(
    data.accumBalance,
    data.volume,
    data.trueRange
  );
  const trRatio = calculateTRRatio(data.trueRange, data.last);
  const grs = calculateGRS(data.rsi, zVWAP, trRatio, flowEfficiency);

  return {
    zVWAP,
    flowEfficiency,
    trRatio,
    grs,
  };
}
