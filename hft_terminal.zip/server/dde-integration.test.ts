import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("DDE Integration", () => {
  describe("Market Router - getDDEData", () => {
    it("should return a response object with success field", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.market.getDDEData();

      expect(result).toBeDefined();
      expect(result).toHaveProperty("success");
      expect(typeof result.success).toBe("boolean");
      // When DDE is unavailable, we get error property instead of data
      expect(result.success === true ? result.data : result.error).toBeDefined();
    });

    it("should handle errors gracefully", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.market.getDDEData();

      // Even if DDE API is not available, should return error response
      if (!result.success) {
        expect(result).toHaveProperty("error");
        expect(typeof result.error).toBe("string");
      }
    });

    it("should return market snapshot data when successful", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.market.getDDEData();

      if (result.success && result.data) {
        expect(result.data).toHaveProperty("marketSnapshot");
        expect(result.data).toHaveProperty("lastPrice");
        expect(result.data).toHaveProperty("insightMain");
        expect(result.data).toHaveProperty("marketPressure");
        expect(result.data).toHaveProperty("volatilityScore");
        expect(result.data).toHaveProperty("volatilityLevel");
        expect(result.data).toHaveProperty("priceTrend");
      }
    });
  });

  describe("Market Router - getLatestSnapshot", () => {
    it("should accept a symbol parameter", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.market.getLatestSnapshot({ symbol: "WINFUT" });

      // Should not throw and return null or snapshot object
      expect(result === null || typeof result === "object").toBe(true);
    });

    it("should handle different symbols", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const symbols = ["WINFUT", "INDFUT", "DOLFUT"];

      for (const symbol of symbols) {
        const result = await caller.market.getLatestSnapshot({ symbol });
        expect(result === null || typeof result === "object").toBe(true);
      }
    });
  });

  describe("Backtest Router - Integration", () => {
    it("should allow authenticated users to fetch backtests", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getUserBacktests();

      expect(result.success).toBe(true);
      expect(Array.isArray(result.data)).toBe(true);
    });

    it("should allow authenticated users to fetch robot performance", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      expect(result.success).toBe(true);
      expect(Array.isArray(result.data)).toBe(true);
    });

    it("should allow authenticated users to fetch trades", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      expect(result.success).toBe(true);
      expect(Array.isArray(result.data)).toBe(true);
    });

    it("should support filtering trades by robot", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({
        backtestId: 1,
        robot: "TestRobot",
      });

      expect(result.success).toBe(true);
      expect(Array.isArray(result.data)).toBe(true);
    });
  });

  describe("Data Consistency", () => {
    it("should return consistent market snapshot structure", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.market.getDDEData();

      if (result.success && result.data?.marketSnapshot) {
        const snapshot = result.data.marketSnapshot;
        expect(snapshot).toHaveProperty("symbol");
        expect(snapshot).toHaveProperty("timestamp");
        // All numeric fields should be numbers or null
        expect(typeof snapshot.last === "number" || snapshot.last === null).toBe(true);
      }
    });

    it("should return valid volatility levels", async () => {
      const caller = appRouter.createCaller({} as TrpcContext);

      const result = await caller.market.getDDEData();

      if (result.success && result.data) {
        const validLevels = ["LOW", "MEDIUM", "HIGH"];
        expect(validLevels).toContain(result.data.volatilityLevel);
      }
    });
  });
});
