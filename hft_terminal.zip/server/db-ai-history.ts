/**
 * Database helpers para histórico de recomendações AI
 */

import { getDb } from "./db";
import { aiRecommendationsHistory } from "../drizzle/schema";
import { desc, sql } from "drizzle-orm";

/**
 * Salva recomendação AI no histórico
 */
export async function saveAIRecommendation(data: {
  recommendation: "LONG" | "SHORT" | "NEUTRO";
  confidence: number;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  context: string;
  currentPrice: number;
  rsi: number;
  vwap: number;
  volumeProfilePoc: number | null;
  macroCascadeSignal: string | null;
  darkPoolDetected: boolean;
}) {
  try {
    const db = await getDb();
    if (!db) {
      console.error("[AI History] Database not available");
      return;
    }
    
    await db.insert(aiRecommendationsHistory).values({
      recommendation: data.recommendation,
      confidence: Math.round(data.confidence), // int 0-100
      entry: data.entry.toString(),
      stopLoss: data.stopLoss.toString(),
      takeProfit: data.takeProfit.toString(),
      context: data.context,
      timestamp: Date.now(), // Unix timestamp in ms
    });
    
    console.log(`[AI History] Recomendação salva: ${data.recommendation} ${data.confidence}%`);
  } catch (error) {
    console.error("[AI History] Erro ao salvar recomendação:", error);
  }
}

/**
 * Busca últimas N recomendações
 */
export async function getLatestRecommendations(limit: number = 50) {
  const db = await getDb();
  if (!db) {
    console.error("[AI History] Database not available");
    return [];
  }
  
  return db
    .select()
    .from(aiRecommendationsHistory)
    .orderBy(desc(aiRecommendationsHistory.timestamp))
    .limit(limit);
}

/**
 * Calcula KPIs do histórico de recomendações
 * (simula backtest das recomendações)
 */
export async function calculateAIKPIs() {
  const recommendations = await getLatestRecommendations(100);
  
  if (recommendations.length === 0) {
    return {
      totalRecommendations: 0,
      longCount: 0,
      shortCount: 0,
      neutralCount: 0,
      avgConfidence: 0,
      // Backtest KPIs (simulados)
      winRate: 0,
      profitFactor: 0,
      sharpeRatio: 0,
      maxDrawdown: 0,
      totalPnL: 0,
    };
  }

  // Contadores básicos
  const totalRecommendations = recommendations.length;
  const longCount = recommendations.filter(r => r.recommendation === "LONG").length;
  const shortCount = recommendations.filter(r => r.recommendation === "SHORT").length;
  const neutralCount = recommendations.filter(r => r.recommendation === "NEUTRO").length;
  
  const avgConfidence = recommendations.reduce((sum, r) => sum + r.confidence, 0) / totalRecommendations;

  // Simular backtest das recomendações
  // (assumindo que cada recomendação foi seguida e fechada no próximo tick)
  let wins = 0;
  let losses = 0;
  let totalProfit = 0;
  let totalLoss = 0;
  let equity = 10000; // Capital inicial simulado
  let maxEquity = 10000;
  let maxDrawdown = 0;
  const returns: number[] = [];

  for (let i = 0; i < recommendations.length - 1; i++) {
    const rec = recommendations[i];
    const nextRec = recommendations[i + 1];
    
    const entryPrice = parseFloat(rec.entry);
    const stopLoss = parseFloat(rec.stopLoss);
    const takeProfit = parseFloat(rec.takeProfit);
    const nextPrice = parseFloat(nextRec.entry); // Usar entry do próximo tick como proxy do preço atual
    
    // Simular resultado da operação
    let pnl = 0;
    if (rec.recommendation === "LONG") {
      // Se preço subiu até TP → ganho, se caiu até SL → perda
      if (nextPrice >= takeProfit) {
        pnl = takeProfit - entryPrice;
        wins++;
        totalProfit += pnl;
      } else if (nextPrice <= stopLoss) {
        pnl = stopLoss - entryPrice;
        losses++;
        totalLoss += Math.abs(pnl);
      } else {
        // Fechou no meio → considerar neutro (não conta win/loss)
        pnl = nextPrice - entryPrice;
      }
    } else if (rec.recommendation === "SHORT") {
      // Se preço caiu até TP → ganho, se subiu até SL → perda
      if (nextPrice <= takeProfit) {
        pnl = entryPrice - takeProfit;
        wins++;
        totalProfit += pnl;
      } else if (nextPrice >= stopLoss) {
        pnl = entryPrice - stopLoss;
        losses++;
        totalLoss += Math.abs(pnl);
      } else {
        // Fechou no meio → considerar neutro
        pnl = entryPrice - nextPrice;
      }
    }
    
    // Atualizar equity
    equity += pnl;
    if (equity > maxEquity) maxEquity = equity;
    
    // Calcular drawdown
    const drawdown = ((maxEquity - equity) / maxEquity) * 100;
    if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    
    // Guardar retorno para Sharpe Ratio
    if (pnl !== 0) {
      returns.push((pnl / entryPrice) * 100);
    }
  }

  // Calcular métricas
  const totalTrades = wins + losses;
  const winRate = totalTrades > 0 ? (wins / totalTrades) * 100 : 0;
  const profitFactor = totalLoss > 0 ? totalProfit / totalLoss : 0;
  
  // Sharpe Ratio (retorno médio / desvio padrão dos retornos)
  const avgReturn = returns.length > 0 ? returns.reduce((a, b) => a + b, 0) / returns.length : 0;
  const variance = returns.length > 0 
    ? returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length 
    : 0;
  const stdDev = Math.sqrt(variance);
  const sharpeRatio = stdDev > 0 ? (avgReturn / stdDev) * Math.sqrt(252) : 0; // Anualizado

  const totalPnL = equity - 10000;

  return {
    totalRecommendations,
    longCount,
    shortCount,
    neutralCount,
    avgConfidence: Math.round(avgConfidence),
    // Backtest KPIs
    winRate: Math.round(winRate * 10) / 10,
    profitFactor: Math.round(profitFactor * 100) / 100,
    sharpeRatio: Math.round(sharpeRatio * 100) / 100,
    maxDrawdown: Math.round(maxDrawdown * 10) / 10,
    totalPnL: Math.round(totalPnL),
  };
}
