/**
 * server/market-service.ts
 * Market data service: Profit DDE + Yahoo Finance integration
 */

import { callDataApi } from "./_core/dataApi";
import { ENV } from "./_core/env";

// ============================================
// PROFIT DDE INTEGRATION
// ============================================

/**
 * Fetch data from Profit DDE (local Python service via ngrok)
 * Real DDE structure: { marketSnapshot: { last, open, high, low, volume, vwap, vwapMonthly, rsi, accumBalance, trueRange, timestamp, ... }, ... }
 */
export async function fetchProfitDDE() {
  try {
    const endpoint = `${ENV.ddeApiUrl}/prices`;
    const response = await fetch(endpoint, {
      headers: {
        "ngrok-skip-browser-warning": "true", // Skip ngrok browser warning
      },
    });
    if (!response.ok) {
      throw new Error(`DDE service returned ${response.status}`);
    }
    const data = await response.json();
    
    // Map real DDE structure to expected format
    const snapshot = data.marketSnapshot;
    if (!snapshot) {
      throw new Error("DDE response missing marketSnapshot");
    }

    return {
      marketSnapshot: {
        symbol: snapshot.symbol || "WINFUT",
        last: snapshot.last || 0,
        open: snapshot.open || 0,
        high: snapshot.high || 0,
        low: snapshot.low || 0,
        close: snapshot.close || snapshot.open || 0,
        varPts: snapshot.varPts || 0,
        varPct: snapshot.varPct || 0,
        volume: snapshot.volume || 0,
        adjust: snapshot.adjust || snapshot.last || 0,
        adjustPrev: snapshot.adjustPrev || snapshot.open || 0,
        hilo: snapshot.hilo || (snapshot.high - snapshot.low) || 0,
        rsi: snapshot.rsi || snapshot["WINFUT.1"] || 0,
        priorAdj: snapshot.priorAdj || snapshot.open || 0,
        priorAdjB: snapshot.priorAdjB || snapshot.open || 0,
        accumBalance: snapshot.accumBalance || snapshot["WINFUT.103"] || 0,
        trueRange: snapshot.trueRange || snapshot["WINFUT.17"] || 0,
        vwap: snapshot.vwap || 0,
        vwapMonthly: snapshot.vwapMonthly || 0,
        timestamp: snapshot.timestamp || new Date().toISOString(),
      },
      otherAssets: data.otherAssets || {},
      lastPrice: snapshot.last || 0,
      lastPriceLabel: `WINFUT ${snapshot.last || 0} pts`,
      insightMain: data.insightMain || `WINFUT ${snapshot.last || 0} pts – direção ${data.priceTrend?.direction || "Sideways"}.`,
      insightSecondary: data.insightSecondary || `Variação de ${snapshot.varPct?.toFixed(2) || "0.00"}% vs ref. intradiária.`,
      marketPressure: data.marketPressure || { buy: 0.5, sell: 0.5, net: 0 },
      volatilityScore: data.volatilityScore || 0,
      volatilityLevel: data.volatilityLevel || "MEDIUM",
      executiveSummary: data.executiveSummary || `WINFUT ${snapshot.last || 0} | Var ${snapshot.varPct?.toFixed(2) || "0.00"}% | Vol ${snapshot.volume || 0}`,
      priceTrend: data.priceTrend || {
        direction: "Sideways",
        probLow: 0.33,
        probMedium: 0.34,
        probHigh: 0.33,
      },
    };
  } catch (error) {
    console.warn("[Profit DDE] Service not available, using mock data");
    // Return mock data when DDE is not available
    return {
      marketSnapshot: {
        symbol: "WINFUT",
        last: 127450,
        open: 124800,
        high: 128900,
        low: 124500,
        close: 124800,
        varPts: 2650,
        varPct: 2.12,
        volume: 2500000,
        adjust: 127450,
        adjustPrev: 124800,
        hilo: 4400,
        rsi: 65.5,
        priorAdj: 124800,
        priorAdjB: 124500,
        accumBalance: 15000,
        trueRange: 4400,
        vwap: 126850,
        vwapMonthly: 125500,
        timestamp: new Date().toISOString(),
      },
      lastPrice: 127450,
      lastPriceLabel: "WINFUT 127450 pts",
      insightMain: "WINFUT 127450 pts – direção Up.",
      insightSecondary: "Variação de +2.12% vs ref. intradiária. Monitorando estrutura de risco e oportunidade em tempo real.",
      marketPressure: { buy: 0.65, sell: 0.35, net: 0.30 },
      volatilityScore: 0.75,
      volatilityLevel: "HIGH",
      executiveSummary: "WINFUT 127450 | Var +2.12% | Vol 2500000 – Dados mock (DDE offline).",
      priceTrend: {
        direction: "Up",
        probLow: 0.15,
        probMedium: 0.30,
        probHigh: 0.55,
      },
    };
  }
}

// ============================================
// YAHOO FINANCE INTEGRATION
// ============================================

/**
 * Get mock data for a symbol when Yahoo Finance fails
 * (Only for international markets, NOT B3)
 */
function getMockDataForSymbol(symbol: string): any {
  const mockData: Record<string, any> = {
    // Índices Internacionais
    "^DXY": { symbol: "^DXY", name: "US Dollar Index", last: 104.25, open: 104.10, high: 104.50, low: 103.90, close: 104.00, varPts: 0.25, varPct: 0.24, volume: 0, currency: "USD", exchange: "N/A", timestamp: new Date().toISOString() },
    "^VIX": { symbol: "^VIX", name: "CBOE Volatility Index", last: 18.75, open: 19.20, high: 19.50, low: 18.30, close: 19.00, varPts: -0.25, varPct: -1.32, volume: 0, currency: "USD", exchange: "N/A", timestamp: new Date().toISOString() },
    "^GSPC": { symbol: "^GSPC", name: "S&P 500", last: 4580.25, open: 4565.00, high: 4590.00, low: 4560.00, close: 4570.00, varPts: 10.25, varPct: 0.22, volume: 0, currency: "USD", exchange: "N/A", timestamp: new Date().toISOString() },
    "^DJI": { symbol: "^DJI", name: "Dow Jones Industrial Average", last: 35420.50, open: 35300.00, high: 35500.00, low: 35280.00, close: 35380.00, varPts: 40.50, varPct: 0.11, volume: 0, currency: "USD", exchange: "N/A", timestamp: new Date().toISOString() },
    "^IXIC": { symbol: "^IXIC", name: "NASDAQ Composite", last: 14250.75, open: 14180.00, high: 14280.00, low: 14150.00, close: 14200.00, varPts: 50.75, varPct: 0.36, volume: 0, currency: "USD", exchange: "N/A", timestamp: new Date().toISOString() },
    "^FTSE": { symbol: "^FTSE", name: "FTSE 100", last: 7520.30, open: 7500.00, high: 7540.00, low: 7490.00, close: 7510.00, varPts: 10.30, varPct: 0.14, volume: 0, currency: "GBP", exchange: "N/A", timestamp: new Date().toISOString() },
    "^N225": { symbol: "^N225", name: "Nikkei 225", last: 32850.00, open: 32700.00, high: 32900.00, low: 32650.00, close: 32800.00, varPts: 50.00, varPct: 0.15, volume: 0, currency: "JPY", exchange: "N/A", timestamp: new Date().toISOString() },

    // Moedas (Forex)
    "EURUSD=X": { symbol: "EURUSD=X", name: "EUR/USD", last: 1.0875, open: 1.0850, high: 1.0890, low: 1.0840, close: 1.0860, varPts: 0.0015, varPct: 0.14, volume: 0, currency: "USD", exchange: "CCY", timestamp: new Date().toISOString() },
    "GBPUSD=X": { symbol: "GBPUSD=X", name: "GBP/USD", last: 1.2650, open: 1.2620, high: 1.2680, low: 1.2610, close: 1.2630, varPts: 0.0020, varPct: 0.16, volume: 0, currency: "USD", exchange: "CCY", timestamp: new Date().toISOString() },
    "JPYUSD=X": { symbol: "JPYUSD=X", name: "JPY/USD", last: 0.0067, open: 0.0068, high: 0.0068, low: 0.0067, close: 0.0068, varPts: -0.0001, varPct: -1.47, volume: 0, currency: "USD", exchange: "CCY", timestamp: new Date().toISOString() },
    "CADUSD=X": { symbol: "CADUSD=X", name: "CAD/USD", last: 0.7380, open: 0.7370, high: 0.7390, low: 0.7365, close: 0.7375, varPts: 0.0005, varPct: 0.07, volume: 0, currency: "USD", exchange: "CCY", timestamp: new Date().toISOString() },
    "BRLUSD=X": { symbol: "BRLUSD=X", name: "BRL/USD", last: 0.2010, open: 0.2005, high: 0.2015, low: 0.2000, close: 0.2008, varPts: 0.0002, varPct: 0.10, volume: 0, currency: "USD", exchange: "CCY", timestamp: new Date().toISOString() },
    "MXNUSD=X": { symbol: "MXNUSD=X", name: "MXN/USD", last: 0.0585, open: 0.0583, high: 0.0587, low: 0.0582, close: 0.0584, varPts: 0.0001, varPct: 0.17, volume: 0, currency: "USD", exchange: "CCY", timestamp: new Date().toISOString() },

    // Commodities
    "GC=F": { symbol: "GC=F", name: "Gold", last: 2035.50, open: 2028.00, high: 2042.00, low: 2025.00, close: 2030.00, varPts: 5.50, varPct: 0.27, volume: 0, currency: "USD", exchange: "COMEX", timestamp: new Date().toISOString() },
    "SI=F": { symbol: "SI=F", name: "Silver", last: 24.85, open: 24.70, high: 25.00, low: 24.65, close: 24.75, varPts: 0.10, varPct: 0.40, volume: 0, currency: "USD", exchange: "COMEX", timestamp: new Date().toISOString() },
    "CL=F": { symbol: "CL=F", name: "Crude Oil WTI", last: 78.25, open: 77.80, high: 78.60, low: 77.50, close: 77.90, varPts: 0.35, varPct: 0.45, volume: 0, currency: "USD", exchange: "NYMEX", timestamp: new Date().toISOString() },
    "BZ=F": { symbol: "BZ=F", name: "Brent Crude Oil", last: 82.40, open: 81.90, high: 82.70, low: 81.60, close: 82.00, varPts: 0.40, varPct: 0.49, volume: 0, currency: "USD", exchange: "ICE", timestamp: new Date().toISOString() },
    "NG=F": { symbol: "NG=F", name: "Natural Gas", last: 2.95, open: 2.88, high: 3.00, low: 2.85, close: 2.90, varPts: 0.05, varPct: 1.72, volume: 0, currency: "USD", exchange: "NYMEX", timestamp: new Date().toISOString() },
    "HG=F": { symbol: "HG=F", name: "Copper", last: 3.82, open: 3.78, high: 3.85, low: 3.76, close: 3.80, varPts: 0.02, varPct: 0.53, volume: 0, currency: "USD", exchange: "COMEX", timestamp: new Date().toISOString() },

    // ADRs
    "EWZ": { symbol: "EWZ", name: "iShares MSCI Brazil ETF", last: 32.45, open: 32.20, high: 32.60, low: 32.10, close: 32.30, varPts: 0.15, varPct: 0.46, volume: 5200000, currency: "USD", exchange: "NYSE", timestamp: new Date().toISOString() },
    "VALE": { symbol: "VALE", name: "Vale SA", last: 14.85, open: 14.70, high: 15.00, low: 14.65, close: 14.75, varPts: 0.10, varPct: 0.68, volume: 18500000, currency: "USD", exchange: "NYSE", timestamp: new Date().toISOString() },
    "PBR": { symbol: "PBR", name: "Petrobras", last: 16.25, open: 16.10, high: 16.40, low: 16.05, close: 16.15, varPts: 0.10, varPct: 0.62, volume: 22300000, currency: "USD", exchange: "NYSE", timestamp: new Date().toISOString() },
    "ITUB": { symbol: "ITUB", name: "Itaú Unibanco", last: 6.45, open: 6.38, high: 6.50, low: 6.35, close: 6.40, varPts: 0.05, varPct: 0.78, volume: 12800000, currency: "USD", exchange: "NYSE", timestamp: new Date().toISOString() },
  };

  return mockData[symbol] || {
    symbol,
    name: symbol,
    last: 100,
    open: 99,
    high: 101,
    low: 98,
    close: 99.5,
    varPts: 0.5,
    varPct: 0.50,
    volume: 1000000,
    currency: "USD",
    exchange: "N/A",
    timestamp: new Date().toISOString(),
  };
}

/**
 * Fetch stock/index/commodity data from Yahoo Finance
 */
export async function fetchYahooFinance(params: {
  symbol: string;
  interval?: string; // 1m, 5m, 15m, 1h, 1d, 1wk, 1mo
  range?: string; // 1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max
}) {
  try {
    const result = await callDataApi("YahooFinance/get_stock_chart", {
      query: {
        symbol: params.symbol,
        region: "US",
        interval: params.interval || "1d",
        range: params.range || "1d",
      },
    });

    const resultAny = result as any;
    if (!resultAny || !resultAny.chart || !resultAny.chart.result || resultAny.chart.result.length === 0) {
      console.error(`[Yahoo Finance] No data for ${params.symbol}`);
      return null;
    }

    const chartResult = resultAny.chart.result[0];
    const meta = chartResult.meta;
    const timestamps = chartResult.timestamp || [];
    const quotes = chartResult.indicators?.quote?.[0] || {};

    // Get latest values
    const lastIndex = timestamps.length - 1;
    const last = quotes.close?.[lastIndex] || meta.regularMarketPrice || 0;
    const open = quotes.open?.[lastIndex] || 0;
    const high = quotes.high?.[lastIndex] || 0;
    const low = quotes.low?.[lastIndex] || 0;
    const volume = quotes.volume?.[lastIndex] || 0;
    const previousClose = meta.chartPreviousClose || meta.previousClose || 0;

    const varPts = last - previousClose;
    const varPct = previousClose > 0 ? (varPts / previousClose) * 100 : 0;

    return {
      symbol: params.symbol,
      name: meta.longName || meta.shortName || params.symbol,
      last,
      open,
      high,
      low,
      close: previousClose,
      varPts,
      varPct,
      volume,
      currency: meta.currency || "USD",
      exchange: meta.exchangeName || "N/A",
      timestamp: timestamps[lastIndex] ? new Date(timestamps[lastIndex] * 1000).toISOString() : new Date().toISOString(),
    };
  } catch (error) {
    console.error(`[Yahoo Finance] Error fetching ${params.symbol}:`, error);
    // Return mock data as fallback (only for international markets, NOT B3)
    if (!params.symbol.endsWith('.SA')) {
      return getMockDataForSymbol(params.symbol);
    }
    return null;
  }
}

/**
 * Fetch multiple symbols in parallel
 */
export async function fetchMultipleSymbols(symbols: string[], interval?: string, range?: string) {
  const promises = symbols.map((symbol) =>
    fetchYahooFinance({ symbol, interval, range })
  );
  const results = await Promise.all(promises);
  return results.filter((r) => r !== null);
}

// ============================================
// MARKET DATA AGGREGATORS
// ============================================

/**
 * Get Brazilian market data (Profit DDE)
 */
export async function getBrazilianMarketData() {
  const ddeData = await fetchProfitDDE();
  if (!ddeData) {
    return {
      winfut: null,
      lastUpdate: null,
    };
  }

  return {
    winfut: ddeData.marketSnapshot,
    otherAssets: ddeData.otherAssets || {},
    lastPrice: ddeData.lastPrice,
    insightMain: ddeData.insightMain,
    insightSecondary: ddeData.insightSecondary,
    marketPressure: ddeData.marketPressure,
    volatilityScore: ddeData.volatilityScore,
    volatilityLevel: ddeData.volatilityLevel,
    executiveSummary: ddeData.executiveSummary,
    priceTrend: ddeData.priceTrend,
    lastUpdate: ddeData.marketSnapshot?.timestamp || null,
  };
}

/**
 * Get international indices
 */
export async function getInternationalIndices() {
  const symbols = [
    "^DXY", // US Dollar Index
    "^VIX", // Volatility Index
    "^GSPC", // S&P 500
    "^DJI", // Dow Jones
    "^IXIC", // NASDAQ
    "^FTSE", // FTSE 100
    "^N225", // Nikkei 225
  ];

  const results = await fetchMultipleSymbols(symbols);
  return results.reduce((acc, item) => {
    if (item) {
      acc[item.symbol] = item;
    }
    return acc;
  }, {} as Record<string, any>);
}

/**
 * Get forex pairs
 */
export async function getForexPairs() {
  const symbols = [
    "EURUSD=X", // EUR/USD
    "GBPUSD=X", // GBP/USD
    "JPYUSD=X", // JPY/USD
    "CADUSD=X", // CAD/USD
    "BRLUSD=X", // BRL/USD
    "MXNUSD=X", // MXN/USD
  ];

  const results = await fetchMultipleSymbols(symbols);
  return results.reduce((acc, item) => {
    if (item) {
      acc[item.symbol] = item;
    }
    return acc;
  }, {} as Record<string, any>);
}

/**
 * Get commodities
 */
export async function getCommodities() {
  const symbols = [
    "GC=F", // Gold
    "SI=F", // Silver
    "CL=F", // Crude Oil WTI
    "BZ=F", // Brent Crude Oil
    "NG=F", // Natural Gas
    "HG=F", // Copper
  ];

  const results = await fetchMultipleSymbols(symbols);
  return results.reduce((acc, item) => {
    if (item) {
      acc[item.symbol] = item;
    }
    return acc;
  }, {} as Record<string, any>);
}

/**
 * Get ADRs (American Depositary Receipts)
 */
export async function getADRs() {
  const symbols = [
    "EWZ", // iShares MSCI Brazil ETF
    "VALE", // Vale SA
    "PBR", // Petrobras
    "ITUB", // Itaú Unibanco
  ];

  const results = await fetchMultipleSymbols(symbols);
  return results.reduce((acc, item) => {
    if (item) {
      acc[item.symbol] = item;
    }
    return acc;
  }, {} as Record<string, any>);
}

/**
 * Get top Brazilian stocks (Blueships IBOV)
 */
export async function getTopBrazilianStocks() {
  const symbols = [
    "VALE3.SA", // Vale
    "PETR4.SA", // Petrobras
    "ITUB4.SA", // Itaú
    "BBDC4.SA", // Bradesco
    "ABEV3.SA", // Ambev
    "WEGE3.SA", // WEG
    "RENT3.SA", // Localiza
    "BBAS3.SA", // Banco do Brasil
    "ITSA4.SA", // Itaúsa
    "ELET3.SA", // Eletrobras
    "RDOR3.SA", // Rede D'Or
    "SUZB3.SA", // Suzano
  ];

  const results = await fetchMultipleSymbols(symbols);
  return results.reduce((acc, item) => {
    if (item) {
      acc[item.symbol] = item;
    }
    return acc;
  }, {} as Record<string, any>);
}

// ============================================
// CALCULATED METRICS
// ============================================

/**
 * Calculate "Preço Justo" (Fair Price) for an asset
 * Based on ABERT, JUSTO, MAX, MIN, AMPLIT, DIST metrics
 */
export function calculateFairPrice(data: {
  open: number;
  high: number;
  low: number;
  close: number;
  last: number;
}) {
  const { open, high, low, close, last } = data;

  // JUSTO = média entre máxima e mínima
  const justo = (high + low) / 2;

  // AMPLIT MÉDIA = amplitude média histórica (aproximação: high - low)
  const amplitMedia = high - low;

  // AMPLIT DIA = amplitude do dia (high - low)
  const amplitDia = high - low;

  // DIST ABER = distância da abertura ao preço justo
  const distAber = open - justo;

  // DIST MAX = distância da máxima ao preço justo
  const distMax = high - justo;

  // DIST MIN = distância da mínima ao preço justo
  const distMin = low - justo;

  return {
    abert: open,
    justo,
    max: high,
    min: low,
    amplitMedia,
    amplitDia,
    distAber,
    distMax,
    distMin,
  };
}

/**
 * Calculate market probabilities (Bull vs Bear)
 * Based on price action and momentum
 */
export function calculateProbabilities(data: {
  last: number;
  open: number;
  high: number;
  low: number;
  close: number;
  varPct: number;
}) {
  const { last, open, high, low, close, varPct } = data;

  // Momentum: variação percentual
  const momentum = varPct;

  // Posição no range do dia: 0 = mínima, 1 = máxima
  const range = high - low;
  const positionInRange = range > 0 ? (last - low) / range : 0.5;

  // Probabilidade de COMPRA (bull): baseada em momentum positivo e posição alta no range
  let probBuy = 0.5; // neutro
  if (momentum > 0) {
    probBuy += momentum / 2; // aumenta com momentum positivo
  }
  probBuy += (positionInRange - 0.5) * 0.3; // aumenta se estiver acima do meio do range

  // Limitar entre 0 e 1
  probBuy = Math.max(0, Math.min(1, probBuy));

  // Probabilidade de VENDA (bear): complemento
  const probSell = 1 - probBuy;

  return {
    buy: Math.round(probBuy * 100),
    sell: Math.round(probSell * 100),
  };
}
