import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getUserBacktests, getBacktestRobotPerformance, getBacktestTrades, createBacktest, createBacktestWithId, updateBacktestStatus, saveRobotPerformance, saveTrades } from "../db.market";
import { storagePut } from "../storage";
import { nanoid } from "nanoid";

/**
 * Parse Excel data from base64 and extract backtest information
 */
function parseExcelData(fileData: string | Buffer) {
  try {
    console.log('[Backtest] Starting parseExcelData...');
    
    let buffer: Buffer;
    
    if (Buffer.isBuffer(fileData)) {
      buffer = fileData;
    } else {
      // Remove data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64, prefix
      const base64Data = fileData.split(",")[1] || fileData;
      console.log('[Backtest] Base64 data length:', base64Data.length);
      buffer = Buffer.from(base64Data, "base64");
    }
    console.log('[Backtest] Buffer created, size:', buffer.length);

    // Use xlsx to parse Excel file
    const XLSX = require('xlsx');
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    console.log('[Backtest] Workbook loaded, sheets:', workbook.SheetNames);
    
    // Procurar pela aba 'report_profit' ou usar a primeira aba
    const sheetName = workbook.SheetNames.find((name: string) => name.toLowerCase().includes('report')) || workbook.SheetNames[0];
    console.log('[Backtest] Using sheet:', sheetName);
    
    const worksheet = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json(worksheet);
    console.log('[Backtest] JSON data rows:', jsonData.length);

    // Map Excel columns to our expected format
    // Helper function to find column value with accent tolerance
    const getColumnValue = (row: any, ...possibleNames: string[]) => {
      for (const name of possibleNames) {
        if (row[name] !== undefined && row[name] !== null) {
          return row[name];
        }
      }
      return '';
    };

    const data = jsonData.map((row: any) => {
      const side = getColumnValue(row, 'Lado', 'Side', 'side');
      // Preço de compra é entry price para long, preço de venda é entry price para short
      const buyPrice = parseFloat(getColumnValue(row, 'Preço Compra', 'Buy Price', 'buy_price') || 0);
      const sellPrice = parseFloat(getColumnValue(row, 'Preço Venda', 'Sell Price', 'sell_price') || 0);
      const entryPrice = side === 'C' ? buyPrice : sellPrice;
      const exitPrice = side === 'C' ? sellPrice : buyPrice;
      
      return {
        account: getColumnValue(row, 'Subconta', 'Account', 'Conta', 'account'),
        robot: getColumnValue(row, 'Robô', 'Robo', 'Robot', 'robot'),
        asset: getColumnValue(row, 'Ativo', 'Asset', 'asset'),
        entryTime: getColumnValue(row, 'Abertura', 'Entry Time', 'entry_time'),
        exitTime: getColumnValue(row, 'Fechamento', 'Exit Time', 'exit_time'),
        entryPrice: entryPrice,
        exitPrice: exitPrice,
        pnl: parseFloat(getColumnValue(row, 'Liquido', 'Res. Operação', 'Res. Intervalo', 'PnL', 'pnl') || 0),
        pnlBruto: parseFloat(getColumnValue(row, 'Res. Intervalo Bruto', 'Res. Operacao', 'pnl_bruto') || 0),
        side: side,
        quantity: parseFloat(getColumnValue(row, 'Qtd Compra', 'Qtd Venda', 'Quantity', 'quantity') || 0),
        duration: getColumnValue(row, 'Tempo Operacao', 'Duration', 'duration'),
      };
    });
    
    console.log('[Backtest] Mapped data rows:', data.length);
    if (data.length > 0) {
      console.log('[Backtest] First mapped row:', data[0]);
    }

    return {
      headers: Object.keys(data[0] || {}),
      data: data,
    };
  } catch (error) {
    console.error('[Backtest] Error parsing Excel:', error);
    // Fallback to simple parsing
    return { headers: [], data: [] };
  }
}

/**
 * Calculate robot performance metrics from trades
 */
function calculateRobotMetrics(trades: any[]) {
  const robots = new Map<string, any>();
  const accounts = new Map<string, any>();

  trades.forEach((trade) => {
    const robot = trade.robot || "Unknown";
    const account = trade.account || "Unknown";
    const pnl = trade.pnl || 0;

    // Robot metrics
    if (!robots.has(robot)) {
      robots.set(robot, {
        totalTrades: 0,
        winningTrades: 0,
        losingTrades: 0,
        totalPnl: 0,
        pnlValues: [],
        accounts: new Set<string>(),
      });
    }

    const robotMetrics = robots.get(robot)!;
    robotMetrics.totalTrades++;
    robotMetrics.totalPnl += pnl;
    robotMetrics.pnlValues.push(pnl);
    robotMetrics.accounts.add(account);

    if (pnl > 0) {
      robotMetrics.winningTrades++;
    } else if (pnl < 0) {
      robotMetrics.losingTrades++;
    }

    // Account metrics
    if (!accounts.has(account)) {
      accounts.set(account, {
        totalTrades: 0,
        winningTrades: 0,
        losingTrades: 0,
        totalPnl: 0,
        pnlValues: [],
        robots: new Set<string>(),
      });
    }

    const accountMetrics = accounts.get(account)!;
    accountMetrics.totalTrades++;
    accountMetrics.totalPnl += pnl;
    accountMetrics.pnlValues.push(pnl);
    accountMetrics.robots.add(robot);

    if (pnl > 0) {
      accountMetrics.winningTrades++;
    } else if (pnl < 0) {
      accountMetrics.losingTrades++;
    }
  });

  // Calculate additional metrics for robots
  const robotResult: any[] = [];
  robots.forEach((metrics, robot) => {
    const winRate = metrics.totalTrades > 0 ? (metrics.winningTrades / metrics.totalTrades) * 100 : 0;
    const avgPnl = metrics.totalTrades > 0 ? metrics.totalPnl / metrics.totalTrades : 0;

    // Calculate max drawdown
    let maxDrawdown = 0;
    let runningMax = 0;
    let equity = 0;
    metrics.pnlValues.forEach((pnl: number) => {
      equity += pnl;
      runningMax = Math.max(runningMax, equity);
      const drawdown = runningMax - equity;
      maxDrawdown = Math.max(maxDrawdown, drawdown);
    });

    // Calculate profit factor
    const grossProfit = metrics.pnlValues.filter((p: number) => p > 0).reduce((a: number, b: number) => a + b, 0);
    const grossLoss = Math.abs(metrics.pnlValues.filter((p: number) => p < 0).reduce((a: number, b: number) => a + b, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 999 : 0;

    robotResult.push({
      robot,
      totalTrades: metrics.totalTrades,
      winningTrades: metrics.winningTrades,
      losingTrades: metrics.losingTrades,
      winRate,
      totalPnl: metrics.totalPnl,
      avgPnlPerTrade: avgPnl,
      maxDrawdown,
      profitFactor,
      accounts: Array.from(metrics.accounts),
    });
  });

  // Calculate additional metrics for accounts
  const accountResult: any[] = [];
  accounts.forEach((metrics, account) => {
    const winRate = metrics.totalTrades > 0 ? (metrics.winningTrades / metrics.totalTrades) * 100 : 0;
    const avgPnl = metrics.totalTrades > 0 ? metrics.totalPnl / metrics.totalTrades : 0;

    // Calculate max drawdown
    let maxDrawdown = 0;
    let runningMax = 0;
    let equity = 0;
    metrics.pnlValues.forEach((pnl: number) => {
      equity += pnl;
      runningMax = Math.max(runningMax, equity);
      const drawdown = runningMax - equity;
      maxDrawdown = Math.max(maxDrawdown, drawdown);
    });

    // Calculate profit factor
    const grossProfit = metrics.pnlValues.filter((p: number) => p > 0).reduce((a: number, b: number) => a + b, 0);
    const grossLoss = Math.abs(metrics.pnlValues.filter((p: number) => p < 0).reduce((a: number, b: number) => a + b, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 999 : 0;

    accountResult.push({
      account,
      totalTrades: metrics.totalTrades,
      winningTrades: metrics.winningTrades,
      losingTrades: metrics.losingTrades,
      winRate,
      totalPnl: metrics.totalPnl,
      avgPnlPerTrade: avgPnl,
      maxDrawdown,
      profitFactor,
      robots: Array.from(metrics.robots),
    });
  });

  return { robots: robotResult, accounts: accountResult };
}

export const backtestRouter = router({
  /**
   * Get user's backtests
   */
  getUserBacktests: protectedProcedure.query(async ({ ctx }) => {
    try {
      const backtests = await getUserBacktests(ctx.user.id);
      return {
        success: true,
        data: backtests,
      };
    } catch (error) {
      console.error("[Backtest] Error fetching backtests:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        data: [],
      };
    }
  }),

  /**
   * Upload and process backtest file - SIMPLE VERSION
   * This is a simpler version that doesn't require base64 encoding
   */
  uploadFileSimple: protectedProcedure
    .input(
      z.object({
        fileName: z.string().max(255),
        fileContent: z.string(), // Raw binary as string or base64
      })
    )
    .mutation(async ({ ctx, input }: any) => {
      try {
        console.log('[Backtest] uploadFileSimple started');
        console.log('[Backtest] fileName:', input.fileName);
        console.log('[Backtest] fileContent length:', input.fileContent.length);
        
        // Decode base64 if needed
        let buffer: Buffer;
        if (input.fileContent.startsWith('data:')) {
          const base64Data = input.fileContent.split(",")[1];
          buffer = Buffer.from(base64Data, 'base64');
        } else {
          buffer = Buffer.from(input.fileContent, 'base64');
        }
        
        console.log('[Backtest] Buffer size:', buffer.length);
        
        // Parse Excel
        const parsedData = parseExcelData(buffer);
        console.log('[Backtest] Parsed data rows:', parsedData.data.length);
        
        if (parsedData.data.length === 0) {
          return {
            success: false,
            error: 'No data found in Excel file',
          };
        }
        
        // Create backtest record
        const fileKey = `backtest-${Date.now()}-${Math.random().toString(36).substring(7)}`;
        const backtestId = await createBacktestWithId({
          userId: ctx.user.id,
          fileName: input.fileName,
          fileKey: fileKey,
        });
        
        if (!backtestId) {
          return {
            success: false,
            error: 'Failed to create backtest record',
          };
        }
        
        // Save trades
        if (parsedData.data.length > 0) {
          const excelDateToJSDate = (excelDate: any) => {
            if (!excelDate) return new Date();
            if (typeof excelDate === 'number') {
              const date = new Date((excelDate - 25569) * 86400 * 1000);
              if (isNaN(date.getTime())) return new Date();
              return date;
            }
            const date = new Date(excelDate);
            if (isNaN(date.getTime())) return new Date();
            return date;
          };
          
          const tradesToSave = parsedData.data.map((trade: any) => ({
            backtestId: backtestId,
            robot: trade.robot || 'Unknown',
            entryTime: excelDateToJSDate(trade.entryTime),
            exitTime: excelDateToJSDate(trade.exitTime),
            entryPrice: String(trade.entryPrice || 0),
            exitPrice: String(trade.exitPrice || 0),
            quantity: trade.quantity || 0,
            pnl: String(trade.pnl || 0),
            direction: trade.side === 'C' ? 'long' : 'short',
            status: 'closed',
          }));
          
          try {
            await saveTrades(tradesToSave);
            console.log('[Backtest] Trades saved successfully');
          } catch (tradeError) {
            console.error('[Backtest] Error saving trades:', tradeError);
            throw tradeError;
          }
        }
        
        // Calculate metrics
        const { robots, accounts } = calculateRobotMetrics(parsedData.data);
        
        // Update status
        await updateBacktestStatus(backtestId, "completed", {
          robotCount: robots.length,
          accountCount: accounts.length,
          totalTrades: parsedData.data.length,
        });
        
        return {
          success: true,
          backtestId: backtestId,
          fileName: input.fileName,
          robotCount: robots.length,
          totalTrades: parsedData.data.length,
          message: "Backtest uploaded and processed successfully",
        };
      } catch (error) {
        console.error('[Backtest] uploadFileSimple error:', error);
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  /**
   * Upload and process backtest file
   */
  uploadFile: protectedProcedure
    .input(
      z.object({
        fileName: z.string().max(255),
        fileData: z.string().max(100 * 1024 * 1024), // 100MB limit
        fileSize: z.number().positive(),
      })
    )
    .mutation(async ({ ctx, input }: any) => {
      try {
        console.log('[Backtest] uploadFile mutation started');
        console.log('[Backtest] Input fileName:', input.fileName);
        console.log('[Backtest] Input fileSize:', input.fileSize);
        console.log('[Backtest] Input fileData length:', input.fileData.length);
        
        // Upload file to S3
        const fileKey = `backtest/${ctx.user.id}/${nanoid()}-${input.fileName}`;
        const buffer = Buffer.from(input.fileData.split(",")[1] || input.fileData, "base64");
        console.log('[Backtest] Buffer created, size:', buffer.length);

        const { url } = await storagePut(fileKey, buffer, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

        // Create backtest record
        const backtestId = await createBacktestWithId({
          userId: ctx.user.id,
          fileName: input.fileName,
          fileKey: fileKey,
        });

        if (!backtestId) {
          throw new Error("Failed to create backtest record");
        }

        // Parse and process file data
        console.log('[Backtest] Parsing Excel data...');
        const parsedData = parseExcelData(input.fileData);
        console.log('[Backtest] Parsed data - headers:', parsedData.headers.length, 'rows:', parsedData.data.length);

        // Update status to processing
        await updateBacktestStatus(backtestId, "processing");

        // Calculate metrics
        console.log('[Backtest] Calculating robot metrics...');
        const { robots, accounts } = calculateRobotMetrics(parsedData.data);
        console.log('[Backtest] Metrics calculated - robots:', robots.length, 'accounts:', accounts.length);

        // Save robot performance
        for (const metric of robots) {
          await saveRobotPerformance({
            backtestId: backtestId,
            robot: metric.robot,
            totalTrades: metric.totalTrades,
            winningTrades: metric.winningTrades,
            losingTrades: metric.losingTrades,
            winRate: metric.winRate,
            totalPnl: metric.totalPnl,
            avgPnlPerTrade: metric.avgPnlPerTrade,
            maxDrawdown: metric.maxDrawdown,
            profitFactor: metric.profitFactor,
          });
        }

        // Save trades
        if (parsedData.data.length > 0) {
          // Helper to convert Excel serial dates to JS Date
          const excelDateToJSDate = (excelDate: any) => {
            if (!excelDate) {
              return new Date(); // Use current date as fallback
            }
            if (typeof excelDate === 'number') {
              // Excel serial date: days since 1900-01-01 (with leap year bug)
              const date = new Date((excelDate - 25569) * 86400 * 1000);
              if (isNaN(date.getTime())) {
                return new Date(); // Fallback if date is invalid
              }
              return date;
            }
            const date = new Date(excelDate);
            if (isNaN(date.getTime())) {
              return new Date(); // Fallback if date is invalid
            }
            return date;
          };

          console.log('[Backtest] Saving', parsedData.data.length, 'trades...');
          const tradesToSave = parsedData.data.map((trade: any) => {
            const entryPrice = trade.entryPrice ? String(trade.entryPrice) : '0';
            const exitPrice = trade.exitPrice ? String(trade.exitPrice) : '0';
            const pnl = trade.pnl ? String(trade.pnl) : '0';
            
            return {
              backtestId: backtestId,
              robot: trade.robot,
              entryTime: excelDateToJSDate(trade.entryTime),
              exitTime: excelDateToJSDate(trade.exitTime),
              entryPrice: entryPrice,
              exitPrice: exitPrice,
              quantity: trade.quantity || 0,
              pnl: pnl,
              direction: trade.side === 'C' ? 'long' : 'short',
              status: 'closed',
            };
          });
          
          console.log('[Backtest] First trade to save:', tradesToSave[0]);
          try {
            await saveTrades(tradesToSave);
            console.log('[Backtest] Trades saved successfully');
          } catch (tradeError) {
            console.error('[Backtest] Error saving trades:', tradeError);
            if (tradeError instanceof Error) {
              console.error('[Backtest] Trade error message:', tradeError.message);
              console.error('[Backtest] Trade error stack:', tradeError.stack);
            }
            throw tradeError;
          }
        }

        // Update status to completed
        await updateBacktestStatus(backtestId, "completed", {
          robotCount: robots.length,
          accountCount: accounts.length,
          totalTrades: parsedData.data.length,
          fileSize: input.fileSize,
        });

        return {
          success: true,
          backtestId: backtestId,
          fileName: input.fileName,
          fileUrl: url,
          robotCount: robots.length,
          accountCount: accounts.length,
          totalTrades: parsedData.data.length,
          message: "Backtest enviado e processado com sucesso",
        };
      } catch (error) {
        console.error("[Backtest] Error uploading file:", error);
        console.error("[Backtest] Error stack:", error instanceof Error ? error.stack : 'No stack');
        console.error("[Backtest] Error type:", typeof error);
        console.error("[Backtest] Error keys:", Object.keys(error || {}));
        
        // Log full error details
        if (error instanceof Error) {
          console.error("[Backtest] Error message:", error.message);
          console.error("[Backtest] Error name:", error.name);
        }
        
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Get backtest robot performance
   */
  getRobotPerformance: protectedProcedure
    .input(z.object({ backtestId: z.number() }))
    .query(async ({ input }) => {
      try {
        const performance = await getBacktestRobotPerformance(input.backtestId);
        return {
          success: true,
          data: performance,
        };
      } catch (error) {
        console.error("[Backtest] Error fetching robot performance:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
          data: [],
        };
      }
    }),

  /**
   * Get backtest trades
   */
  getTrades: protectedProcedure
    .input(z.object({ backtestId: z.number() }))
    .query(async ({ input }) => {
      try {
        const trades = await getBacktestTrades(input.backtestId);
        return {
          success: true,
          data: trades,
        };
      } catch (error) {
        console.error("[Backtest] Error fetching trades:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
          data: [],
        };
      }
    }),
});
