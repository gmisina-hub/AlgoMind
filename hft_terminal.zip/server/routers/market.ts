import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { getLatestMarketSnapshot, saveMarketSnapshot, getUserBacktests, getBacktestRobotPerformance, getBacktestTrades } from "../db.market";

const DDE_API_URL = process.env.DDE_API_URL || "http://127.0.0.1:5000";

/**
 * Market data router - handles real-time market data from DDE
 */
export const marketRouter = router({
  /**
   * Get latest market snapshot for a symbol
   */
  getLatestSnapshot: publicProcedure
    .input(z.object({ symbol: z.string() }))
    .query(async ({ input }) => {
      try {
        const snapshot = await getLatestMarketSnapshot(input.symbol);
        if (snapshot) {
          return snapshot;
        }

        // If no cached data, try to fetch from DDE API
        const response = await fetch(`${DDE_API_URL}/prices`);
        if (!response.ok) {
          return null;
        }

        const data = await response.json();
        
        // Save to database for caching
        if (data.marketSnapshot) {
          await saveMarketSnapshot({
            ...data.marketSnapshot,
            timestamp: new Date(data.marketSnapshot.timestamp || new Date()),
          });
        }

        return data.marketSnapshot || null;
      } catch (error) {
        console.error("[Market] Error fetching snapshot:", error);
        return null;
      }
    }),

  /**
   * Get real-time DDE data
   */
  getDDEData: publicProcedure.query(async () => {
    try {
      const response = await fetch(`${DDE_API_URL}/prices`);
      if (!response.ok) {
        throw new Error("Failed to fetch DDE data");
      }

      const data = await response.json();

      // Save snapshot to database
      if (data.marketSnapshot) {
        await saveMarketSnapshot({
          ...data.marketSnapshot,
          timestamp: new Date(data.marketSnapshot.timestamp || new Date()),
        });
      }

      return {
        success: true,
        data: {
          marketSnapshot: data.marketSnapshot,
          lastPrice: data.lastPrice,
          insightMain: data.insightMain,
          insightSecondary: data.insightSecondary,
          marketPressure: data.marketPressure,
          volatilityScore: data.volatilityScore,
          volatilityLevel: data.volatilityLevel,
          priceTrend: data.priceTrend,
        },
      };
    } catch (error) {
      console.error("[Market] Error fetching DDE data:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }),
});

/**
 * Backtest router - handles backtest data and analysis
 */
export const backtestRouter = router({
  /**
   * Get user's backtests
   */
  getUserBacktests: protectedProcedure.query(async ({ ctx }) => {
    try {
      const backtests = await getUserBacktests(ctx.user.id);
      return {
        success: true,
        data: backtests,
      };
    } catch (error) {
      console.error("[Backtest] Error fetching backtests:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        data: [],
      };
    }
  }),

  /**
   * Get robot performance for a backtest
   */
  getRobotPerformance: protectedProcedure
    .input(z.object({ backtestId: z.number() }))
    .query(async ({ input }) => {
      try {
        const performance = await getBacktestRobotPerformance(input.backtestId);
        return {
          success: true,
          data: performance,
        };
      } catch (error) {
        console.error("[Backtest] Error fetching robot performance:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
          data: [],
        };
      }
    }),

  /**
   * Get trades for a backtest
   */
  getTrades: protectedProcedure
    .input(z.object({ backtestId: z.number(), robot: z.string().optional() }))
    .query(async ({ input }) => {
      try {
        const trades = await getBacktestTrades(input.backtestId, input.robot);
        return {
          success: true,
          data: trades,
        };
      } catch (error) {
        console.error("[Backtest] Error fetching trades:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
          data: [],
        };
      }
    }),
});
