/**
 * server/routers/dashboard.ts
 * tRPC router for main dashboard data
 */

import { router, publicProcedure } from "../_core/trpc";
import { z } from "zod";
import {
  getBrazilianMarketData,
  getInternationalIndices,
  getForexPairs,
  getCommodities,
  getADRs,
  getTopBrazilianStocks,
  calculateFairPrice,
  calculateProbabilities,
} from "../market-service";
import { insertIntradayTick, getIntradayTicks } from "../db";
import { startIntradayPolling, stopIntradayPolling, isIntradayPollingActive } from "../intraday-polling";
import { calculateProprietaryMetrics } from "../proprietary-metrics";
import { calculateTechnicalIndicators, calculateLinearRegression } from "../technical-indicators";
import { getB3MarketParams } from "../b3-service";
import { checkAllAlerts, type Alert } from "../alert-system";
import { volumeProfileService } from "../volume-profile";
import { macroCascadeService } from "../macro-cascade";
import { darkPoolDetectorService } from "../dark-pool-detector";
import { aiTradingAssistantService } from "../ai-trading-assistant";
import { getLatestRecommendations, calculateAIKPIs } from "../db-ai-history";

export const dashboardRouter = router({
  /**
   * Get all dashboard data (aggregated)
   */
  getAllData: publicProcedure.query(async () => {
    try {
      const [
        brazilianData,
        indices,
        forex,
        commodities,
        adrs,
        brazilianStocks,
      ] = await Promise.all([
        getBrazilianMarketData(),
        getInternationalIndices(),
        getForexPairs(),
        getCommodities(),
        getADRs(),
        getTopBrazilianStocks(),
      ]);

      // Calculate Fair Price and Probabilities for WINFUT
      let fairPriceIndice = null;
      let probabilitiesIndice = null;
      let proprietaryMetrics = null;
      let technicalIndicators = null;
      if (brazilianData.winfut) {
        fairPriceIndice = calculateFairPrice({
          open: brazilianData.winfut.open || 0,
          high: brazilianData.winfut.high || 0,
          low: brazilianData.winfut.low || 0,
          close: brazilianData.winfut.close || 0,
          last: brazilianData.winfut.last || 0,
        });

        probabilitiesIndice = calculateProbabilities({
          last: brazilianData.winfut.last || 0,
          open: brazilianData.winfut.open || 0,
          high: brazilianData.winfut.high || 0,
          low: brazilianData.winfut.low || 0,
          close: brazilianData.winfut.close || 0,
          varPct: brazilianData.winfut.varPct || 0,
        });

        // Calculate Proprietary Metrics
        proprietaryMetrics = calculateProprietaryMetrics({
          last: brazilianData.winfut.last || 0,
          vwap: brazilianData.winfut.vwap || 0,
          trueRange: brazilianData.winfut.trueRange || 0,
          accumBalance: brazilianData.winfut.accumBalance || 0,
          volume: brazilianData.winfut.volume || 0,
          rsi: brazilianData.winfut.rsi || 50,
        });

        // Calculate Technical Indicators (Fair Value, Pivot Points, Fibonacci)
        // Use IBOV real from DDE as spot index
        const futurePrice = brazilianData.winfut.last || 0;
        const b3Params = await getB3MarketParams();
        const diRate = b3Params.diRate;
        const daysToExpiry = b3Params.daysToExpiry;
        
        // Use IBOV real from DDE (otherAssets.IBOV)
        const ibovSpot = (brazilianData as any).otherAssets?.IBOV || 0;
        // If IBOV not available, estimate from WINFUT
        const spotIndex = ibovSpot > 0 ? ibovSpot : futurePrice / (1 + (diRate * daysToExpiry) / 252);
        
        technicalIndicators = calculateTechnicalIndicators({
          spotIndex,
          futurePrice: brazilianData.winfut.last || 0,
          high: brazilianData.winfut.high || 0,
          low: brazilianData.winfut.low || 0,
          close: brazilianData.winfut.close || brazilianData.winfut.last || 0,
          diRate,
          daysToExpiry,
        });
        
        // Calculate Linear Regression projection using real intraday ticks
        const now = new Date();
        const startOfDay = new Date(now);
        startOfDay.setHours(0, 0, 0, 0);
        
        // Get all ticks from today
        const allTicks = await getIntradayTicks("WINFUT", startOfDay);
        
        // Filter ticks based on time window (for chart display)
        // This will be used by frontend to filter data
        const intradayTicks = allTicks;
        
        let linearRegression;
        if (intradayTicks.length >= 10) {
          // Use real historical prices from database
          const historicalPrices = intradayTicks
            .map(tick => tick.last)
            .filter((price): price is string => price !== null)
            .map(price => parseFloat(price))
            .filter(price => isFinite(price)); // Filtrar NaN e Infinity
          linearRegression = calculateLinearRegression(historicalPrices, 10);
        } else {
          // Fallback to mock data if not enough real data
          const mockHistoricalPrices = Array.from({ length: 30 }, (_, i) => 
            (brazilianData.winfut.last || 0) + Math.sin(i / 5) * 200 + (Math.random() - 0.5) * 100
          );
          linearRegression = calculateLinearRegression(mockHistoricalPrices, 10);
        }
        
        // Check for alerts (compare current price with previous tick)
        let alerts: Alert[] = [];
        if (intradayTicks.length >= 2) {
          const previousPrice = parseFloat(intradayTicks[intradayTicks.length - 2].last || "0");
          // Validar que previousPrice é um número válido
          if (!isFinite(previousPrice)) {
            console.error("[Dashboard] Invalid previousPrice:", previousPrice);
            alerts = [];
          } else {
            const currentPrice = brazilianData.winfut.last || 0;
            alerts = await checkAllAlerts(currentPrice, previousPrice, technicalIndicators);
          }
        }
        
        technicalIndicators = {
          ...technicalIndicators,
          linearRegression,
          config: { diRate, daysToExpiry },
          alerts,
        };
      }

      // Calculate Fair Price and Probabilities for USD/BRL
      let fairPriceDolar = null;
      let probabilitiesDolar = null;
      const usdBrl = forex["BRLUSD=X"];
      if (usdBrl) {
        fairPriceDolar = calculateFairPrice({
          open: usdBrl.open || 0,
          high: usdBrl.high || 0,
          low: usdBrl.low || 0,
          close: usdBrl.close || 0,
          last: usdBrl.last || 0,
        });

        probabilitiesDolar = calculateProbabilities({
          last: usdBrl.last || 0,
          open: usdBrl.open || 0,
          high: usdBrl.high || 0,
          low: usdBrl.low || 0,
          close: usdBrl.close || 0,
          varPct: usdBrl.varPct || 0,
        });
      }

      return {
        brazilian: brazilianData,
        indices,
        forex,
        commodities,
        adrs,
        brazilianStocks,
        fairPrice: {
          indice: fairPriceIndice,
          dolar: fairPriceDolar,
        },
        probabilities: {
          indice: probabilitiesIndice,
          dolar: probabilitiesDolar,
        },
        proprietaryMetrics,
        technicalIndicators,
        lastUpdate: new Date().toISOString(),
      };
    } catch (error) {
      console.error("[Dashboard] Error fetching data:", error);
      throw new Error("Failed to fetch dashboard data");
    }
  }),

  /**
   * Get Brazilian market data only (Profit DDE)
   */
  getBrazilianData: publicProcedure.query(async () => {
    try {
      return await getBrazilianMarketData();
    } catch (error) {
      console.error("[Dashboard] Error fetching Brazilian data:", error);
      throw new Error("Failed to fetch Brazilian market data");
    }
  }),

  /**
   * Get international indices
   */
  getIndices: publicProcedure.query(async () => {
    try {
      return await getInternationalIndices();
    } catch (error) {
      console.error("[Dashboard] Error fetching indices:", error);
      throw new Error("Failed to fetch international indices");
    }
  }),

  /**
   * Get forex pairs
   */
  getForex: publicProcedure.query(async () => {
    try {
      return await getForexPairs();
    } catch (error) {
      console.error("[Dashboard] Error fetching forex:", error);
      throw new Error("Failed to fetch forex pairs");
    }
  }),

  /**
   * Get commodities
   */
  getCommodities: publicProcedure.query(async () => {
    try {
      return await getCommodities();
    } catch (error) {
      console.error("[Dashboard] Error fetching commodities:", error);
      throw new Error("Failed to fetch commodities");
    }
  }),

  /**
   * Get ADRs
   */
  getADRs: publicProcedure.query(async () => {
    try {
      return await getADRs();
    } catch (error) {
      console.error("[Dashboard] Error fetching ADRs:", error);
      throw new Error("Failed to fetch ADRs");
    }
  }),

  /**
   * Get top Brazilian stocks
   */
  getBrazilianStocks: publicProcedure.query(async () => {
    try {
      return await getTopBrazilianStocks();
    } catch (error) {
      console.error("[Dashboard] Error fetching Brazilian stocks:", error);
      throw new Error("Failed to fetch Brazilian stocks");
    }
  }),

  /**
   * Save intraday tick to database
   */
  saveIntradayTick: publicProcedure
    .input(
      z.object({
        symbol: z.string(),
        timestamp: z.date(),
        last: z.number().optional(),
        open: z.number().optional(),
        high: z.number().optional(),
        low: z.number().optional(),
        close: z.number().optional(),
        varPts: z.number().optional(),
        varPct: z.number().optional(),
        volume: z.number().optional(),
        rsi: z.number().optional(),
        vwap: z.number().optional(),
        vwapMonthly: z.number().optional(),
        trueRange: z.number().optional(),
        accumBalance: z.number().optional(),
        adjust: z.number().optional(),
        hilo: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        await insertIntradayTick({
          symbol: input.symbol,
          timestamp: input.timestamp,
          last: input.last?.toString(),
          open: input.open?.toString(),
          high: input.high?.toString(),
          low: input.low?.toString(),
          close: input.close?.toString(),
          varPts: input.varPts?.toString(),
          varPct: input.varPct?.toString(),
          volume: input.volume?.toString(),
          rsi: input.rsi?.toString(),
          vwap: input.vwap?.toString(),
          vwapMonthly: input.vwapMonthly?.toString(),
          trueRange: input.trueRange?.toString(),
          accumBalance: input.accumBalance?.toString(),
          adjust: input.adjust?.toString(),
          hilo: input.hilo?.toString(),
        });
        return { success: true };
      } catch (error) {
        console.error("[Dashboard] Error saving intraday tick:", error);
        throw new Error("Failed to save intraday tick");
      }
    }),

  /**
   * Get intraday ticks for a symbol on a specific date
   */
  getIntradayTicks: publicProcedure
    .input(
      z.object({
        symbol: z.string(),
        date: z.string(), // ISO date string
      })
    )
    .query(async ({ input }) => {
      try {
        const date = new Date(input.date);
        const ticks = await getIntradayTicks(input.symbol, date);
        
        // Convert decimal strings back to numbers for frontend
        return ticks.map((tick) => ({
          ...tick,
          last: tick.last ? parseFloat(tick.last) : null,
          open: tick.open ? parseFloat(tick.open) : null,
          high: tick.high ? parseFloat(tick.high) : null,
          low: tick.low ? parseFloat(tick.low) : null,
          close: tick.close ? parseFloat(tick.close) : null,
          varPts: tick.varPts ? parseFloat(tick.varPts) : null,
          varPct: tick.varPct ? parseFloat(tick.varPct) : null,
          volume: tick.volume ? parseFloat(tick.volume) : null,
          rsi: tick.rsi ? parseFloat(tick.rsi) : null,
          vwap: tick.vwap ? parseFloat(tick.vwap) : null,
          vwapMonthly: tick.vwapMonthly ? parseFloat(tick.vwapMonthly) : null,
          trueRange: tick.trueRange ? parseFloat(tick.trueRange) : null,
          accumBalance: tick.accumBalance ? parseFloat(tick.accumBalance) : null,
          adjust: tick.adjust ? parseFloat(tick.adjust) : null,
          hilo: tick.hilo ? parseFloat(tick.hilo) : null,
        }));
      } catch (error) {
        console.error("[Dashboard] Error fetching intraday ticks:", error);
        throw new Error("Failed to fetch intraday ticks");
      }
    }),

  /**
   * Start intraday polling (save ticks to database automatically)
   */
  startPolling: publicProcedure
    .input(
      z.object({
        intervalSeconds: z.number().min(2).max(60).optional().default(10),
      })
    )
    .mutation(async ({ input }) => {
      try {
        startIntradayPolling(input.intervalSeconds);
        return { success: true, message: `Polling started with ${input.intervalSeconds}s interval` };
      } catch (error) {
        console.error("[Dashboard] Error starting polling:", error);
        throw new Error("Failed to start polling");
      }
    }),

  /**
   * Stop intraday polling
   */
  stopPolling: publicProcedure.mutation(async () => {
    try {
      stopIntradayPolling();
      return { success: true, message: "Polling stopped" };
    } catch (error) {
      console.error("[Dashboard] Error stopping polling:", error);
      throw new Error("Failed to stop polling");
    }
  }),

  /**
   * Get tick count from today
   */
  getTickCount: publicProcedure.query(async () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const ticks = await getIntradayTicks("WINFUT", today);
    return ticks.length;
  }),
  
  /**
   * Get polling status
   */
  getPollingStatus: publicProcedure.query(() => {
    return { active: isIntradayPollingActive() };
  }),
  
  /**
   * Get intraday ticks for chart (filtered by time period)
   */
  getIntradayTicksForChart: publicProcedure
    .input(
      z.object({
        periodMinutes: z.number().min(2).max(540).optional().default(540), // Default: full day (9h)
      })
    )
    .query(async ({ input }) => {
      const now = new Date();
      const startTime = new Date(now.getTime() - input.periodMinutes * 60 * 1000);
      
      const ticks = await getIntradayTicks("WINFUT", startTime);
      
      return ticks.map(tick => ({
        timestamp: tick.timestamp,
        last: parseFloat(tick.last || "0"),
        volume: parseFloat(tick.volume || "0"),
      }));
    }),

  /**
   * Get Volume Profile (POC, HVN, LVN)
   */
  getVolumeProfile: publicProcedure.query(() => {
    try {
      const profile = volumeProfileService.calculateVolumeProfile();
      const stats = volumeProfileService.getBufferStats();
      
      return {
        profile,
        bufferStats: stats,
      };
    } catch (error) {
      console.error("[Dashboard] Error calculating Volume Profile:", error);
      throw new Error("Failed to calculate Volume Profile");
    }
  }),

  /**
   * Get distance to POC (Point of Control)
   */
  getDistanceToPOC: publicProcedure
    .input(z.object({ currentPrice: z.number() }))
    .query(({ input }) => {
      try {
        const distance = volumeProfileService.getDistanceToPOC(input.currentPrice);
        return { distance };
      } catch (error) {
        console.error("[Dashboard] Error calculating distance to POC:", error);
        throw new Error("Failed to calculate distance to POC");
      }
    }),

  /**
   * Get Macro Cascade (VIX, DXY, S&P500, 10Y Treasury + signals)
   */
  getMacroCascade: publicProcedure.query(async () => {
    try {
      const data = await macroCascadeService.getMacroCascade();
      return data;
    } catch (error) {
      console.error("[Dashboard] Error fetching Macro Cascade:", error);
      throw new Error("Failed to fetch Macro Cascade");
    }
  }),

  /**
   * Detect Dark Pool activity (institutional volume spikes)
   */
  detectDarkPool: publicProcedure
    .input(
      z.object({
        currentVolume: z.number(),
        currentPrice: z.number(),
        vwap: z.number(),
      })
    )
    .query(({ input }) => {
      try {
        const detection = darkPoolDetectorService.detectDarkPool(
          input.currentVolume,
          input.currentPrice,
          input.vwap
        );
        const stats = darkPoolDetectorService.getVolumeStats();
        return { detection, stats };
      } catch (error) {
        console.error("[Dashboard] Error detecting dark pool:", error);
        throw new Error("Failed to detect dark pool");
      }
    }),

  /**
   * Get AI Trading Recommendation (contextual analysis)
   */
  getAIRecommendation: publicProcedure
    .input(
      z.object({
        context: z.object({
          currentPrice: z.number(),
          varPts: z.number(),
          varPct: z.number(),
          volume: z.number(),
          rsi: z.number(),
          vwap: z.number(),
          trueRange: z.number(),
          accumBalance: z.number(),
          fibonacci: z.object({
            level_0: z.number(),
            level_236: z.number(),
            level_382: z.number(),
            level_50: z.number(),
            level_618: z.number(),
            level_100: z.number(),
          }),
          pivotPoints: z.object({
            r2: z.number(),
            r1: z.number(),
            pp: z.number(),
            s1: z.number(),
            s2: z.number(),
          }),
          volumeProfile: z.object({
            poc: z.number(),
            distanceToPOC: z.number(),
          }).nullable(),
          darkPool: z.object({
            detected: z.boolean(),
            direction: z.enum(["BUY", "SELL", "NEUTRAL"]),
            confidence: z.number(),
          }).nullable(),
          macro: z.object({
            vixChange: z.number(),
            dxyChange: z.number(),
            sp500Change: z.number(),
            overallSignal: z.enum(["BULLISH", "BEARISH", "NEUTRAL"]),
            confidence: z.number(),
          }).nullable(),
        }),
      })
    )
    .query(async ({ input }) => {
      try {
        const recommendation = await aiTradingAssistantService.generateRecommendation(input.context);
        return recommendation;
      } catch (error) {
        console.error("[Dashboard] Error generating AI recommendation:", error);
        throw new Error("Failed to generate AI recommendation");
      }
    }),

  /**
   * Get AI recommendations history
   */
  getAIHistory: publicProcedure
    .input(
      z.object({
        limit: z.number().optional().default(50),
      })
    )
    .query(async ({ input }) => {
      try {
        const recommendations = await getLatestRecommendations(input.limit);
        return recommendations;
      } catch (error) {
        console.error("[Dashboard] Error fetching AI history:", error);
        throw new Error("Failed to fetch AI history");
      }
    }),

  /**
   * Get AI KPIs (backtest metrics)
   */
  getAIKPIs: publicProcedure.query(async () => {
    try {
      const kpis = await calculateAIKPIs();
      return kpis;
    } catch (error) {
      console.error("[Dashboard] Error calculating AI KPIs:", error);
      throw new Error("Failed to calculate AI KPIs");
    }
  }),
});
