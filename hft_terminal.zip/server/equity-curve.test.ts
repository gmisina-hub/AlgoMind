import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("Equity Curve Analysis", () => {
  describe("getTrades for equity curve", () => {
    it("should return trades with required fields", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      expect(result).toBeDefined();
      expect(result).toHaveProperty("success");
      expect(Array.isArray(result.data)).toBe(true);

      if (result.data.length > 0) {
        const trade = result.data[0];
        expect(trade).toHaveProperty("pnl");
        expect(trade).toHaveProperty("entryTime");
        expect(trade).toHaveProperty("exitTime");
      }
    });

    it("should calculate cumulative equity correctly", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        let cumulativeEquity = 0;
        result.data.forEach((trade: any) => {
          const pnl = parseFloat(trade.pnl) || 0;
          cumulativeEquity += pnl;
          expect(typeof cumulativeEquity).toBe("number");
        });
      }
    });

    it("should handle empty trades gracefully", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 999 });

      expect(result.success).toBe(true);
      expect(result.data).toEqual([]);
    });
  });

  describe("Risk Metrics Calculation", () => {
    it("should calculate max drawdown correctly", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        let maxEquity = 0;
        let maxDrawdown = 0;
        let currentEquity = 0;

        result.data.forEach((trade: any) => {
          const pnl = parseFloat(trade.pnl) || 0;
          currentEquity += pnl;
          maxEquity = Math.max(maxEquity, currentEquity);

          if (maxEquity > 0) {
            const drawdown = ((currentEquity - maxEquity) / maxEquity) * 100;
            maxDrawdown = Math.min(maxDrawdown, drawdown);
          }
        });

        expect(typeof maxDrawdown).toBe("number");
        expect(maxDrawdown).toBeLessThanOrEqual(0);
      }
    });

    it("should calculate win rate from trades", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const winningTrades = result.data.filter((t: any) => parseFloat(t.pnl) > 0).length;
        const totalTrades = result.data.length;
        const winRate = (winningTrades / totalTrades) * 100;

        expect(winRate).toBeGreaterThanOrEqual(0);
        expect(winRate).toBeLessThanOrEqual(100);
      }
    });

    it("should calculate Sharpe ratio components", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const returns = result.data.map((t: any) => parseFloat(t.pnl) || 0);
        const avgReturn = returns.reduce((sum: number, r: number) => sum + r, 0) / returns.length;
        const variance = returns.reduce((sum: number, r: number) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length;
        const stdDev = Math.sqrt(variance);

        expect(typeof avgReturn).toBe("number");
        expect(typeof stdDev).toBe("number");
        expect(stdDev).toBeGreaterThanOrEqual(0);
      }
    });

    it("should calculate profit factor", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const returns = result.data.map((t: any) => parseFloat(t.pnl) || 0);
        const grossProfit = returns.filter((r: number) => r > 0).reduce((sum: number, r: number) => sum + r, 0);
        const grossLoss = Math.abs(returns.filter((r: number) => r < 0).reduce((sum: number, r: number) => sum + r, 0));
        const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 999 : 0;

        expect(typeof profitFactor).toBe("number");
        expect(profitFactor).toBeGreaterThanOrEqual(0);
      }
    });
  });

  describe("Trade Distribution Analysis", () => {
    it("should categorize trades by P&L buckets", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const distribution: { [key: number]: number } = {};

        result.data.forEach((trade: any) => {
          const pnl = parseFloat(trade.pnl) || 0;
          const bucket = Math.floor(pnl / 100) * 100;
          distribution[bucket] = (distribution[bucket] || 0) + 1;
        });

        expect(Object.keys(distribution).length).toBeGreaterThan(0);
        Object.values(distribution).forEach((count: number) => {
          expect(count).toBeGreaterThan(0);
        });
      }
    });
  });

  describe("Equity Curve Consistency", () => {
    it("should maintain consistent equity curve across calls", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result1 = await caller.backtest.getTrades({ backtestId: 1 });
      const result2 = await caller.backtest.getTrades({ backtestId: 1 });

      expect(result1.data).toEqual(result2.data);
    });

    it("should handle robot-specific equity curves", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({
        backtestId: 1,
        robot: "TestRobot",
      });

      expect(result.success).toBe(true);
      expect(Array.isArray(result.data)).toBe(true);

      if (result.data.length > 0) {
        result.data.forEach((trade: any) => {
          expect(trade.robot).toBe("TestRobot");
        });
      }
    });
  });

  describe("Edge Cases", () => {
    it("should handle trades with zero P&L", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const zeroPnlTrades = result.data.filter((t: any) => parseFloat(t.pnl) === 0);
        // Should not crash with zero P&L trades
        expect(Array.isArray(zeroPnlTrades)).toBe(true);
      }
    });

    it("should handle negative P&L correctly", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const negativePnlTrades = result.data.filter((t: any) => parseFloat(t.pnl) < 0);
        negativePnlTrades.forEach((trade: any) => {
          expect(parseFloat(trade.pnl)).toBeLessThan(0);
        });
      }
    });

    it("should handle very large P&L values", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        result.data.forEach((trade: any) => {
          const pnl = parseFloat(trade.pnl);
          expect(isNaN(pnl)).toBe(false);
          expect(isFinite(pnl)).toBe(true);
        });
      }
    });
  });
});
