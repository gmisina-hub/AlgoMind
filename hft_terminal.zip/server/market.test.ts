import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("Market Router", () => {
  it("should get latest market snapshot", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    const result = await caller.market.getDDEData();

    expect(result).toBeDefined();
    expect(result.success).toBeDefined();
    expect(typeof result.success).toBe("boolean");
  });

  it("should get snapshot for specific symbol", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    const result = await caller.market.getLatestSnapshot({ symbol: "WINFUT" });

    // Result can be null if no data in DB, but should not throw
    expect(result === null || typeof result === "object").toBe(true);
  });
});

describe("Backtest Router", () => {
  it("should get user backtests", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.backtest.getUserBacktests();

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
    expect(Array.isArray(result.data)).toBe(true);
  });

  it("should get robot performance for backtest", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
    expect(Array.isArray(result.data)).toBe(true);
  });

  it("should get trades for backtest", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.backtest.getTrades({ backtestId: 1 });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
    expect(Array.isArray(result.data)).toBe(true);
  });

  it("should get trades for specific robot", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.backtest.getTrades({
      backtestId: 1,
      robot: "TestRobot",
    });

    expect(result).toBeDefined();
    expect(result.success).toBe(true);
    expect(Array.isArray(result.data)).toBe(true);
  });
});
