/**
 * server/intraday-polling.ts
 * Automatic polling service to save DDE ticks to database
 */

import { getBrazilianMarketData } from "./market-service";
import { insertIntradayTick } from "./db";
import { volumeProfileService } from "./volume-profile";
import { darkPoolDetectorService } from "./dark-pool-detector";

let pollingInterval: NodeJS.Timeout | null = null;
let isPolling = false;

/**
 * Start automatic polling to save intraday ticks
 * @param intervalSeconds - Interval in seconds between each poll (default: 10)
 */
export function startIntradayPolling(intervalSeconds: number = 10) {
  if (isPolling) {
    console.log("[Intraday Polling] Already running");
    return;
  }

  console.log(`[Intraday Polling] Starting with ${intervalSeconds}s interval`);
  isPolling = true;

  // Poll immediately on start
  pollAndSave();

  // Then poll at regular intervals
  pollingInterval = setInterval(() => {
    pollAndSave();
  }, intervalSeconds * 1000);
}

/**
 * Stop automatic polling
 */
export function stopIntradayPolling() {
  if (!isPolling) {
    console.log("[Intraday Polling] Not running");
    return;
  }

  console.log("[Intraday Polling] Stopping");
  isPolling = false;

  if (pollingInterval) {
    clearInterval(pollingInterval);
    pollingInterval = null;
  }
}

/**
 * Check if polling is currently active
 */
export function isIntradayPollingActive(): boolean {
  return isPolling;
}

/**
 * Poll DDE and save tick to database
 */
async function pollAndSave() {
  try {
    const data = await getBrazilianMarketData();

    // Save WINFUT tick if available
    if (data.winfut) {
      await insertIntradayTick({
        symbol: "WINFUT",
        timestamp: new Date(),
        last: data.winfut.last?.toString(),
        open: data.winfut.open?.toString(),
        high: data.winfut.high?.toString(),
        low: data.winfut.low?.toString(),
        close: data.winfut.close?.toString(),
        varPts: data.winfut.varPts?.toString(),
        varPct: data.winfut.varPct?.toString(),
        volume: data.winfut.volume?.toString(),
        rsi: data.winfut.rsi?.toString(),
        vwap: data.winfut.vwap?.toString(),
        vwapMonthly: data.winfut.vwapMonthly?.toString(),
        trueRange: data.winfut.trueRange?.toString(),
        accumBalance: data.winfut.accumBalance?.toString(),
        adjust: data.winfut.adjust?.toString(),
        hilo: data.winfut.hilo?.toString(),
      });

      console.log(`[Intraday Polling] Saved WINFUT tick: ${data.winfut.last} pts`);

      // Adicionar tick ao Volume Profile Service (em memória)
      volumeProfileService.addTick({
        price: data.winfut.last || 0,
        volume: data.winfut.volume || 0,
        timestamp: Date.now(),
      });

      // Adicionar tick ao Dark Pool Detector (em memória)
      darkPoolDetectorService.addTick(
        data.winfut.volume || 0,
        data.winfut.last || 0
      );
    }

    // TODO: Add more symbols here (DOLFUT, INDFUT, etc.)
  } catch (error) {
    console.error("[Intraday Polling] Error polling and saving:", error);
  }
}
