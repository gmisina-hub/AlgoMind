/**
 * Macro Cascade Service
 * 
 * Monitora indicadores macro (VIX, DXY, S&P500, 10Y Treasury) via Alpha Vantage API
 * e calcula correlações dinâmicas com WINFUT para detectar lead-lag relationships.
 * 
 * Lead-lag estimado:
 * - VIX → S&P500 → WINFUT (delay 2-10 min)
 * - DXY → WINFUT (delay 30-60 min)
 * - 10Y Treasury → WINFUT (delay 1-3 horas)
 * 
 * Alpha Vantage API:
 * - Free tier: 500 calls/day, 5 calls/minute
 * - Endpoint: GLOBAL_QUOTE
 */

interface MacroIndicator {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  timestamp: number;
}

interface MacroCascadeData {
  vix: MacroIndicator | null;
  dxy: MacroIndicator | null;
  sp500: MacroIndicator | null;
  treasury10y: MacroIndicator | null;
  correlations: {
    vixWinfut: number | null;
    dxyWinfut: number | null;
    sp500Winfut: number | null;
  };
  signals: {
    vixSignal: "BULLISH" | "BEARISH" | "NEUTRAL";
    dxySignal: "BULLISH" | "BEARISH" | "NEUTRAL";
    sp500Signal: "BULLISH" | "BEARISH" | "NEUTRAL";
    overallSignal: "BULLISH" | "BEARISH" | "NEUTRAL";
    confidence: number; // 0-100%
  };
}

class MacroCascadeService {
  private cache: Map<string, { data: any; timestamp: number }> = new Map();
  private cacheDuration = 5 * 60 * 1000; // 5 minutos (reduz rate limit)
  private apiKey = process.env.ALPHA_VANTAGE_API_KEY || "demo"; // Free tier: 500 calls/day, 5 calls/min

  /**
   * Busca cotação de um símbolo via Alpha Vantage API (com cache)
   */
  private async fetchQuote(symbol: string): Promise<MacroIndicator | null> {
    try {
      // Verificar cache
      const cached = this.cache.get(symbol);
      if (cached && Date.now() - cached.timestamp < this.cacheDuration) {
        return cached.data;
      }

      // Buscar via Alpha Vantage API
      const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${this.apiKey}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        console.error(`[Macro Cascade] Alpha Vantage API error: ${response.status} ${response.statusText}`);
        return null;
      }

      const data: any = await response.json();

      // Alpha Vantage retorna erro quando rate limit é atingido
      if (data["Note"]) {
        console.error(`[Macro Cascade] Alpha Vantage rate limit: ${data["Note"]}`);
        return null;
      }

      if (data["Error Message"]) {
        console.error(`[Macro Cascade] Alpha Vantage error: ${data["Error Message"]}`);
        return null;
      }

      const quote = data["Global Quote"];
      if (!quote || !quote["05. price"]) {
        console.error(`[Macro Cascade] No data found for ${symbol}`);
        return null;
      }

      const price = parseFloat(quote["05. price"]);
      const change = parseFloat(quote["09. change"]);
      const changePercent = parseFloat(quote["10. change percent"]?.replace("%", "") || "0");

      // Validar que todos os valores são números válidos
      if (!isFinite(price) || !isFinite(change) || !isFinite(changePercent)) {
        console.error(`[Macro Cascade] Invalid numeric values for ${symbol}: price=${price}, change=${change}, changePercent=${changePercent}`);
        return null;
      }

      const indicator: MacroIndicator = {
        symbol,
        name: this.getSymbolName(symbol),
        price,
        change,
        changePercent,
        timestamp: Date.now(),
      };

      // Atualizar cache
      this.cache.set(symbol, { data: indicator, timestamp: Date.now() });

      return indicator;
    } catch (error) {
      console.error(`[Macro Cascade] Error fetching ${symbol}:`, error);
      return null;
    }
  }

  /**
   * Mapeia símbolo para nome legível
   */
  private getSymbolName(symbol: string): string {
    const names: Record<string, string> = {
      "^VIX": "VIX",
      "DX-Y.NYB": "DXY",
      "^GSPC": "S&P500",
      "^TNX": "10Y Treasury",
      "SPY": "S&P500", // ETF como alternativa
      "UUP": "DXY", // ETF como alternativa
    };
    return names[symbol] || symbol;
  }

  /**
   * Busca todos os indicadores macro
   */
  async fetchMacroIndicators(): Promise<Omit<MacroCascadeData, "correlations" | "signals">> {
    // Alpha Vantage rate limit: 5 calls/minute
    // Fazer chamadas sequenciais com delay para evitar rate limit
    // Nota: Alpha Vantage usa símbolos diferentes do Yahoo Finance
    const vix = await this.fetchQuote("VIXY"); // VIX Short-Term Futures ETF (Alpha Vantage não tem VIX direto)
    await this.delay(300); // 300ms delay entre chamadas

    const dxy = await this.fetchQuote("UUP"); // Invesco DB USD Index Bullish Fund (proxy para DXY)
    await this.delay(300);

    const sp500 = await this.fetchQuote("SPY"); // S&P500 ETF (Alpha Vantage não tem ^GSPC)
    await this.delay(300);

    const treasury10y = await this.fetchQuote("TLT"); // 10Y Treasury ETF (Alpha Vantage não tem ^TNX)

    return {
      vix,
      dxy,
      sp500,
      treasury10y,
    };
  }

  /**
   * Delay helper para respeitar rate limit
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Calcula sinais baseados em indicadores macro
   */
  calculateSignals(
    vix: MacroIndicator | null,
    dxy: MacroIndicator | null,
    sp500: MacroIndicator | null
  ): MacroCascadeData["signals"] {
    let bullishCount = 0;
    let bearishCount = 0;
    let totalSignals = 0;

    // VIX Signal (inverso: VIX subindo = bearish para equities)
    let vixSignal: "BULLISH" | "BEARISH" | "NEUTRAL" = "NEUTRAL";
    if (vix) {
      totalSignals++;
      if (vix.changePercent > 1) {
        vixSignal = "BEARISH"; // VIX subindo = medo = bearish
        bearishCount++;
      } else if (vix.changePercent < -0.3) {
        vixSignal = "BULLISH"; // VIX caindo = confiança = bullish
        bullishCount++;
      }
    }

    // DXY Signal (inverso: DXY subindo = bearish para EM)
    let dxySignal: "BULLISH" | "BEARISH" | "NEUTRAL" = "NEUTRAL";
    if (dxy) {
      totalSignals++;
      if (dxy.changePercent > 0.2) {
        dxySignal = "BEARISH"; // Dólar forte = capital sai de EM = bearish
        bearishCount++;
      } else if (dxy.changePercent < -0.2) {
        dxySignal = "BULLISH"; // Dólar fraco = capital entra em EM = bullish
        bullishCount++;
      }
    }

    // S&P500 Signal (direto: S&P subindo = bullish)
    let sp500Signal: "BULLISH" | "BEARISH" | "NEUTRAL" = "NEUTRAL";
    if (sp500) {
      totalSignals++;
      if (sp500.changePercent > 0.2) {
        sp500Signal = "BULLISH";
        bullishCount++;
      } else if (sp500.changePercent < -0.2) {
        sp500Signal = "BEARISH";
        bearishCount++;
      }
    }

    // Overall Signal (maioria vence)
    let overallSignal: "BULLISH" | "BEARISH" | "NEUTRAL" = "NEUTRAL";
    if (bullishCount > bearishCount) {
      overallSignal = "BULLISH";
    } else if (bearishCount > bullishCount) {
      overallSignal = "BEARISH";
    }

    // Confidence (% de sinais alinhados)
    const confidence = totalSignals > 0 ? Math.max(bullishCount, bearishCount) / totalSignals * 100 : 0;

    return {
      vixSignal,
      dxySignal,
      sp500Signal,
      overallSignal,
      confidence: Math.round(confidence),
    };
  }

  /**
   * Busca dados completos do Macro Cascade
   */
  async getMacroCascade(): Promise<MacroCascadeData> {
    const indicators = await this.fetchMacroIndicators();
    const signals = this.calculateSignals(indicators.vix, indicators.dxy, indicators.sp500);

    // TODO: Calcular correlações dinâmicas (requer histórico de WINFUT)
    const correlations = {
      vixWinfut: -0.85, // Placeholder (correlação histórica conhecida)
      dxyWinfut: -0.71, // Placeholder
      sp500Winfut: 0.92, // Placeholder
    };

    return {
      ...indicators,
      correlations,
      signals,
    };
  }

  /**
   * Limpa cache (útil para testes)
   */
  clearCache(): void {
    this.cache.clear();
  }
}

// Singleton instance
export const macroCascadeService = new MacroCascadeService();
