import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("Backtest Router", () => {
  describe("getUserBacktests", () => {
    it("should return backtests list for authenticated user", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getUserBacktests();

      expect(result).toBeDefined();
      expect(result).toHaveProperty("success");
      expect(result).toHaveProperty("data");
      expect(Array.isArray(result.data)).toBe(true);
    });

    it("should return backtests list for user", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getUserBacktests();

      expect(result.success).toBe(true);
      expect(Array.isArray(result.data)).toBe(true);
    });
  });

  describe("getRobotPerformance", () => {
    it("should accept backtestId parameter", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      expect(result).toBeDefined();
      expect(result).toHaveProperty("success");
      expect(Array.isArray(result.data)).toBe(true);
    });

    it("should return empty array for non-existent backtest", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 999 });

      expect(result.success).toBe(true);
      expect(result.data).toEqual([]);
    });
  });

  describe("getTrades", () => {
    it("should accept backtestId parameter", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      expect(result).toBeDefined();
      expect(result).toHaveProperty("success");
      expect(Array.isArray(result.data)).toBe(true);
    });

    it("should support optional robot filter", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({
        backtestId: 1,
        robot: "TestRobot",
      });

      expect(result.success).toBe(true);
      expect(Array.isArray(result.data)).toBe(true);
    });

    it("should return empty array for non-existent backtest", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 999 });

      expect(result.success).toBe(true);
      expect(result.data).toEqual([]);
    });
  });

  describe("uploadFile", () => {
    it("should accept file upload parameters", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      // Mock file data (base64 encoded CSV)
      const mockFileData = "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,QXNzZXQsRGF0YSxIb3JhCldJTkZVVCwyMDI0LTAxLTAxLDEwOjAwCldJTkZVVCwyMDI0LTAxLTAxLDExOjAw";

      const result = await caller.backtest.uploadFile({
        fileName: "test-backtest.xlsx",
        fileData: mockFileData,
        fileSize: 1024,
      });

      expect(result).toBeDefined();
      expect(result).toHaveProperty("success");

      if (result.success) {
        expect(result).toHaveProperty("backtestId");
        expect(result).toHaveProperty("fileName");
        expect(result.fileName).toBe("test-backtest.xlsx");
      }
    });

    it("should handle file upload errors gracefully", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      // Invalid file data
      const result = await caller.backtest.uploadFile({
        fileName: "invalid.xlsx",
        fileData: "invalid-base64-data",
        fileSize: 100,
      });

      // Should return error response
      expect(result).toBeDefined();
      expect(result).toHaveProperty("success");
    });
  });

  describe("Data Consistency", () => {
    it("should return consistent robot performance structure", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getRobotPerformance({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const performance = result.data[0];
        expect(performance).toHaveProperty("robot");
        expect(performance).toHaveProperty("totalTrades");
        expect(typeof performance.totalTrades).toBe("number");
      }
    });

    it("should return consistent trade structure", async () => {
      const ctx = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.backtest.getTrades({ backtestId: 1 });

      if (result.success && result.data.length > 0) {
        const trade = result.data[0];
        expect(trade).toHaveProperty("backtestId");
        expect(trade).toHaveProperty("robot");
        expect(trade).toHaveProperty("direction");
        expect(["long", "short"]).toContain(trade.direction);
      }
    });
  });
});
