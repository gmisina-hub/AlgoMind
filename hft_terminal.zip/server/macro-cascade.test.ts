/**
 * Macro Cascade Service Tests
 * 
 * Valida integração com Alpha Vantage API
 */

import { describe, it, expect } from "vitest";
import { macroCascadeService } from "./macro-cascade";

describe("Macro Cascade Service", () => {
  it("should fetch VIX data from Alpha Vantage API", async () => {
    // Limpar cache para forçar chamada real
    macroCascadeService.clearCache();

    const data = await macroCascadeService.fetchMacroIndicators();

    // Validar que VIX foi buscado (pode ser null se API falhar, mas não deve dar erro)
    expect(data).toBeDefined();
    expect(data).toHaveProperty("vix");
    expect(data).toHaveProperty("dxy");
    expect(data).toHaveProperty("sp500");
    expect(data).toHaveProperty("treasury10y");

    // Se VIX foi buscado com sucesso, validar estrutura
    if (data.vix) {
      expect(data.vix).toHaveProperty("symbol");
      expect(data.vix).toHaveProperty("price");
      expect(data.vix).toHaveProperty("change");
      expect(data.vix).toHaveProperty("changePercent");
      expect(data.vix.price).toBeGreaterThan(0);
      console.log("✅ VIX data fetched successfully:", data.vix);
    } else {
      console.warn("⚠️ VIX data is null (API may have failed or rate limited)");
    }
  }, 30000); // 30s timeout (Alpha Vantage pode ser lento)

  it("should calculate signals based on macro indicators", () => {
    // Mock data para testar lógica de sinais
    const mockVix = {
      symbol: "^VIX",
      name: "VIX",
      price: 20.5,
      change: 2.5,
      changePercent: 13.9, // >5% = BEARISH
      timestamp: Date.now(),
    };

    const mockDxy = {
      symbol: "DX-Y.NYB",
      name: "DXY",
      price: 104.2,
      change: 0.8,
      changePercent: 0.77, // >0.5% = BEARISH
      timestamp: Date.now(),
    };

    const mockSp500 = {
      symbol: "^GSPC",
      name: "S&P500",
      price: 5800.0,
      change: -50.0,
      changePercent: -0.85, // <-0.5% = BEARISH
      timestamp: Date.now(),
    };

    const signals = macroCascadeService.calculateSignals(mockVix, mockDxy, mockSp500);

    expect(signals).toBeDefined();
    expect(signals.vixSignal).toBe("BEARISH"); // VIX subindo >5%
    expect(signals.dxySignal).toBe("BEARISH"); // DXY subindo >0.5%
    expect(signals.sp500Signal).toBe("BEARISH"); // S&P caindo >0.5%
    expect(signals.overallSignal).toBe("BEARISH"); // Maioria bearish
    expect(signals.confidence).toBe(100); // 3/3 sinais alinhados

    console.log("✅ Signal calculation validated:", signals);
  });

  it("should handle null indicators gracefully", () => {
    const signals = macroCascadeService.calculateSignals(null, null, null);

    expect(signals).toBeDefined();
    expect(signals.overallSignal).toBe("NEUTRAL");
    expect(signals.confidence).toBe(0);

    console.log("✅ Null handling validated:", signals);
  });

  it("should cache API responses for 5 minutes", async () => {
    macroCascadeService.clearCache();

    // Primeira chamada (deve buscar da API)
    const start1 = Date.now();
    const data1 = await macroCascadeService.fetchMacroIndicators();
    const duration1 = Date.now() - start1;

    // Segunda chamada imediata (deve usar cache)
    const start2 = Date.now();
    const data2 = await macroCascadeService.fetchMacroIndicators();
    const duration2 = Date.now() - start2;

    // Cache deve ser muito mais rápido (<100ms vs >1000ms)
    expect(duration2).toBeLessThan(duration1 / 2);
    console.log(`✅ Cache working: API call ${duration1}ms, cached ${duration2}ms`);

    // Dados devem ser idênticos
    expect(data2).toEqual(data1);
  }, 30000);
});
