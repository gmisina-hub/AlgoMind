/**
 * server/openai-validation.test.ts
 * Teste para validar API key OpenAI
 */

import { describe, it, expect } from "vitest";
import OpenAI from "openai";

describe("OpenAI API Key Validation", () => {
  it("deve validar API key OpenAI com chamada simples", async () => {
    const apiKey = process.env.OPENAI_API_KEY;
    
    expect(apiKey).toBeDefined();
    expect(apiKey).toMatch(/^sk-/);
    
    const openai = new OpenAI({
      apiKey: apiKey,
    });
    
    // Fazer chamada mínima para validar chave
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini", // Modelo mais barato para teste
      messages: [
        { role: "system", content: "You are a helpful assistant." },
        { role: "user", content: "Say 'OK' if you can read this." }
      ],
      max_tokens: 10,
    });
    
    expect(response.choices).toHaveLength(1);
    expect(response.choices[0].message.content).toBeTruthy();
    expect(response.model).toContain("gpt-4o-mini");
    
    console.log("[OpenAI] API key válida! Modelo:", response.model);
    console.log("[OpenAI] Resposta:", response.choices[0].message.content);
  });
});
