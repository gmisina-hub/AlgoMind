# Correção: AI Trading Assistant Piscando

## 🎯 Problema Identificado

**Sintoma:**
- AI Trading Assistant piscava a cada 2 segundos (intervalo de polling)
- Quando recebia recomendação da AI (a cada 5 minutos), mostrava por 2 segundos e voltava para NEUTRO
- Recomendação ficava ilegível e inútil para o usuário

**Causa Raiz:**
O React Query estava invalidando a query `getAIRecommendation` toda vez que o contexto mudava (a cada 2 segundos no polling principal), fazendo com que `aiRecommendationData` ficasse `undefined` durante o refetch, resetando o card para NEUTRO.

---

## ✅ Solução Implementada

**Arquivo modificado:** `client/src/pages/Dashboard.tsx` (linha 142)

**Antes:**
```typescript
{
  enabled: !!data?.brazilian?.winfut && !!data?.technicalIndicators,
  refetchInterval: autoRefresh ? 300000 : false, // 5 min
  staleTime: 300000,
}
```

**Depois:**
```typescript
{
  enabled: !!data?.brazilian?.winfut && !!data?.technicalIndicators,
  refetchInterval: autoRefresh ? 300000 : false, // 5 min
  staleTime: 300000,
  placeholderData: (previousData) => previousData, // Mantém última recomendação até nova atualização
}
```

---

## 🔧 Como Funciona

**`placeholderData: (previousData) => previousData`**

Esta opção do React Query faz com que:
1. ✅ Quando a query é invalidada (por mudança no contexto), ela mantém os dados anteriores
2. ✅ Apenas atualiza quando houver nova resposta do backend
3. ✅ Não reseta para `undefined` durante o refetch
4. ✅ Garante que a recomendação permaneça visível até a próxima atualização de 5 minutos

---

## 📊 Resultado Esperado

**Comportamento correto:**
1. ✅ AI Trading Assistant **NÃO pisca** mais a cada 2 segundos
2. ✅ Quando recebe recomendação da AI (a cada 5 min), ela **permanece fixa**
3. ✅ **Não volta para NEUTRO** entre as atualizações
4. ✅ Apenas atualiza quando houver nova análise da AI (300 segundos = 5 minutos)

---

## 🧪 Como Testar

1. Abra o dashboard com Auto-Refresh ON
2. Observe o AI Trading Assistant por 30 segundos
3. Verifique que ele **NÃO pisca** mais
4. Aguarde até próximo ciclo de 5 minutos
5. Quando receber nova recomendação, ela deve **permanecer fixa** até próxima atualização

---

## 📝 Lições Aprendidas

**React Query Best Practices:**
- Use `placeholderData` quando quiser manter dados anteriores durante refetch
- Use `staleTime` para controlar quando dados são considerados "velhos"
- Use `refetchInterval` para polling periódico
- Combine essas opções para criar UX fluida sem "piscadas"

**Alternativas consideradas:**
- ❌ `keepPreviousData: true` (deprecated no React Query v5)
- ❌ `useState` manual (mais complexo e propenso a bugs)
- ✅ `placeholderData` (solução moderna e recomendada)

---

## 🎓 Referências

- [React Query - Placeholder Data](https://tanstack.com/query/latest/docs/framework/react/guides/placeholder-query-data)
- [React Query - Refetch Interval](https://tanstack.com/query/latest/docs/framework/react/guides/window-focus-refetching)
- [React Query - Stale Time](https://tanstack.com/query/latest/docs/framework/react/guides/caching)
