import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, json, bigint } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Market snapshot table - stores real-time market data from DDE
 */
export const marketSnapshots = mysqlTable("market_snapshots", {
  id: int("id").autoincrement().primaryKey(),
  symbol: varchar("symbol", { length: 32 }).notNull(),
  last: decimal("last", { precision: 18, scale: 4 }),
  open: decimal("open", { precision: 18, scale: 4 }),
  high: decimal("high", { precision: 18, scale: 4 }),
  low: decimal("low", { precision: 18, scale: 4 }),
  close: decimal("close", { precision: 18, scale: 4 }),
  varPts: decimal("varPts", { precision: 18, scale: 4 }),
  varPct: decimal("varPct", { precision: 10, scale: 4 }),
  volume: decimal("volume", { precision: 20, scale: 0 }),
  adjust: decimal("adjust", { precision: 18, scale: 4 }),
  adjustPrev: decimal("adjustPrev", { precision: 18, scale: 4 }),
  hilo: decimal("hilo", { precision: 18, scale: 4 }),
  rsi: decimal("rsi", { precision: 10, scale: 4 }),
  priorAdj: decimal("priorAdj", { precision: 18, scale: 4 }),
  priorAdjB: decimal("priorAdjB", { precision: 18, scale: 4 }),
  accumBalance: decimal("accumBalance", { precision: 18, scale: 4 }),
  trueRange: decimal("trueRange", { precision: 18, scale: 4 }),
  vwap: decimal("vwap", { precision: 18, scale: 4 }),
  vwapMonthly: decimal("vwapMonthly", { precision: 18, scale: 4 }),
  timestamp: timestamp("timestamp").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MarketSnapshot = typeof marketSnapshots.$inferSelect;
export type InsertMarketSnapshot = typeof marketSnapshots.$inferInsert;

/**
 * Backtest data table - stores uploaded Excel backtest results
 */
export const backtests = mysqlTable("backtests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 255 }).notNull(),
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
  processedAt: timestamp("processedAt"),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  summary: json("summary"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Backtest = typeof backtests.$inferSelect;
export type InsertBacktest = typeof backtests.$inferInsert;

/**
 * Trade data table - stores individual trades from backtest
 */
export const trades = mysqlTable("trades", {
  id: int("id").autoincrement().primaryKey(),
  backtestId: int("backtestId").notNull(),
  robot: varchar("robot", { length: 128 }).notNull(),
  entryTime: timestamp("entryTime").notNull(),
  exitTime: timestamp("exitTime"),
  entryPrice: decimal("entryPrice", { precision: 18, scale: 4 }).notNull(),
  exitPrice: decimal("exitPrice", { precision: 18, scale: 4 }),
  quantity: int("quantity").notNull(),
  pnl: decimal("pnl", { precision: 18, scale: 4 }),
  pnlPct: decimal("pnlPct", { precision: 10, scale: 4 }),
  direction: mysqlEnum("direction", ["long", "short"]).notNull(),
  status: mysqlEnum("status", ["open", "closed"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Trade = typeof trades.$inferSelect;
export type InsertTrade = typeof trades.$inferInsert;

/**
 * Robot performance table - aggregated metrics per robot
 */
export const robotPerformance = mysqlTable("robot_performance", {
  id: int("id").autoincrement().primaryKey(),
  backtestId: int("backtestId").notNull(),
  robot: varchar("robot", { length: 128 }).notNull(),
  totalTrades: int("totalTrades").default(0).notNull(),
  winningTrades: int("winningTrades").default(0).notNull(),
  losingTrades: int("losingTrades").default(0).notNull(),
  winRate: decimal("winRate", { precision: 10, scale: 4 }),
  totalPnl: decimal("totalPnl", { precision: 18, scale: 4 }),
  avgPnlPerTrade: decimal("avgPnlPerTrade", { precision: 18, scale: 4 }),
  maxDrawdown: decimal("maxDrawdown", { precision: 10, scale: 4 }),
  profitFactor: decimal("profitFactor", { precision: 10, scale: 4 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type RobotPerformance = typeof robotPerformance.$inferSelect;
export type InsertRobotPerformance = typeof robotPerformance.$inferInsert;

/**
 * Intraday ticks table - stores real-time market data ticks throughout the trading day
 * Enables historical chart reconstruction, replay, and pattern analysis
 */
export const intradayTicks = mysqlTable("intraday_ticks", {
  id: int("id").autoincrement().primaryKey(),
  symbol: varchar("symbol", { length: 32 }).notNull(),
  timestamp: timestamp("timestamp").notNull(),
  last: decimal("last", { precision: 18, scale: 4 }),
  open: decimal("open", { precision: 18, scale: 4 }),
  high: decimal("high", { precision: 18, scale: 4 }),
  low: decimal("low", { precision: 18, scale: 4 }),
  close: decimal("close", { precision: 18, scale: 4 }),
  varPts: decimal("varPts", { precision: 18, scale: 4 }),
  varPct: decimal("varPct", { precision: 10, scale: 4 }),
  volume: decimal("volume", { precision: 20, scale: 0 }),
  rsi: decimal("rsi", { precision: 10, scale: 4 }),
  vwap: decimal("vwap", { precision: 18, scale: 4 }),
  vwapMonthly: decimal("vwapMonthly", { precision: 18, scale: 4 }),
  trueRange: decimal("trueRange", { precision: 18, scale: 4 }),
  accumBalance: decimal("accumBalance", { precision: 18, scale: 4 }),
  adjust: decimal("adjust", { precision: 18, scale: 4 }),
  hilo: decimal("hilo", { precision: 18, scale: 4 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type IntradayTick = typeof intradayTicks.$inferSelect;
export type InsertIntradayTick = typeof intradayTicks.$inferInsert;

/**
 * AI Recommendations History - stores all AI trading recommendations for performance tracking
 */
export const aiRecommendationsHistory = mysqlTable("ai_recommendations_history", {
  id: int("id").autoincrement().primaryKey(),
  timestamp: bigint("timestamp", { mode: "number" }).notNull(), // Unix timestamp in ms
  recommendation: mysqlEnum("recommendation", ["LONG", "SHORT", "NEUTRO"]).notNull(),
  confidence: int("confidence").notNull(), // 0-100
  entry: decimal("entry", { precision: 18, scale: 4 }).notNull(),
  stopLoss: decimal("stopLoss", { precision: 18, scale: 4 }).notNull(),
  takeProfit: decimal("takeProfit", { precision: 18, scale: 4 }).notNull(),
  context: text("context").notNull(),
  // Performance tracking fields (filled later)
  exitPrice: decimal("exitPrice", { precision: 18, scale: 4 }),
  exitTimestamp: bigint("exitTimestamp", { mode: "number" }),
  result: mysqlEnum("result", ["win", "loss", "breakeven", "pending"]).default("pending"),
  profitLoss: decimal("profitLoss", { precision: 18, scale: 4 }),
  profitLossPct: decimal("profitLossPct", { precision: 10, scale: 4 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AIRecommendationHistory = typeof aiRecommendationsHistory.$inferSelect;
export type InsertAIRecommendationHistory = typeof aiRecommendationsHistory.$inferInsert;
