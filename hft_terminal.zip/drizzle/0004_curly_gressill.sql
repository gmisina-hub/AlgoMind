CREATE TABLE `backtests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`fileKey` varchar(255) NOT NULL,
	`uploadedAt` timestamp NOT NULL DEFAULT (now()),
	`processedAt` timestamp,
	`status` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
	`summary` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `backtests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `intraday_ticks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`symbol` varchar(32) NOT NULL,
	`timestamp` timestamp NOT NULL,
	`last` decimal(18,4),
	`open` decimal(18,4),
	`high` decimal(18,4),
	`low` decimal(18,4),
	`close` decimal(18,4),
	`varPts` decimal(18,4),
	`varPct` decimal(10,4),
	`volume` decimal(20,0),
	`rsi` decimal(10,4),
	`vwap` decimal(18,4),
	`vwapMonthly` decimal(18,4),
	`trueRange` decimal(18,4),
	`accumBalance` decimal(18,4),
	`adjust` decimal(18,4),
	`hilo` decimal(18,4),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `intraday_ticks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `market_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`symbol` varchar(32) NOT NULL,
	`last` decimal(18,4),
	`open` decimal(18,4),
	`high` decimal(18,4),
	`low` decimal(18,4),
	`close` decimal(18,4),
	`varPts` decimal(18,4),
	`varPct` decimal(10,4),
	`volume` decimal(20,0),
	`adjust` decimal(18,4),
	`adjustPrev` decimal(18,4),
	`hilo` decimal(18,4),
	`rsi` decimal(10,4),
	`priorAdj` decimal(18,4),
	`priorAdjB` decimal(18,4),
	`accumBalance` decimal(18,4),
	`trueRange` decimal(18,4),
	`vwap` decimal(18,4),
	`vwapMonthly` decimal(18,4),
	`timestamp` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `market_snapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `robot_performance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`backtestId` int NOT NULL,
	`robot` varchar(128) NOT NULL,
	`totalTrades` int NOT NULL DEFAULT 0,
	`winningTrades` int NOT NULL DEFAULT 0,
	`losingTrades` int NOT NULL DEFAULT 0,
	`winRate` decimal(10,4),
	`totalPnl` decimal(18,4),
	`avgPnlPerTrade` decimal(18,4),
	`maxDrawdown` decimal(10,4),
	`profitFactor` decimal(10,4),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `robot_performance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trades` (
	`id` int AUTO_INCREMENT NOT NULL,
	`backtestId` int NOT NULL,
	`robot` varchar(128) NOT NULL,
	`entryTime` timestamp NOT NULL,
	`exitTime` timestamp,
	`entryPrice` decimal(18,4) NOT NULL,
	`exitPrice` decimal(18,4),
	`quantity` int NOT NULL,
	`pnl` decimal(18,4),
	`pnlPct` decimal(10,4),
	`direction` enum('long','short') NOT NULL,
	`status` enum('open','closed') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `trades_id` PRIMARY KEY(`id`)
);
