DROP TABLE `backtests`;--> statement-breakpoint
DROP TABLE `intraday_ticks`;--> statement-breakpoint
DROP TABLE `market_snapshots`;--> statement-breakpoint
DROP TABLE `robot_performance`;--> statement-breakpoint
DROP TABLE `trades`;