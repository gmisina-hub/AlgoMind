CREATE TABLE `ai_recommendations_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`timestamp` bigint NOT NULL,
	`recommendation` enum('LONG','SHORT','NEUTRO') NOT NULL,
	`confidence` int NOT NULL,
	`entry` decimal(18,4) NOT NULL,
	`stopLoss` decimal(18,4) NOT NULL,
	`takeProfit` decimal(18,4) NOT NULL,
	`context` text NOT NULL,
	`exitPrice` decimal(18,4),
	`exitTimestamp` bigint,
	`result` enum('win','loss','breakeven','pending') DEFAULT 'pending',
	`profitLoss` decimal(18,4),
	`profitLossPct` decimal(10,4),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ai_recommendations_history_id` PRIMARY KEY(`id`)
);
