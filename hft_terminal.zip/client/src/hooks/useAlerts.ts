/**
 * useAlerts Hook
 * 
 * Monitora condições críticas e dispara alertas visuais (toast) + sonoros (beep)
 * 
 * Triggers:
 * - AI confidence >80%
 * - Dark Pool detectado (>70%)
 * - Preço cruza R2/S2
 * - Preço cruza Fibonacci 61.8%
 */

import { useEffect, useRef } from "react";
import { toast } from "sonner";

interface AlertConditions {
  aiConfidence?: number;
  aiRecommendation?: string;
  darkPoolDetected?: boolean;
  darkPoolConfidence?: number;
  darkPoolDirection?: string;
  currentPrice?: number;
  pivotR2?: number;
  pivotS2?: number;
  fibonacci618?: number;
}

export function useAlerts(conditions: AlertConditions) {
  const previousConditions = useRef<AlertConditions>({});
  const audioContext = useRef<AudioContext | null>(null);

  // Inicializar AudioContext
  useEffect(() => {
    if (typeof window !== "undefined" && !audioContext.current) {
      audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }, []);

  // Função para tocar beep
  const playBeep = (frequency = 800, duration = 200) => {
    if (!audioContext.current) return;

    const oscillator = audioContext.current.createOscillator();
    const gainNode = audioContext.current.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.current.destination);

    oscillator.frequency.value = frequency;
    oscillator.type = "sine";

    gainNode.gain.setValueAtTime(0.3, audioContext.current.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.current.currentTime + duration / 1000);

    oscillator.start(audioContext.current.currentTime);
    oscillator.stop(audioContext.current.currentTime + duration / 1000);
  };

  // Monitorar condições
  useEffect(() => {
    const prev = previousConditions.current;

    // 1. AI Confidence >80%
    if (
      conditions.aiConfidence !== undefined &&
      conditions.aiConfidence > 80 &&
      prev.aiConfidence !== conditions.aiConfidence
    ) {
      const recommendation = conditions.aiRecommendation || "NEUTRO";
      const color = recommendation === "LONG" ? "🟢" : recommendation === "SHORT" ? "🔴" : "🟡";
      
      toast.success(`${color} AI Trading: ${recommendation}`, {
        description: `Confiança: ${conditions.aiConfidence}% - Sinal forte detectado!`,
        duration: 10000,
      });
      playBeep(1000, 300); // Beep agudo para AI
    }

    // 2. Dark Pool Detectado (>70%)
    if (
      conditions.darkPoolDetected &&
      conditions.darkPoolConfidence !== undefined &&
      conditions.darkPoolConfidence > 70 &&
      prev.darkPoolConfidence !== conditions.darkPoolConfidence
    ) {
      const direction = conditions.darkPoolDirection || "NEUTRAL";
      const emoji = direction === "BUY" ? "🐋💚" : direction === "SELL" ? "🐋❤️" : "🐋";
      
      toast.warning(`${emoji} Dark Pool Detectado!`, {
        description: `Direção: ${direction} | Confiança: ${conditions.darkPoolConfidence}% - Institucionais ativos!`,
        duration: 10000,
      });
      playBeep(600, 400); // Beep grave para Dark Pool
    }

    // 3. Preço cruza R2 (resistência forte)
    if (
      conditions.currentPrice !== undefined &&
      conditions.pivotR2 !== undefined &&
      prev.currentPrice !== undefined &&
      prev.currentPrice < conditions.pivotR2 &&
      conditions.currentPrice >= conditions.pivotR2
    ) {
      toast.info("📍 Cruzamento R2 (Pivot)", {
        description: `Preço: ${conditions.currentPrice.toFixed(0)} cruzou R2: ${conditions.pivotR2.toFixed(0)} - Resistência forte!`,
        duration: 8000,
      });
      playBeep(800, 200);
    }

    // 4. Preço cruza S2 (suporte forte)
    if (
      conditions.currentPrice !== undefined &&
      conditions.pivotS2 !== undefined &&
      prev.currentPrice !== undefined &&
      prev.currentPrice > conditions.pivotS2 &&
      conditions.currentPrice <= conditions.pivotS2
    ) {
      toast.info("📍 Cruzamento S2 (Pivot)", {
        description: `Preço: ${conditions.currentPrice.toFixed(0)} cruzou S2: ${conditions.pivotS2.toFixed(0)} - Suporte forte!`,
        duration: 8000,
      });
      playBeep(800, 200);
    }

    // 5. Preço cruza Fibonacci 61.8% (nível golden)
    if (
      conditions.currentPrice !== undefined &&
      conditions.fibonacci618 !== undefined &&
      prev.currentPrice !== undefined &&
      Math.abs(prev.currentPrice - conditions.fibonacci618) > 50 && // estava longe
      Math.abs(conditions.currentPrice - conditions.fibonacci618) <= 50 // agora está perto
    ) {
      toast.info("🟡 Fibonacci 61.8%", {
        description: `Preço: ${conditions.currentPrice.toFixed(0)} próximo de ${conditions.fibonacci618.toFixed(0)} - Nível golden!`,
        duration: 8000,
      });
      playBeep(900, 200);
    }

    // Atualizar referência
    previousConditions.current = { ...conditions };
  }, [conditions]);

  return null; // Hook não retorna nada, apenas dispara alertas
}
