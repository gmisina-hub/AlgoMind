import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";

export interface MarketData {
  symbol: string;
  last: number;
  open: number;
  high: number;
  low: number;
  close: number;
  varPts: number;
  varPct: number;
  volume: number;
  adjust: number;
  adjustPrev: number;
  hilo: number;
  rsi: number;
  priorAdj: number;
  priorAdjB: number;
  accumBalance: number;
  trueRange: number;
  vwap: number;
  vwapMonthly: number;
  timestamp: string;
}

export interface DDEData {
  marketSnapshot: MarketData;
  lastPrice: number;
  insightMain: string;
  insightSecondary: string;
  marketPressure: {
    buy: number;
    sell: number;
    net: number;
  };
  volatilityScore: number;
  volatilityLevel: string;
  priceTrend: {
    direction: string;
    probLow: number;
    probMedium: number;
    probHigh: number;
  };
}

/**
 * Hook para consumir dados DDE em tempo real com polling
 * @param pollInterval Intervalo de polling em ms (padrão: 3000ms)
 */
export function useDDEData(pollInterval: number = 3000) {
  const [data, setData] = useState<DDEData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  const { data: ddeData, isLoading: isFetching, error: fetchError } = trpc.market.getDDEData.useQuery(undefined, {
    refetchInterval: pollInterval,
    refetchIntervalInBackground: true,
  });

  useEffect(() => {
    if (ddeData) {
      if (ddeData.success && ddeData.data) {
        setData(ddeData.data as DDEData);
        setLastUpdate(new Date());
        setError(null);
      } else if (!ddeData.success) {
        setError(ddeData.error || "Erro ao buscar dados DDE");
      }
    }
  }, [ddeData]);

  useEffect(() => {
    setIsLoading(isFetching);
  }, [isFetching]);

  useEffect(() => {
    if (fetchError) {
      setError(fetchError.message);
    }
  }, [fetchError]);

  return {
    data,
    isLoading,
    error,
    lastUpdate,
  };
}

/**
 * Hook para consumir snapshot de um símbolo específico
 */
export function useMarketSnapshot(symbol: string) {
  const { data, isLoading, error } = trpc.market.getLatestSnapshot.useQuery(
    { symbol },
    {
      refetchInterval: 3000,
      refetchIntervalInBackground: true,
    }
  );

  return {
    snapshot: data,
    isLoading,
    error,
  };
}
