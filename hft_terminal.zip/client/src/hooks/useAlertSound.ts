/**
 * Custom hook to play alert sound when alerts are triggered
 */

import { useEffect, useRef } from "react";

export function useAlertSound(alerts: any[] | undefined) {
  const previousAlertsCount = useRef(0);
  const audioContext = useRef<AudioContext | null>(null);

  useEffect(() => {
    // Initialize AudioContext on first use
    if (!audioContext.current) {
      audioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }, []);

  useEffect(() => {
    if (!alerts || alerts.length === 0) {
      previousAlertsCount.current = 0;
      return;
    }

    // Check if new alerts were added
    if (alerts.length > previousAlertsCount.current) {
      playAlertSound();
    }

    previousAlertsCount.current = alerts.length;
  }, [alerts]);

  const playAlertSound = () => {
    if (!audioContext.current) return;

    const ctx = audioContext.current;
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    // Beep sound: 800Hz for 200ms
    oscillator.frequency.value = 800;
    oscillator.type = "sine";

    // Fade in/out for smoother sound
    gainNode.gain.setValueAtTime(0, ctx.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.3, ctx.currentTime + 0.01);
    gainNode.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.2);

    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + 0.2);
  };

  return { playAlertSound };
}
