import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Loader2, TrendingUp, TrendingDown, AlertCircle, BarChart3 } from "lucide-react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
} from "recharts";

export default function EquityCurvePage() {
  const [selectedBacktest, setSelectedBacktest] = useState<number | null>(null);
  const [selectedRobot, setSelectedRobot] = useState<string | null>(null);

  // Fetch backtests
  const { data: backtestsData, isLoading: backtestsLoading } = trpc.backtest.getUserBacktests.useQuery();
  const backtests = backtestsData?.data || [];

  // Fetch trades for equity curve
  const { data: tradesData, isLoading: tradesLoading } = trpc.backtest.getTrades.useQuery(
    {
      backtestId: selectedBacktest || 0,
    },
    { enabled: selectedBacktest !== null }
  );
  const trades = tradesData?.data || [];

  // Fetch robot performance for risk metrics
  const { data: performanceData } = trpc.backtest.getRobotPerformance.useQuery(
    { backtestId: selectedBacktest || 0 },
    { enabled: selectedBacktest !== null }
  );
  const robots = performanceData?.data || [];

  // Calculate equity curve
  const equityCurveData = trades
    .reduce((acc: any[], trade: any, index: number) => {
      const prevEquity = acc.length > 0 ? acc[acc.length - 1].equity : 0;
      const pnl = parseFloat(trade.pnl) || 0;
      const newEquity = prevEquity + pnl;

      return [
        ...acc,
        {
          trade: index + 1,
          equity: newEquity,
          pnl: pnl,
          cumPnl: newEquity,
          date: new Date(trade.entryTime).toLocaleDateString("pt-BR"),
        },
      ];
    }, []);

  // Calculate drawdown
  const drawdownData = equityCurveData.map((point: any) => {
    const maxEquity = Math.max(...equityCurveData.slice(0, equityCurveData.indexOf(point) + 1).map((p: any) => p.equity));
    const drawdown = maxEquity > 0 ? ((point.equity - maxEquity) / maxEquity) * 100 : 0;
    return {
      ...point,
      drawdown: drawdown,
    };
  });

  // Calculate distribution of trades
  const tradeDistribution = trades.reduce((acc: any, trade: any) => {
    const pnl = parseFloat(trade.pnl) || 0;
    const bucket = Math.floor(pnl / 100) * 100;
    const existing = acc.find((item: any) => item.bucket === bucket);

    if (existing) {
      existing.count += 1;
    } else {
      acc.push({
        bucket: bucket,
        count: 1,
        range: `${bucket} a ${bucket + 100}`,
      });
    }

    return acc;
  }, []);

  // Calculate risk metrics
  const calculateRiskMetrics = () => {
    if (equityCurveData.length === 0) return null;

    const returns = equityCurveData.map((point: any) => point.pnl);
    const totalPnl = returns.reduce((sum: number, r: number) => sum + r, 0);
    const avgReturn = totalPnl / returns.length;
    const stdDev = Math.sqrt(
      returns.reduce((sum: number, r: number) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length
    );

    const maxDrawdown = Math.min(...drawdownData.map((d: any) => d.drawdown));
    const winningTrades = returns.filter((r: number) => r > 0).length;
    const losingTrades = returns.filter((r: number) => r < 0).length;
    const winRate = (winningTrades / returns.length) * 100;

    // Sharpe Ratio (simplified, assuming 0% risk-free rate)
    const sharpeRatio = stdDev > 0 ? avgReturn / stdDev : 0;

    // Profit Factor
    const grossProfit = returns.filter((r: number) => r > 0).reduce((sum: number, r: number) => sum + r, 0);
    const grossLoss = Math.abs(returns.filter((r: number) => r < 0).reduce((sum: number, r: number) => sum + r, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 999 : 0;

    return {
      totalPnl,
      avgReturn,
      stdDev,
      maxDrawdown,
      winRate,
      sharpeRatio,
      profitFactor,
      winningTrades,
      losingTrades,
    };
  };

  const riskMetrics = calculateRiskMetrics();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white">Curva de Equity</h1>
        <p className="text-slate-400 mt-1">Análise de performance e risco</p>
      </div>

      {/* Backtest Selector */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-sm">Selecionar Backtest</CardTitle>
        </CardHeader>
        <CardContent>
          {backtestsLoading ? (
            <div className="flex items-center gap-2">
              <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
              <span className="text-sm text-slate-400">Carregando backtests...</span>
            </div>
          ) : backtests.length === 0 ? (
            <p className="text-sm text-slate-400">Nenhum backtest disponível. Envie um arquivo primeiro.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
              {backtests.map((backtest: any) => (
                <Button
                  key={backtest.id}
                  variant={selectedBacktest === backtest.id ? "default" : "outline"}
                  className={`text-left h-auto py-2 px-3 ${
                    selectedBacktest === backtest.id
                      ? "bg-cyan-600 border-cyan-600"
                      : "border-slate-600 hover:border-slate-500"
                  }`}
                  onClick={() => {
                    setSelectedBacktest(backtest.id);
                    setSelectedRobot(null);
                  }}
                >
                  <div className="text-xs font-medium truncate">{backtest.fileName}</div>
                  <div className="text-xs text-slate-400">
                    {backtest.summary?.robotCount || 0} robôs
                  </div>
                </Button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {selectedBacktest && (
        <>
          {/* Robot Selector */}
          {robots.length > 0 && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-sm">Selecionar Robô (Opcional)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
                  <Button
                    variant={selectedRobot === null ? "default" : "outline"}
                    className={`text-xs h-auto py-1 px-2 ${
                      selectedRobot === null ? "bg-cyan-600 border-cyan-600" : "border-slate-600"
                    }`}
                    onClick={() => setSelectedRobot(null)}
                  >
                    Todos
                  </Button>
                  {robots.map((robot: any) => (
                    <Button
                      key={robot.robot}
                      variant={selectedRobot === robot.robot ? "default" : "outline"}
                      className={`text-xs h-auto py-1 px-2 truncate ${
                        selectedRobot === robot.robot
                          ? "bg-cyan-600 border-cyan-600"
                          : "border-slate-600 hover:border-slate-500"
                      }`}
                      onClick={() => setSelectedRobot(robot.robot)}
                    >
                      {robot.robot}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Risk Metrics Summary */}
          {riskMetrics && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-400">P&L Total</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className={`text-2xl font-bold ${riskMetrics.totalPnl >= 0 ? "text-green-400" : "text-red-400"}`}>
                    {riskMetrics.totalPnl.toFixed(2)}
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-400">Max Drawdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-orange-400">
                    {riskMetrics.maxDrawdown.toFixed(2)}%
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-400">Win Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-cyan-400">
                    {riskMetrics.winRate.toFixed(2)}%
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-400">Sharpe Ratio</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-white">
                    {riskMetrics.sharpeRatio.toFixed(2)}
                  </p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Equity Curve Chart */}
          {equityCurveData.length > 0 ? (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle>Curva de Equity</CardTitle>
                <CardDescription>Acúmulo de P&L ao longo dos trades</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <AreaChart data={equityCurveData}>
                    <defs>
                      <linearGradient id="colorEquity" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="trade" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip
                      contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }}
                      formatter={(value: any) => value.toFixed(2)}
                    />
                    <Area
                      type="monotone"
                      dataKey="equity"
                      stroke="#06b6d4"
                      fillOpacity={1}
                      fill="url(#colorEquity)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardContent className="py-8">
                <div className="text-center">
                  <AlertCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                  <p className="text-slate-400">Nenhum trade encontrado para este backtest</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Drawdown Chart */}
          {drawdownData.length > 0 && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle>Drawdown</CardTitle>
                <CardDescription>Redução percentual do equity em relação ao máximo</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={drawdownData}>
                    <defs>
                      <linearGradient id="colorDrawdown" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="trade" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip
                      contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }}
                      formatter={(value: any) => value.toFixed(2) + "%"}
                    />
                    <Area
                      type="monotone"
                      dataKey="drawdown"
                      stroke="#ef4444"
                      fillOpacity={1}
                      fill="url(#colorDrawdown)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          {/* Trade Distribution */}
          {tradeDistribution.length > 0 && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle>Distribuição de P&L</CardTitle>
                <CardDescription>Histograma de P&L por trade</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={tradeDistribution}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="range" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip
                      contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }}
                    />
                    <Bar dataKey="count" fill="#06b6d4" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          {/* Detailed Risk Metrics */}
          {riskMetrics && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle>Métricas Detalhadas de Risco</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-xs text-slate-400 mb-1">Retorno Médio</p>
                    <p className="text-lg font-bold text-white">
                      {riskMetrics.avgReturn.toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 mb-1">Desvio Padrão</p>
                    <p className="text-lg font-bold text-white">
                      {riskMetrics.stdDev.toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 mb-1">Profit Factor</p>
                    <p className="text-lg font-bold text-white">
                      {riskMetrics.profitFactor.toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 mb-1">Trades Vencedores</p>
                    <p className="text-lg font-bold text-green-400">
                      {riskMetrics.winningTrades} / {riskMetrics.winningTrades + riskMetrics.losingTrades}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
