import { useEffect, useState } from 'react';

export default function BacktestPage() {
  const [iframeKey, setIframeKey] = useState(Date.now());

  useEffect(() => {
    // Force reload iframe on mount
    setIframeKey(Date.now());
  }, []);

  return (
    <div className="w-full h-screen">
      <iframe
        key={iframeKey}
        src={`/backtest-dashboard-v18.html?v=${iframeKey}`}
        className="w-full h-full border-0"
        title="Backtest Analysis"
      />
    </div>
  );
}
