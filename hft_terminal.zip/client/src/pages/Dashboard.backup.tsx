/**
 * client/src/pages/Dashboard.tsx
 * Live Market Dashboard - Institutional Grade (Citadel/Renaissance Standard)
 * 100% live market data, ZERO backtest elements
 */

import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar, Line, Pie } from "react-chartjs-2";

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

export default function Dashboard() {
  const [autoRefresh, setAutoRefresh] = useState(true);
  const { data, isLoading, refetch } = trpc.dashboard.getAllData.useQuery();

  // Auto-refresh every 10 seconds
  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => refetch(), 10000);
    return () => clearInterval(interval);
  }, [autoRefresh, refetch]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-20 w-full" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {[...Array(10)].map((_, i) => (
            <Skeleton key={i} className="h-96" />
          ))}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Card className="bg-slate-900/50 border-slate-700 max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-slate-400">
              Erro ao carregar dados de mercado. Verifique as integrações.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { brazilian, indices, forex, commodities, adrs, brazilianStocks, fairPrice, probabilities } = data;

  // Chart.js theme config (dark mode)
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: {
          color: "#cbd5e1",
          font: { size: 11 },
        },
      },
      tooltip: {
        backgroundColor: "rgba(15, 23, 42, 0.95)",
        titleColor: "#f1f5f9",
        bodyColor: "#cbd5e1",
        borderColor: "#475569",
        borderWidth: 1,
      },
    },
    scales: {
      x: {
        ticks: { color: "#94a3b8", font: { size: 10 } },
        grid: { color: "rgba(71, 85, 105, 0.2)" },
      },
      y: {
        ticks: { color: "#94a3b8", font: { size: 10 } },
        grid: { color: "rgba(71, 85, 105, 0.2)" },
      },
    },
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Live Market Dashboard
            </span>
          </h1>
          <p className="text-sm text-slate-400 mt-2">
            {brazilian.winfut ? (
              <>
                WINFUT {brazilian.winfut.last?.toFixed(0)} pts ({brazilian.winfut.varPct >= 0 ? "+" : ""}
                {brazilian.winfut.varPct?.toFixed(2)}%) • USD/BRL {forex["BRLUSD=X"]?.last?.toFixed(4)} • {new Date(data.lastUpdate).toLocaleTimeString("pt-BR")}
              </>
            ) : (
              "Aguardando dados de mercado..."
            )}
          </p>
        </div>
        <button
          onClick={() => setAutoRefresh(!autoRefresh)}
          className={`px-5 py-2.5 rounded-lg text-sm font-semibold transition-all ${
            autoRefresh
              ? "bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg shadow-cyan-500/30"
              : "bg-slate-800 text-slate-400 border border-slate-700"
          }`}
        >
          {autoRefresh ? "🔄 Auto-Refresh ON" : "⏸️ Auto-Refresh OFF"}
        </button>
      </div>

      {/* Grid Layout - 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Índices Internacionais */}
        <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-cyan-400 text-sm uppercase tracking-wider flex items-center gap-2">
              <span className="text-lg">📊</span> Índices Internacionais
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <Bar
                data={{
                  labels: Object.keys(indices).map((k) => k.replace("^", "")),
                  datasets: [
                    {
                      label: "Variação %",
                      data: Object.values(indices).map((v: any) => v.varPct),
                      backgroundColor: Object.values(indices).map((v: any) =>
                        v.varPct >= 0 ? "rgba(34, 197, 94, 0.7)" : "rgba(239, 68, 68, 0.7)"
                      ),
                      borderColor: Object.values(indices).map((v: any) =>
                        v.varPct >= 0 ? "rgb(34, 197, 94)" : "rgb(239, 68, 68)"
                      ),
                      borderWidth: 1,
                    },
                  ],
                }}
                options={chartOptions}
              />
            </div>
          </CardContent>
        </Card>

        {/* 2. Moedas (Forex) */}
        <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-purple-400 text-sm uppercase tracking-wider flex items-center gap-2">
              <span className="text-lg">💱</span> Moedas (Forex)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <Bar
                data={{
                  labels: Object.keys(forex).map((k) => k.replace("USD=X", "").replace("=X", "/USD")),
                  datasets: [
                    {
                      label: "Variação %",
                      data: Object.values(forex).map((v: any) => v.varPct),
                      backgroundColor: Object.values(forex).map((v: any) =>
                        v.varPct >= 0 ? "rgba(168, 85, 247, 0.7)" : "rgba(239, 68, 68, 0.7)"
                      ),
                      borderColor: Object.values(forex).map((v: any) =>
                        v.varPct >= 0 ? "rgb(168, 85, 247)" : "rgb(239, 68, 68)"
                      ),
                      borderWidth: 1,
                    },
                  ],
                }}
                options={chartOptions}
              />
            </div>
          </CardContent>
        </Card>

        {/* 3. Commodities */}
        <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-yellow-400 text-sm uppercase tracking-wider flex items-center gap-2">
              <span className="text-lg">🛢️</span> Commodities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <Bar
                data={{
                  labels: Object.keys(commodities).map((k) => k.replace("=F", "")),
                  datasets: [
                    {
                      label: "Variação %",
                      data: Object.values(commodities).map((v: any) => v.varPct),
                      backgroundColor: Object.values(commodities).map((v: any) =>
                        v.varPct >= 0 ? "rgba(234, 179, 8, 0.7)" : "rgba(239, 68, 68, 0.7)"
                      ),
                      borderColor: Object.values(commodities).map((v: any) =>
                        v.varPct >= 0 ? "rgb(234, 179, 8)" : "rgb(239, 68, 68)"
                      ),
                      borderWidth: 1,
                    },
                  ],
                }}
                options={chartOptions}
              />
            </div>
          </CardContent>
        </Card>

        {/* 4. Top 12 Blueships IBOV */}
        <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-green-400 text-sm uppercase tracking-wider flex items-center gap-2">
              <span className="text-lg">🏆</span> Top 12 Blueships IBOV
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-slate-900">
                  <tr className="border-b border-slate-700">
                    <th className="text-left py-2 text-slate-400 font-medium">Ação</th>
                    <th className="text-right py-2 text-slate-400 font-medium">Preço</th>
                    <th className="text-right py-2 text-slate-400 font-medium">Var %</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(brazilianStocks)
                    .sort(([, a]: any, [, b]: any) => b.varPct - a.varPct)
                    .slice(0, 12)
                    .map(([symbol, data]: [string, any]) => (
                      <tr key={symbol} className="border-b border-slate-800 hover:bg-slate-800/30">
                        <td className="py-2 font-medium text-white">{symbol.replace(".SA", "")}</td>
                        <td className="py-2 text-right text-slate-300">R$ {data.last?.toFixed(2)}</td>
                        <td className={`py-2 text-right font-semibold ${data.varPct >= 0 ? "text-green-400" : "text-red-400"}`}>
                          {data.varPct >= 0 ? "▲" : "▼"} {Math.abs(data.varPct).toFixed(2)}%
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* 5. Preço Justo - Índice */}
        {fairPrice.indice && (
          <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-cyan-400 text-sm uppercase tracking-wider flex items-center gap-2">
                <span className="text-lg">⚖️</span> Preço Justo - Índice
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-xs text-slate-400 mb-1">ABERT.</p>
                  <p className="text-xl font-bold text-yellow-400">{fairPrice.indice.abert.toFixed(0)}</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-slate-400 mb-1">JUSTO</p>
                  <p className="text-xl font-bold text-cyan-400">{fairPrice.indice.justo.toFixed(0)}</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-slate-400 mb-1">MAX.</p>
                  <p className="text-xl font-bold text-green-400">{fairPrice.indice.max.toFixed(0)}</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-slate-400 mb-1">MIN.</p>
                  <p className="text-xl font-bold text-red-400">{fairPrice.indice.min.toFixed(0)}</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-slate-400 mb-1">AMPLIT. MÉDIA</p>
                  <p className="text-lg font-semibold text-white">{fairPrice.indice.amplitMedia.toFixed(0)} pts</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-slate-400 mb-1">AMPLIT. DIA</p>
                  <p className="text-lg font-semibold text-white">{fairPrice.indice.amplitDia.toFixed(0)} pts</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* 6. Probabilidades - Índice */}
        {probabilities.indice && (
          <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-400 text-sm uppercase tracking-wider flex items-center gap-2">
                <span className="text-lg">🎲</span> Probabilidades - Índice
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-3xl">🐂</span>
                      <span className="text-sm text-slate-400 font-medium">COMPRA</span>
                    </div>
                    <span className="text-3xl font-bold text-green-400">{probabilities.indice.buy}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-4 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-green-500 to-green-400 h-4 transition-all duration-500"
                      style={{ width: `${probabilities.indice.buy}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-3xl">🐻</span>
                      <span className="text-sm text-slate-400 font-medium">VENDA</span>
                    </div>
                    <span className="text-3xl font-bold text-red-400">{probabilities.indice.sell}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-4 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-red-500 to-red-400 h-4 transition-all duration-500"
                      style={{ width: `${probabilities.indice.sell}%` }}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* 7. ADRs EUA */}
        <Card className="bg-slate-900/50 border-slate-700 backdrop-blur-sm lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-pink-400 text-sm uppercase tracking-wider flex items-center gap-2">
              <span className="text-lg">🇺🇸</span> ADRs - EUA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(adrs).map(([symbol, data]: [string, any]) => (
                <div key={symbol} className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                  <p className="text-xs text-slate-400 mb-1">{symbol}</p>
                  <p className="text-2xl font-bold text-white mb-1">${data.last?.toFixed(2)}</p>
                  <p className={`text-sm font-semibold ${data.varPct >= 0 ? "text-green-400" : "text-red-400"}`}>
                    {data.varPct >= 0 ? "▲" : "▼"} {Math.abs(data.varPct).toFixed(2)}%
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <div className="text-center text-sm text-slate-500 pt-6 border-t border-slate-800">
        <p>Última atualização: {new Date(data.lastUpdate).toLocaleString("pt-BR")} • Dados em tempo real via Profit DDE + Yahoo Finance</p>
        <p className="mt-1">Made with Manus 🚀 • Institutional Grade Dashboard</p>
      </div>
    </div>
  );
}
