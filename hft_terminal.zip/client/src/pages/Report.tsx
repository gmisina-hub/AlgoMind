import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Loader2, Download, TrendingUp, TrendingDown, Trophy } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function ReportPage() {
  const [selectedBacktest, setSelectedBacktest] = useState<number | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  // Fetch backtests
  const { data: backtestsData, isLoading: backtestsLoading } = trpc.backtest.getUserBacktests.useQuery();
  const backtests = backtestsData?.data || [];

  // Fetch robot performance for selected backtest
  const { data: performanceData } = trpc.backtest.getRobotPerformance.useQuery(
    { backtestId: selectedBacktest || 0 },
    { enabled: selectedBacktest !== null }
  );
  const robots = performanceData?.data || [];

  const selectedBacktestData = backtests.find((b: any) => b.id === selectedBacktest);

  const formatCurrency = (value: number | string) => {
    const num = typeof value === "string" ? parseFloat(value) : value;
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
      minimumFractionDigits: 2,
    }).format(num);
  };

  const formatPercent = (value: number | string) => {
    const num = typeof value === "string" ? parseFloat(value) : value;
    return `${num.toFixed(2)}%`;
  };

  const generatePDF = async () => {
    if (!selectedBacktest || !selectedBacktestData) return;

    setIsGenerating(true);
    try {
      // Criar conteúdo HTML para o PDF
      const htmlContent = `
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Relatório de Performance - ${selectedBacktestData.fileName}</title>
          <style>
            * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
            }
            body {
              font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
              background: #0f172a;
              color: #e2e8f0;
              line-height: 1.6;
            }
            .container {
              max-width: 1200px;
              margin: 0 auto;
              padding: 40px;
              background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            }
            .header {
              text-align: center;
              margin-bottom: 40px;
              border-bottom: 2px solid #0ea5e9;
              padding-bottom: 30px;
            }
            .header h1 {
              font-size: 32px;
              font-weight: bold;
              color: #06b6d4;
              margin-bottom: 10px;
            }
            .header p {
              color: #94a3b8;
              font-size: 14px;
            }
            .metrics-grid {
              display: grid;
              grid-template-columns: repeat(4, 1fr);
              gap: 20px;
              margin-bottom: 40px;
            }
            .metric-card {
              background: rgba(30, 41, 59, 0.5);
              border: 1px solid #334155;
              border-radius: 8px;
              padding: 20px;
              text-align: center;
            }
            .metric-label {
              color: #94a3b8;
              font-size: 12px;
              text-transform: uppercase;
              margin-bottom: 10px;
            }
            .metric-value {
              font-size: 24px;
              font-weight: bold;
              color: #06b6d4;
            }
            .metric-value.positive {
              color: #10b981;
            }
            .metric-value.negative {
              color: #ef4444;
            }
            .section {
              margin-bottom: 40px;
            }
            .section-title {
              font-size: 20px;
              font-weight: bold;
              color: #06b6d4;
              margin-bottom: 20px;
              border-left: 4px solid #0ea5e9;
              padding-left: 15px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              background: rgba(30, 41, 59, 0.5);
              border: 1px solid #334155;
              border-radius: 8px;
              overflow: hidden;
            }
            th {
              background: rgba(15, 23, 42, 0.8);
              color: #0ea5e9;
              padding: 15px;
              text-align: left;
              font-weight: 600;
              border-bottom: 2px solid #334155;
            }
            td {
              padding: 12px 15px;
              border-bottom: 1px solid #334155;
            }
            tr:last-child td {
              border-bottom: none;
            }
            .footer {
              text-align: center;
              margin-top: 40px;
              padding-top: 20px;
              border-top: 1px solid #334155;
              color: #64748b;
              font-size: 12px;
            }
            .badge {
              display: inline-block;
              padding: 4px 12px;
              border-radius: 4px;
              font-size: 12px;
              font-weight: 600;
            }
            .badge-success {
              background: rgba(16, 185, 129, 0.2);
              color: #10b981;
            }
            .badge-warning {
              background: rgba(245, 158, 11, 0.2);
              color: #f59e0b;
            }
            .badge-danger {
              background: rgba(239, 68, 68, 0.2);
              color: #ef4444;
            }
            @media print {
              body {
                background: white;
                color: #000;
              }
              .container {
                background: white;
              }
              .metric-card {
                background: #f3f4f6;
                border: 1px solid #d1d5db;
              }
              table {
                background: white;
                border: 1px solid #d1d5db;
              }
              th {
                background: #f3f4f6;
                color: #000;
                border-bottom: 2px solid #d1d5db;
              }
              td {
                border-bottom: 1px solid #d1d5db;
              }
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>📊 Relatório de Performance</h1>
              <p>${selectedBacktestData.fileName}</p>
              <p>Gerado em ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}</p>
            </div>

            <div class="metrics-grid">
              <div class="metric-card">
                <div class="metric-label">Total de Robôs</div>
                <div class="metric-value">${robots.length}</div>
              </div>
              <div class="metric-card">
                <div class="metric-label">P&L Total</div>
                <div class="metric-value ${robots.reduce((sum: number, r: any) => sum + (parseFloat(r.totalPnl) || 0), 0) >= 0 ? 'positive' : 'negative'}">
                  ${formatCurrency(robots.reduce((sum: number, r: any) => sum + (parseFloat(r.totalPnl) || 0), 0))}
                </div>
              </div>
              <div class="metric-card">
                <div class="metric-label">Win Rate Médio</div>
                <div class="metric-value">
                  ${formatPercent(
                    robots.length > 0
                      ? robots.reduce((sum: number, r: any) => sum + (parseFloat(r.winRate) || 0), 0) / robots.length
                      : 0
                  )}
                </div>
              </div>
              <div class="metric-card">
                <div class="metric-label">Total de Trades</div>
                <div class="metric-value">${robots.reduce((sum: number, r: any) => sum + (r.totalTrades || 0), 0)}</div>
              </div>
            </div>

            <div class="section">
              <div class="section-title">🏆 Ranking de Robôs</div>
              <table>
                <thead>
                  <tr>
                    <th>Robô</th>
                    <th>P&L</th>
                    <th>Win Rate</th>
                    <th>Profit Factor</th>
                    <th>Trades</th>
                    <th>Max DD</th>
                  </tr>
                </thead>
                <tbody>
                  ${robots
                    .sort((a: any, b: any) => (parseFloat(b.totalPnl) || 0) - (parseFloat(a.totalPnl) || 0))
                    .map(
                      (robot: any, index: number) => `
                    <tr>
                      <td><strong>${index + 1}. ${robot.robotName}</strong></td>
                      <td class="${parseFloat(robot.totalPnl) >= 0 ? 'positive' : 'negative'}" style="color: ${parseFloat(robot.totalPnl) >= 0 ? '#10b981' : '#ef4444'}">
                        ${formatCurrency(robot.totalPnl)}
                      </td>
                      <td>${formatPercent(robot.winRate)}</td>
                      <td>${parseFloat(robot.profitFactor).toFixed(2)}</td>
                      <td>${robot.totalTrades}</td>
                      <td>${formatPercent(robot.maxDrawdown)}</td>
                    </tr>
                  `
                    )
                    .join("")}
                </tbody>
              </table>
            </div>

            <div class="section">
              <div class="section-title">📈 Resumo Executivo</div>
              <div style="background: rgba(30, 41, 59, 0.5); border: 1px solid #334155; border-radius: 8px; padding: 20px; line-height: 1.8;">
                <p><strong>Período Analisado:</strong> ${selectedBacktestData.fileName}</p>
                <p><strong>Total de Robôs:</strong> ${robots.length}</p>
                <p><strong>Total de Trades Executados:</strong> ${robots.reduce((sum: number, r: any) => sum + (r.totalTrades || 0), 0)}</p>
                <p><strong>Resultado Total:</strong> <span style="color: ${robots.reduce((sum: number, r: any) => sum + (parseFloat(r.totalPnl) || 0), 0) >= 0 ? '#10b981' : '#ef4444'}; font-weight: bold;">${formatCurrency(robots.reduce((sum: number, r: any) => sum + (parseFloat(r.totalPnl) || 0), 0))}</span></p>
                <p><strong>Taxa de Acerto Média:</strong> ${formatPercent(robots.length > 0 ? robots.reduce((sum: number, r: any) => sum + (parseFloat(r.winRate) || 0), 0) / robots.length : 0)}</p>
              </div>
            </div>

            <div class="footer">
              <p>Relatório gerado automaticamente pelo HFT Terminal</p>
              <p>© ${new Date().getFullYear()} - Algomind Control Center</p>
            </div>
          </div>
        </body>
        </html>
      `;

      // Criar blob e fazer download
      const blob = new Blob([htmlContent], { type: "text/html" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `relatorio_${selectedBacktestData.fileName.replace(".xlsx", "")}_${new Date().toISOString().split("T")[0]}.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Erro ao gerar relatório:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white">Relatórios</h1>
        <p className="text-slate-400 mt-1">Gere relatórios executivos em PDF</p>
      </div>

      {/* Backtest Selector */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-sm">Selecionar Backtest</CardTitle>
        </CardHeader>
        <CardContent>
          {backtestsLoading ? (
            <div className="flex items-center gap-2">
              <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
              <span className="text-sm text-slate-400">Carregando backtests...</span>
            </div>
          ) : backtests.length === 0 ? (
            <p className="text-sm text-slate-400">Nenhum backtest disponível. Envie um arquivo primeiro.</p>
          ) : (
            <Select value={selectedBacktest?.toString() || ""} onValueChange={(val) => setSelectedBacktest(val ? Number(val) : null)}>
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                <SelectValue placeholder="Selecione um backtest" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                {backtests.map((bt: any) => (
                  <SelectItem key={bt.id} value={bt.id.toString()}>
                    {bt.fileName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </CardContent>
      </Card>

      {selectedBacktest && selectedBacktestData && (
        <>
          {/* Preview */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-lg">Prévia do Relatório</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Metrics Grid */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card className="bg-slate-700/50 border-slate-600">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-slate-400">Total de Robôs</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold text-white">{robots.length}</p>
                  </CardContent>
                </Card>

                <Card className="bg-slate-700/50 border-slate-600">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-slate-400">P&L Total</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className={`text-2xl font-bold ${robots.reduce((sum: number, r: any) => sum + (parseFloat(r.totalPnl) || 0), 0) >= 0 ? "text-green-400" : "text-red-400"}`}>
                      {formatCurrency(robots.reduce((sum: number, r: any) => sum + (parseFloat(r.totalPnl) || 0), 0))}
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-slate-700/50 border-slate-600">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-slate-400">Win Rate Médio</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold text-cyan-400">
                      {formatPercent(robots.length > 0 ? robots.reduce((sum: number, r: any) => sum + (parseFloat(r.winRate) || 0), 0) / robots.length : 0)}
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-slate-700/50 border-slate-600">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-slate-400">Total de Trades</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold text-white">
                      {robots.reduce((sum: number, r: any) => sum + (r.totalTrades || 0), 0)}
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Top Robots */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Top 5 Robôs</h3>
                <div className="space-y-2">
                  {robots
                    .sort((a: any, b: any) => (parseFloat(b.totalPnl) || 0) - (parseFloat(a.totalPnl) || 0))
                    .slice(0, 5)
                    .map((robot: any, index: number) => (
                      <div key={robot.id} className="flex items-center justify-between p-3 bg-slate-700/50 border border-slate-600 rounded">
                        <div className="flex items-center gap-3">
                          <Trophy className={`w-5 h-5 ${index === 0 ? "text-yellow-400" : index === 1 ? "text-gray-400" : "text-orange-400"}`} />
                          <div>
                            <p className="font-semibold text-white">{robot.robotName}</p>
                            <p className="text-xs text-slate-400">{robot.totalTrades} trades</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`font-bold ${parseFloat(robot.totalPnl) >= 0 ? "text-green-400" : "text-red-400"}`}>
                            {formatCurrency(robot.totalPnl)}
                          </p>
                          <p className="text-xs text-slate-400">{formatPercent(robot.winRate)}</p>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Generate Button */}
          <Button
            onClick={generatePDF}
            disabled={isGenerating}
            className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-semibold py-3 rounded-lg flex items-center justify-center gap-2"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Gerando relatório...
              </>
            ) : (
              <>
                <Download className="w-5 h-5" />
                Baixar Relatório em HTML
              </>
            )}
          </Button>
        </>
      )}
    </div>
  );
}
