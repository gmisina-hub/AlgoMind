import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";

export default function Risk() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white">Risk Management</h1>
        <p className="text-slate-400 mt-1">Monitoramento e controle de riscos</p>
      </div>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            Risk Dashboard
          </CardTitle>
          <CardDescription>Análise de riscos em desenvolvimento</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center bg-slate-700/30 rounded-lg border border-slate-600">
            <p className="text-slate-400">Conteúdo em desenvolvimento...</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
