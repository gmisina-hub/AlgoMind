/**
 * client/src/pages/Dashboard.tsx
 * ENTREGA 1: WINFUT Core Básico
 * Layout 12 colunas, 4 zonas, paleta institucional (#0A0F1A, #0AFF7C, #FF3B5C, #00E5FF)
 */

import React, { useEffect, useState } from "react";
import { Toaster } from "sonner";
import { useAlertSound } from "@/hooks/useAlertSound";
// import { useAlerts } from "@/hooks/useAlerts"; // TODO: Fix React hooks error
import { CustomAlertBuilder } from "@/components/CustomAlertBuilder";
import { trpc } from "@/lib/trpc";
import { PivotCard } from "@/components/PivotCard";
import { FibonacciCard } from "@/components/FibonacciCard";
import { ProjectionCard } from "@/components/ProjectionCard";
import { AIRecommendationCard } from "@/components/AIRecommendationCard";
import { AIHistoryCard } from "@/components/AIHistoryCard";
import { VolumeProfileCard } from "@/components/VolumeProfileCard";

import { MacroCascadeCard } from "@/components/MacroCascadeCard";
import { TechnicalLevelsCard } from "@/components/TechnicalLevelsCard";


export default function Dashboard() {
  const autoRefresh = true; // Sempre ativo
  
  // Verificar se mercado está aberto (9h-18h horário de Brasília)
  const isMarketOpen = (): boolean => {
    const now = new Date();
    // Converter para horário de Brasília (UTC-3)
    const brasiliaTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' }));
    const hour = brasiliaTime.getHours();
    const day = brasiliaTime.getDay(); // 0 = Sunday, 6 = Saturday
    
    // Mercado aberto: Segunda a Sexta, 9h-18h
    const isWeekday = day >= 1 && day <= 5;
    const isDuringMarketHours = hour >= 9 && hour < 18;
    
    return isWeekday && isDuringMarketHours;
  };
  
  // Format number with thousand separator
  const formatNumber = (num: number): string => {
    return num.toFixed(0).replace(/(\d)(?=(\d{3})+$)/g, '$1.');
  };
  
  // Polling control
  const startPollingMutation = trpc.dashboard.startPolling.useMutation();
  const stopPollingMutation = trpc.dashboard.stopPolling.useMutation();
  const { data: pollingStatus } = trpc.dashboard.getPollingStatus.useQuery({
    refetchInterval: 1000, // Check status every 1 second for instant feedback
  });
  const pollingActive = pollingStatus?.active || false;
  
  // Query tick count for status indicator
  const { data: tickCount } = trpc.dashboard.getTickCount.useQuery(void 0, {
    refetchInterval: pollingActive ? 2000 : false, // Refresh every 2s when polling is active
  });
  const [lastUpdate, setLastUpdate] = useState(new Date());
  


  // Fetch dashboard data with auto-refresh
  const { data, isLoading, refetch } = trpc.dashboard.getAllData.useQuery(void 0, {
    refetchInterval: autoRefresh ? 2000 : false, // 2 seconds for ultra real-time feel
  });
  
  // MVP Queries - Edge Real (MUST be before early return to respect React hooks rules)
  const { data: volumeProfileData } = trpc.dashboard.getVolumeProfile.useQuery(void 0, {
    refetchInterval: autoRefresh ? 2000 : false,
  });
  

  
  const { data: macroCascadeData } = trpc.dashboard.getMacroCascade.useQuery(void 0, {
    refetchInterval: autoRefresh ? 2000 : false,
  });
  
  const { data: aiRecommendationData, isLoading: aiLoading } = trpc.dashboard.getAIRecommendation.useQuery(
    {
      context: {
        currentPrice: data?.brazilian?.winfut?.last || 0,
        varPts: data?.brazilian?.winfut?.varPts || 0,
        varPct: ((data?.brazilian?.winfut?.varPts || 0) / (data?.brazilian?.winfut?.last || 1)) * 100,
        volume: data?.brazilian?.winfut?.volume || 0,
        rsi: data?.brazilian?.winfut?.rsi || 50,
        vwap: data?.brazilian?.winfut?.vwap || 0,
        trueRange: data?.brazilian?.winfut?.trueRange || 0,
        accumBalance: data?.proprietaryMetrics?.accumBalance || 0,
        fibonacci: {
          level_0: data?.technicalIndicators?.fibonacci?.fib000 || 0,
          level_236: data?.technicalIndicators?.fibonacci?.fib236 || 0,
          level_382: data?.technicalIndicators?.fibonacci?.fib382 || 0,
          level_50: data?.technicalIndicators?.fibonacci?.fib500 || 0,
          level_618: data?.technicalIndicators?.fibonacci?.fib618 || 0,
          level_100: data?.technicalIndicators?.fibonacci?.fib1000 || 0,
        },
        pivotPoints: {
          r2: data?.technicalIndicators?.pivotPoints?.r2 || 0,
          r1: data?.technicalIndicators?.pivotPoints?.r1 || 0,
          pp: data?.technicalIndicators?.pivotPoints?.pp || 0,
          s1: data?.technicalIndicators?.pivotPoints?.s1 || 0,
          s2: data?.technicalIndicators?.pivotPoints?.s2 || 0,
        },
        volumeProfile: volumeProfileData?.profile
          ? {
              poc: volumeProfileData.profile.poc,
              distanceToPOC: volumeProfileData.profile.poc - (data?.brazilian?.winfut?.last || 0),
            }
          : null,

        macro: macroCascadeData && macroCascadeData.vix && macroCascadeData.dxy && macroCascadeData.sp500
          ? {
              vixChange: macroCascadeData.vix.change,
              dxyChange: macroCascadeData.dxy.change,
              sp500Change: macroCascadeData.sp500.change,
              overallSignal: "NEUTRAL" as const,
              confidence: 0,
            }
          : null,
      },
    },
    {
      enabled: !!data?.brazilian?.winfut && !!data?.technicalIndicators,
      refetchInterval: autoRefresh ? 300000 : false, // 5 min (AI is expensive, strategic analysis)
      staleTime: 300000, // Consider data fresh for 5 minutes to avoid unnecessary re-fetches
      placeholderData: (previousData) => previousData, // Mantém última recomendação até nova atualização
    }
  );
  
  // Alert sound (must be after data declaration)
  useAlertSound(data?.technicalIndicators?.alerts);

  useEffect(() => {
    if (data) {
      setLastUpdate(new Date());
    }
  }, [data]);

  // Sistema de Alertas (DISABLED: React hooks error)
  // TODO: Fix useAlerts hook to respect React hooks rules
  // useAlerts({
  //   aiConfidence: aiRecommendationData?.confidence,
  //   aiRecommendation: aiRecommendationData?.recommendation,
  //   darkPoolDetected: darkPoolData?.detection?.detected,
  //   darkPoolConfidence: darkPoolData?.detection?.confidence,
  //   darkPoolDirection: darkPoolData?.detection?.direction,
  //   currentPrice: data?.brazilian?.winfut?.last,
  //   pivotR2: data?.technicalIndicators?.pivotPoints?.r2,
  //   pivotS2: data?.technicalIndicators?.pivotPoints?.s2,
  //   fibonacci618: data?.technicalIndicators?.fibonacci?.fib618,
  // });

  if (isLoading || !data) {
    return (
      <div className="min-h-screen bg-[#0A0F1A] flex items-center justify-center">
        <div className="text-[#E8ECF2] text-xl">Carregando dados de mercado...</div>
      </div>
    );
  }

  const { brazilian, indices, forex, commodities, proprietaryMetrics, technicalIndicators } = data;
  const winfut = brazilian.winfut || {
    last: 0,
    open: 0,
    high: 0,
    low: 0,
    varPts: 0,
    volume: 0,
    rsi: 50,
    vwap: 0,
    vwapMonthly: 0,
    trueRange: 0,
  };

  return (
    <div className="min-h-screen bg-[#0A0F1A] text-[#E8ECF2] p-4">
      <Toaster position="top-right" richColors />
       {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-[#00E5FF] via-[#A966FF] to-[#FF3B5C] bg-clip-text text-transparent">
            Live Market Dashboard
          </h1>
          <div className="text-sm text-[#7F8DA3] mt-1">
            WINFUT {formatNumber(winfut.last)} pts (+{formatNumber(winfut.varPts)}) • USD/BRL {(typeof data.brazilian.dolar?.last === 'number' && isFinite(data.brazilian.dolar.last)) ? data.brazilian.dolar.last.toFixed(4) : "0.0000"} • {new Date().toLocaleTimeString()}
          </div>
          <div className="text-xs text-[#7F8DA3] mt-1">
            Amplitude: <span className="text-[#00E5FF] font-mono font-bold">{formatNumber(winfut.high - winfut.low)} pts</span> • 
            Máxima: <span className="text-green-400 font-mono">{formatNumber(winfut.high)}</span> • 
            Mínima: <span className="text-red-400 font-mono">{formatNumber(winfut.low)}</span>
          </div>
          
          {/* Parâmetros Configuráveis */}
          {technicalIndicators?.config && (
            <div className="flex gap-4 mt-3">
              <div className="text-xs">
                <span className="text-[#7F8DA3]">Taxa DI:</span>
                <span className="ml-2 text-[#00E5FF] font-mono font-bold">
                  {(() => {
                    const val = technicalIndicators.config.diRate * 100;
                    return (typeof val === 'number' && isFinite(val)) ? val.toFixed(2) : "0.00";
                  })()}% a.a.
                </span>
              </div>
              <div className="text-xs">
                <span className="text-[#7F8DA3]">Dias até Vencimento:</span>
                <span className="ml-2 text-[#A966FF] font-mono font-bold">
                  {technicalIndicators.config.daysToExpiry} dias
                </span>
              </div>
              <div className="text-[10px] text-[#7F8DA3] italic">
                (TODO: Conectar com DDE ou API da B3 para valores reais)
              </div>
            </div>
          )}
        </div>
        <div className="flex gap-3">
          {/* Polling Control */}
          <button
            onClick={async () => {
              if (pollingActive) {
                await stopPollingMutation.mutateAsync({});
              } else {
                // Verificar se mercado está aberto antes de iniciar polling
                if (!isMarketOpen()) {
                  alert('⚠️ Mercado Fechado!\n\nDDE Recording só pode ser ativado durante o horário de mercado:\n\u2022 Segunda a Sexta\n\u2022 9h - 18h (horário de Brasília)\n\nIsso evita erros causados por dados inválidos de APIs externas.');
                  return;
                }
                await startPollingMutation.mutateAsync({ intervalSeconds: 2 });
              }
            }}
            disabled={startPollingMutation.isPending || stopPollingMutation.isPending}
            className={`px-4 py-2 rounded-lg font-bold transition-all ${
              pollingActive
                ? "bg-[#0AFF7C] text-[#0A0F1A] shadow-lg shadow-[#0AFF7C]/50"
                : "bg-[#FF3B5C] text-[#E8ECF2] border border-[#FF3B5C]"
            }`}
            title={!isMarketOpen() && !pollingActive ? '⚠️ Mercado fechado - DDE disponível apenas Segunda-Sexta 9h-18h' : ''}
          >
            {pollingActive ? (
              <>
                ▶️ DDE Recording
                {tickCount !== undefined && (
                  <span className="ml-2 text-xs opacity-80">({tickCount} ticks)</span>
                )}
              </>
            ) : (
              <>
                ⏸️ DDE Stopped
                {!isMarketOpen() && <span className="ml-2 text-xs opacity-70">(⚠️ Mercado Fechado)</span>}
              </>
            )}
          </button>

        </div>
      </div>



      {/* Alerts Panel */}
      {technicalIndicators?.alerts && technicalIndicators.alerts.length > 0 && (
        <div className="mb-4 p-4 bg-gradient-to-r from-[#FF3B5C]/20 to-[#FFCA28]/20 border-l-4 border-[#FF3B5C] rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-2xl">⚠️</span>
            <h3 className="text-lg font-bold text-[#FF3B5C]">ALERTAS ATIVOS ({technicalIndicators.alerts.length})</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {technicalIndicators.alerts.map((alert: any) => (
              <div
                key={alert.id}
                className={`p-3 rounded-md border-2 ${
                  alert.direction === "cross_above"
                    ? "bg-[#0AFF7C]/10 border-[#0AFF7C]"
                    : "bg-[#FF3B5C]/10 border-[#FF3B5C]"
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-lg">
                    {alert.direction === "cross_above" ? "↑" : "↓"}
                  </span>
                  <span className="font-bold text-sm">
                    {alert.type === "pivot" && "📍 Pivot"}
                    {alert.type === "fibonacci" && "🟡 Fibonacci"}
                    {alert.type === "projection" && "📈 Projeção"}
                  </span>
                </div>
                <p className="text-xs text-[#E8ECF2]">{alert.message}</p>
                <p className="text-[10px] text-[#7F8DA3] mt-1">
                  {new Date(alert.timestamp).toLocaleTimeString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MVP CARDS - Edge Real */}
      <div className="grid grid-cols-12 gap-6 mb-6">
        {/* AI Recommendation */}
        <div className="col-span-4">
          <AIRecommendationCard
            recommendation={aiRecommendationData?.recommendation || "NEUTRO"}
            confidence={aiRecommendationData?.confidence || 0}
            entry={aiRecommendationData?.entry || winfut.last}
            stopLoss={aiRecommendationData?.stopLoss || winfut.last - 100}
            takeProfit={aiRecommendationData?.takeProfit || winfut.last + 100}
            context={aiRecommendationData?.context || "Aguardando primeira análise..."}
            timestamp={aiRecommendationData?.timestamp}
            isLoading={!aiRecommendationData} // Apenas na primeira carga, depois mantém recomendação
          />
        </div>

        {/* AI History */}
        <div className="col-span-4">
          <AIHistoryCard />
        </div>

        {/* Macro Cascade */}
        <div className="col-span-4">
          <MacroCascadeCard
            vix={{ value: macroCascadeData?.vix?.price || 0, change: macroCascadeData?.vix?.changePercent || 0 }}
            dxy={{ value: macroCascadeData?.dxy?.price || 0, change: macroCascadeData?.dxy?.changePercent || 0 }}
            sp500={{ value: macroCascadeData?.sp500?.price || 0, change: macroCascadeData?.sp500?.changePercent || 0 }}
            overallSignal={macroCascadeData?.signals?.overallSignal || "NEUTRAL"}
            confidence={macroCascadeData?.signals?.confidence || 0}
            isLoading={!macroCascadeData}
          />
        </div>

        {/* Volume Profile */}
        <div className="col-span-4">
          <VolumeProfileCard
            poc={volumeProfileData?.profile?.poc || winfut.vwap || winfut.last}
            distanceToPOC={volumeProfileData?.profile ? (winfut.last - volumeProfileData.profile.poc) : 0}
            currentPrice={winfut.last}
            hvn={volumeProfileData?.profile?.hvns || []}
            lvn={volumeProfileData?.profile?.lvns || []}
            isLoading={!volumeProfileData}
          />
        </div>
      </div>

      {/* Main Grid - 12 columns, 4 zones */}
      <div className="grid grid-cols-12 gap-4">
        {/* ZONE 1: WINFUT CORE (50% top - 12 columns) */}
        <div className="col-span-12 bg-[#0F1522] border border-slate-800 rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-[#00E5FF]">📈 WINFUT CORE</h2>
            <div className="text-sm text-[#7F8DA3]">Market Microstructure</div>
          </div>

          {/* Painel de Métricas - 8 cards (incluindo Valor Justo e Ajuste) */}
          <div className="grid grid-cols-8 gap-3 mb-6">
            <MetricCard label="ÚLTIMO" value={formatNumber(winfut.last)} color="#E8ECF2" />
            <MetricCard label="ABERTURA" value={formatNumber(winfut.open)} color="#7F8DA3" />
            <MetricCard label="MÁXIMA" value={formatNumber(winfut.high)} color="#0AFF7C" />
            <MetricCard label="MÍNIMA" value={formatNumber(winfut.low)} color="#FF3B5C" />
            <MetricCard
              label="VAR PTS"
              value={(winfut.varPts > 0 ? "+" : "") + formatNumber(winfut.varPts)}
              color={winfut.varPts > 0 ? "#0AFF7C" : "#FF3B5C"}
            />
            <MetricCard label="VOLUME" value={formatNumber(winfut.volume / 1000000) + " M"} color="#A966FF" />
            <MetricCard label="AJUSTE" value={formatNumber(winfut.adjust)} color="#FFC107" />
            
            {/* Valor Justo - Card Destacado */}
            {technicalIndicators && (
              <div className="bg-gradient-to-br from-[#FF6B35] to-[#FF8C42] border-2 border-[#FF6B35] rounded-lg p-3 shadow-lg">
                <div className="text-[#FFFFFF] text-xs mb-1 font-bold">🎯 VALOR JUSTO</div>
                <div className="text-2xl font-bold font-mono text-white mb-1">
                  {formatNumber(technicalIndicators.fairValue.fairValue)}
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-white/90">
                    {technicalIndicators.fairValue.premium > 0 ? "Prêmio" : "Desconto"}
                  </span>
                  <span className="font-mono text-white font-bold">
                    {technicalIndicators.fairValue.premium > 0 ? "+" : ""}
                    {formatNumber(Math.abs(technicalIndicators.fairValue.premium))} pts
                  </span>
                </div>
                <div className="text-[10px] text-white/80 mt-1">
                  Spread: {(() => {
                    const val = technicalIndicators.fairValue.spreadPct;
                    return (typeof val === 'number' && isFinite(val)) ? val.toFixed(2) : "0.00";
                  })()}%
                </div>
              </div>
            )}
          </div>
          {/* NÍVEIS TÉCNICOS UNIFICADOS (Pivot Points + Fibonacci + Métricas) */}
          {technicalIndicators?.pivotPoints && technicalIndicators?.fibonacci && (
            <TechnicalLevelsCard
              currentPrice={winfut.last}
              pivotPoints={technicalIndicators.pivotPoints}
              fibonacci={technicalIndicators.fibonacci}
              metrics={{
                rsi: winfut.rsi,
                trueRange: winfut.trueRange,
                accumBalance: winfut.accumBalance,
              }}
            />
          )}

          {/* PROJEÇÃO LINEAR */}
          {technicalIndicators?.projection && (
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-[#00E5FF]">🎯 PROJEÇÃO LINEAR</h3>
                <div className="text-xs text-[#7F8DA3]">Banda de Confiança 95%</div>
              </div>
              <div className="grid grid-cols-3 gap-6">
                <ProjectionCard type="upper" value={technicalIndicators.projection.upperBand} currentPrice={winfut.last} />
                <ProjectionCard type="center" value={technicalIndicators.projection.projected} currentPrice={winfut.last} trend="bearish" />
                <ProjectionCard type="lower" value={technicalIndicators.projection.lowerBand} currentPrice={winfut.last} />
              </div>
            </div>
          )}




        </div>

        {/* ZONE 2: MERCADOS INTERNACIONAIS (6 columns) - Grid 2x2 */}
        <div className="col-span-6 grid grid-cols-2 gap-4">
          {/* Box 1: Ações B3 */}
          {data.brazilian?.otherAssets && (
            <div className="bg-[#0F1522] border border-slate-800 rounded-lg p-4">
              <div className="text-[#00E5FF] text-sm mb-3 uppercase font-bold tracking-wide flex items-center gap-2">
                <span>🇧🇷</span> Ações B3
              </div>
              <div className="space-y-2">
                {[
                  { symbol: "PETR4", name: "Petrobras" },
                  { symbol: "VALE3", name: "Vale" },
                  { symbol: "BBAS3", name: "Banco do Brasil" },
                  { symbol: "ITUB4", name: "Itaú" },
                ].map(({ symbol, name }) => {
                  const price = data.brazilian.otherAssets[symbol];
                  if (!price) return null;
                  return (
                    <div key={symbol} className="bg-[#0A0F1A] border border-slate-700 rounded px-3 py-2">
                      <div className="flex items-center justify-between">
                        <span className="text-white font-bold text-xs">{symbol}</span>
                        <span className="text-white font-mono text-xs">
                          R$ {(typeof price === 'number' && isFinite(price)) ? price.toFixed(2) : "0.00"}
                        </span>
                      </div>
                      <div className="text-[#7F8DA3] text-[10px] mt-1">{name}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Box 2: Commodities BR */}
          {data.brazilian?.otherAssets && (
            <div className="bg-[#0F1522] border border-slate-800 rounded-lg p-4">
              <div className="text-[#00E5FF] text-sm mb-3 uppercase font-bold tracking-wide flex items-center gap-2">
                <span>🌾</span> Commodities BR
              </div>
              <div className="space-y-2">
                {[
                  { symbol: "SJCFUT", name: "Soja", unit: "R$/sc" },
                  { symbol: "CCMFUT", name: "Milho", unit: "R$/sc" },
                  { symbol: "ICFFUT", name: "Café", unit: "R$/sc" },
                ].map(({ symbol, name, unit }) => {
                  const price = data.brazilian.otherAssets[symbol];
                  if (!price) return null;
                  return (
                    <div key={symbol} className="bg-[#0A0F1A] border border-slate-700 rounded px-3 py-2">
                      <div className="text-[#7F8DA3] text-xs mb-1">{name}</div>
                      <div className="text-white font-mono text-sm font-bold">
                        {(typeof price === 'number' && isFinite(price)) ? price.toFixed(2) : "0.00"}
                      </div>
                      <div className="text-[#7F8DA3] text-[10px] mt-1">{unit}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          
          {/* Box 3: Índices */}
          <div className="bg-[#0F1522] border border-slate-800 rounded-lg p-4">
            <div className="text-[#00E5FF] text-sm mb-3 uppercase font-bold tracking-wide flex items-center gap-2">
              <span>📊</span> Índices
            </div>
            <div className="space-y-1">
              {Object.entries(indices).slice(0, 5).map(([symbol, data]: [string, any]) => (
                <SparklineRow key={symbol} label={symbol.replace("^", "")} value={data.last} change={data.varPct} />
              ))}
            </div>
          </div>

          {/* Box 4: Commodities Globais */}
          <div className="bg-[#0F1522] border border-slate-800 rounded-lg p-4">
            <div className="text-[#00E5FF] text-sm mb-3 uppercase font-bold tracking-wide flex items-center gap-2">
              <span>🛢️</span> Commodities Globais
            </div>
            <div className="space-y-1">
              {Object.entries(commodities).slice(0, 5).map(([symbol, data]: [string, any]) => (
                <SparklineRow key={symbol} label={symbol.replace("=F", "")} value={data.last} change={data.varPct} />
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {/* ZONE 4: ALERTAS CUSTOMIZÁVEIS (full width below) */}
      <div className="mt-6">
        <CustomAlertBuilder />
      </div>
    </div>
  );
}

// Metric Card Component
function MetricCard({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="bg-[#0A0F1A] border border-slate-800 rounded-lg p-3">
      <div className="text-[#7F8DA3] text-xs mb-1">{label}</div>
      <div className="text-2xl font-bold font-mono" style={{ color }}>
        {value}
      </div>
    </div>
  );
}





// Sparkline Row Component
function SparklineRow({ label, value, change }: { label: string; value: number; change: number }) {
  const changeColor = change > 0 ? "#0AFF7C" : "#FF3B5C";
  return (
    <div className="flex items-center justify-between py-2 border-b border-slate-800">
      <div className="text-sm font-medium text-[#E8ECF2]">{label}</div>
      <div className="flex items-center gap-3">
        <div className="text-sm font-mono text-[#7F8DA3]">{(typeof value === 'number' && isFinite(value)) ? value.toFixed(2) : "0.00"}</div>
        <div className="text-sm font-mono" style={{ color: changeColor }}>
          {change > 0 ? "+" : ""}
          {(typeof change === 'number' && isFinite(change)) ? change.toFixed(2) : "0.00"}%
        </div>
      </div>
    </div>
  );
}

// Correlation Heatmap Component
function CorrelationHeatmap({ winfut, indices, commodities }: { winfut: any; indices: any; commodities: any }) {
  // Calculate mock correlations (replace with real calculation later)
  const dxy = indices["DXY"] || { varPct: 0 };
  const sp500 = indices["^GSPC"] || { varPct: 0 };
  const cl = commodities["CL=F"] || { varPct: 0 }; // WTI Crude Oil

  // Simplified correlation: based on % change direction
  const winfutChange = winfut.varPts || 0;
  const correlations = [
    { asset: "WINFUT", value: 1.0, color: "#0AFF7C" },
    { asset: "DXY", value: calculateCorrelation(winfutChange, dxy.varPct), color: getCorrelationColor(calculateCorrelation(winfutChange, dxy.varPct)) },
    { asset: "S&P500", value: calculateCorrelation(winfutChange, sp500.varPct), color: getCorrelationColor(calculateCorrelation(winfutChange, sp500.varPct)) },
    { asset: "WTI", value: calculateCorrelation(winfutChange, cl.varPct), color: getCorrelationColor(calculateCorrelation(winfutChange, cl.varPct)) },
  ];

  return (
    <div className="grid grid-cols-2 gap-3">
      {correlations.map((item) => (
        <div key={item.asset} className="bg-[#0A0F1A] border border-slate-800 rounded-lg p-4">
          <div className="text-xs text-[#7F8DA3] mb-2">{item.asset}</div>
          <div className="text-2xl font-bold font-mono" style={{ color: item.color }}>
            {(typeof item.value === 'number' && isFinite(item.value)) ? item.value.toFixed(2) : "0.00"}
          </div>
          <div className="text-xs text-[#7F8DA3] mt-1">
            {item.value > 0.7 ? "Alta +" : item.value < -0.7 ? "Alta -" : item.value > 0.3 ? "Média +" : item.value < -0.3 ? "Média -" : "Baixa"}
          </div>
        </div>
      ))}
    </div>
  );
}

// Helper: Calculate simplified correlation
function calculateCorrelation(a: number, b: number): number {
  // Simplified: same direction = positive, opposite = negative
  if (a === 0 || b === 0) return 0;
  const sameDirection = (a > 0 && b > 0) || (a < 0 && b < 0);
  const strength = Math.min(Math.abs(a) / 1000, 1) * Math.min(Math.abs(b) / 5, 1);
  return sameDirection ? strength : -strength;
}

// Helper: Get correlation color
function getCorrelationColor(corr: number): string {
  if (corr > 0.7) return "#0AFF7C"; // Strong positive
  if (corr > 0.3) return "#00E5FF"; // Medium positive
  if (corr > -0.3) return "#7F8DA3"; // Weak
  if (corr > -0.7) return "#FFCA28"; // Medium negative
  return "#FF3B5C"; // Strong negative
}
