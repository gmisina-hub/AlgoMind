import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Loader2, TrendingUp, TrendingDown, Trophy, AlertCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from "recharts";

type SortField = "totalPnl" | "winRate" | "profitFactor" | "totalTrades" | "maxDrawdown";

export default function RobotRankingPage() {
  const [selectedBacktest, setSelectedBacktest] = useState<number | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<string>("all");
  const [sortBy, setSortBy] = useState<SortField>("totalPnl");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  // Fetch backtests
  const { data: backtestsData, isLoading: backtestsLoading } = trpc.backtest.getUserBacktests.useQuery();
  const backtests = backtestsData?.data || [];

  // Fetch robot performance for selected backtest
  const { data: performanceData, isLoading: performanceLoading } = trpc.backtest.getRobotPerformance.useQuery(
    { backtestId: selectedBacktest || 0 },
    { enabled: selectedBacktest !== null }
  );
  const robots = performanceData?.data || [];

  // Sort robots
  const sortedRobots = [...robots].sort((a: any, b: any) => {
    let aVal = a[sortBy] || 0;
    let bVal = b[sortBy] || 0;

    if (typeof aVal === "string") aVal = parseFloat(aVal);
    if (typeof bVal === "string") bVal = parseFloat(bVal);

    return sortOrder === "desc" ? bVal - aVal : aVal - bVal;
  });

  const handleSort = (field: SortField) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === "desc" ? "asc" : "desc");
    } else {
      setSortBy(field);
      setSortOrder("desc");
    }
  };

  const formatCurrency = (value: number | string) => {
    const num = typeof value === "string" ? parseFloat(value) : value;
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
      minimumFractionDigits: 2,
    }).format(num);
  };

  const formatPercent = (value: number | string) => {
    const num = typeof value === "string" ? parseFloat(value) : value;
    return `${num.toFixed(2)}%`;
  };

  const selectedBacktestData = backtests.find((b: any) => b.id === selectedBacktest);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white">Ranking de Robôs</h1>
        <p className="text-slate-400 mt-1">Análise comparativa de performance dos robôs</p>
      </div>

      {/* Backtest Selector */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-sm">Selecionar Backtest</CardTitle>
        </CardHeader>
        <CardContent>
          {backtestsLoading ? (
            <div className="flex items-center gap-2">
              <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
              <span className="text-sm text-slate-400">Carregando backtests...</span>
            </div>
          ) : backtests.length === 0 ? (
            <p className="text-sm text-slate-400">Nenhum backtest disponível. Envie um arquivo primeiro.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
              {backtests.map((backtest: any) => (
                <Button
                  key={backtest.id}
                  variant={selectedBacktest === backtest.id ? "default" : "outline"}
                  className={`text-left h-auto py-2 px-3 ${
                    selectedBacktest === backtest.id
                      ? "bg-cyan-600 border-cyan-600"
                      : "border-slate-600 hover:border-slate-500"
                  }`}
                  onClick={() => setSelectedBacktest(backtest.id)}
                >
                  <div className="text-xs font-medium truncate">{backtest.fileName}</div>
                  <div className="text-xs text-slate-400">
                    {backtest.summary?.robotCount || 0} robôs
                  </div>
                </Button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Period Selector */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-sm">Filtrar por Período</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
            {[
              { value: "all", label: "Todos" },
              { value: "today", label: "Hoje" },
              { value: "week", label: "Semana" },
              { value: "month", label: "Mês" },
              { value: "quarter", label: "Trimestre" },
              { value: "year", label: "Ano" },
            ].map((period) => (
              <Button
                key={period.value}
                variant={selectedPeriod === period.value ? "default" : "outline"}
                className={`text-sm ${
                  selectedPeriod === period.value
                    ? "bg-cyan-600 border-cyan-600"
                    : "border-slate-600 hover:border-slate-500"
                }`}
                onClick={() => setSelectedPeriod(period.value)}
              >
                {period.label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {selectedBacktest && selectedBacktestData && (
        <>
          {/* Performance Summary */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-400">Total de Robôs</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-white">{robots.length}</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-400">P&L Total</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-green-400">
                  {formatCurrency(
                    robots.reduce((sum: number, r: any) => sum + (parseFloat(r.totalPnl) || 0), 0)
                  )}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-400">Win Rate Médio</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-cyan-400">
                  {formatPercent(
                    robots.length > 0
                      ? robots.reduce((sum: number, r: any) => sum + (parseFloat(r.winRate) || 0), 0) /
                          robots.length
                      : 0
                  )}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-400">Total de Trades</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-white">
                  {robots.reduce((sum: number, r: any) => sum + (r.totalTrades || 0), 0)}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Ranking Table */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle>Ranking de Robôs</CardTitle>
              <CardDescription>Clique nas colunas para ordenar</CardDescription>
            </CardHeader>
            <CardContent>
              {performanceLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-6 h-6 text-cyan-400 animate-spin" />
                  <span className="ml-2 text-slate-400">Carregando dados...</span>
                </div>
              ) : robots.length === 0 ? (
                <div className="text-center py-8">
                  <AlertCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                  <p className="text-slate-400">Nenhum robô encontrado neste backtest</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-slate-700">
                        <th className="text-left py-3 px-4 font-semibold text-slate-300">
                          <Trophy className="w-4 h-4 inline mr-2 text-yellow-400" />
                          Robô
                        </th>
                        <th
                          className="text-right py-3 px-4 font-semibold text-slate-300 cursor-pointer hover:text-cyan-400"
                          onClick={() => handleSort("totalPnl")}
                        >
                          P&L {sortBy === "totalPnl" && (sortOrder === "desc" ? "↓" : "↑")}
                        </th>
                        <th
                          className="text-right py-3 px-4 font-semibold text-slate-300 cursor-pointer hover:text-cyan-400"
                          onClick={() => handleSort("winRate")}
                        >
                          Win Rate {sortBy === "winRate" && (sortOrder === "desc" ? "↓" : "↑")}
                        </th>
                        <th
                          className="text-right py-3 px-4 font-semibold text-slate-300 cursor-pointer hover:text-cyan-400"
                          onClick={() => handleSort("profitFactor")}
                        >
                          Profit Factor {sortBy === "profitFactor" && (sortOrder === "desc" ? "↓" : "↑")}
                        </th>
                        <th
                          className="text-right py-3 px-4 font-semibold text-slate-300 cursor-pointer hover:text-cyan-400"
                          onClick={() => handleSort("totalTrades")}
                        >
                          Trades {sortBy === "totalTrades" && (sortOrder === "desc" ? "↓" : "↑")}
                        </th>
                        <th
                          className="text-right py-3 px-4 font-semibold text-slate-300 cursor-pointer hover:text-cyan-400"
                          onClick={() => handleSort("maxDrawdown")}
                        >
                          Max DD {sortBy === "maxDrawdown" && (sortOrder === "desc" ? "↓" : "↑")}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedRobots.map((robot: any, index: number) => (
                        <tr key={robot.id} className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2">
                              {index === 0 && <Trophy className="w-4 h-4 text-yellow-400" />}
                              {index === 1 && <Trophy className="w-4 h-4 text-gray-400" />}
                              {index === 2 && <Trophy className="w-4 h-4 text-orange-400" />}
                              <span className="font-medium text-white">{robot.robot}</span>
                            </div>
                          </td>
                          <td className="text-right py-3 px-4">
                            <div className="flex items-center justify-end gap-1">
                              {parseFloat(robot.totalPnl) >= 0 ? (
                                <TrendingUp className="w-4 h-4 text-green-400" />
                              ) : (
                                <TrendingDown className="w-4 h-4 text-red-400" />
                              )}
                              <span
                                className={
                                  parseFloat(robot.totalPnl) >= 0 ? "text-green-400" : "text-red-400"
                                }
                              >
                                {formatCurrency(robot.totalPnl)}
                              </span>
                            </div>
                          </td>
                          <td className="text-right py-3 px-4 text-cyan-400">
                            {formatPercent(robot.winRate)}
                          </td>
                          <td className="text-right py-3 px-4 text-white">
                            {parseFloat(robot.profitFactor).toFixed(2)}
                          </td>
                          <td className="text-right py-3 px-4 text-white">
                            {robot.totalTrades}
                          </td>
                          <td className="text-right py-3 px-4 text-orange-400">
                            {formatCurrency(robot.maxDrawdown)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Performance Charts */}
          {robots.length > 0 && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* P&L Comparison */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-sm">P&L por Robô</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={sortedRobots.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="robot" stroke="#94a3b8" />
                      <YAxis stroke="#94a3b8" />
                      <Tooltip
                        contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }}
                        formatter={(value: any) => formatCurrency(value)}
                      />
                      <Bar dataKey="totalPnl" fill="#06b6d4" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Win Rate Comparison */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-sm">Win Rate por Robô</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={sortedRobots.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="robot" stroke="#94a3b8" />
                      <YAxis stroke="#94a3b8" />
                      <Tooltip
                        contentStyle={{ backgroundColor: "#1e293b", border: "1px solid #475569" }}
                        formatter={(value: any) => formatPercent(value)}
                      />
                      <Line type="monotone" dataKey="winRate" stroke="#06b6d4" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          )}
        </>
      )}
    </div>
  );
}
