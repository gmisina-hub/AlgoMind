/**
 * Volume Profile Card (Versão Compacta)
 * Exibe apenas POC (Point of Control)
 */

import { Card } from "@/components/ui/card";

interface VolumeProfileCardProps {
  poc: number;
  distanceToPOC: number;
  currentPrice: number;
  hvn: number[];
  lvn: number[];
  isLoading?: boolean;
}

export function VolumeProfileCard({
  poc,
  distanceToPOC,
  currentPrice,
  isLoading = false,
}: VolumeProfileCardProps) {
  const formatNumber = (num: number): string => {
    if (typeof num !== 'number' || !isFinite(num)) {
      return '0';
    }
    return num.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  if (isLoading) {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm p-4">
        {/* Loading vazio */}
      </Card>
    );
  }

  const isPriceAbovePOC = currentPrice > poc;
  const distancePercent = ((Math.abs(distanceToPOC) / poc) * 100).toFixed(2);

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm p-4">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4">
        <span className="text-xl">📊</span>
        <h3 className="text-sm font-bold text-white">Volume Profile</h3>
      </div>

      {/* POC Principal */}
      <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50 mb-3">
        <div className="text-xs text-slate-400 mb-1">POC (Point of Control)</div>
        <div className="text-2xl font-bold text-purple-400">
          {formatNumber(poc)}
        </div>
      </div>

      {/* Distância do Preço Atual */}
      <div className="bg-slate-800/30 rounded p-2 border border-slate-700/30">
        <div className="text-xs text-slate-400 mb-1">Distância do Preço Atual</div>
        <div className="flex items-center justify-between">
          <div className={`text-sm font-bold ${isPriceAbovePOC ? 'text-green-400' : 'text-red-400'}`}>
            {isPriceAbovePOC ? '↑' : '↓'} {formatNumber(Math.abs(distanceToPOC))} pts
          </div>
          <div className={`text-xs ${isPriceAbovePOC ? 'text-green-400' : 'text-red-400'}`}>
            {distancePercent}%
          </div>
        </div>
      </div>
    </Card>
  );
}
