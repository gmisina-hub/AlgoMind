/**
 * Volume Profile - Histograma horizontal de distribuição de volume por preço
 * 
 * Identifica zonas de maior liquidez:
 * - POC (Point of Control): Nível de preço com maior volume negociado
 * - VAH (Value Area High): Limite superior da área de valor (70% do volume)
 * - VAL (Value Area Low): Limite inferior da área de valor (70% do volume)
 */

import React from "react";

interface VolumeProfileData {
  price: number;
  volume: number;
}

interface VolumeProfileProps {
  data: VolumeProfileData[];
}

export function VolumeProfile({ data }: VolumeProfileProps) {
  if (!data || data.length === 0) {
    return (
      <div className="p-4 bg-[#1a2332] rounded-lg border border-slate-700">
        <h3 className="text-lg font-bold text-[#00E5FF] mb-2">VOLUME PROFILE</h3>
        <p className="text-sm text-[#7F8DA3]">Aguardando dados...</p>
      </div>
    );
  }

  // Calculate total volume
  const totalVolume = data.reduce((sum, item) => sum + item.volume, 0);

  // Find POC (Point of Control - price with highest volume)
  const poc = data.reduce((max, item) => (item.volume > max.volume ? item : max), data[0]);

  // Calculate Value Area (70% of volume)
  const sortedByVolume = [...data].sort((a, b) => b.volume - a.volume);
  let accumulatedVolume = 0;
  const valueAreaThreshold = totalVolume * 0.7;
  const valueAreaPrices: number[] = [];

  for (const item of sortedByVolume) {
    if (accumulatedVolume >= valueAreaThreshold) break;
    accumulatedVolume += item.volume;
    valueAreaPrices.push(item.price);
  }

  const vah = Math.max(...valueAreaPrices); // Value Area High
  const val = Math.min(...valueAreaPrices); // Value Area Low

  // Find max volume for scaling bars
  const maxVolume = Math.max(...data.map((d) => d.volume));

  // Sort data by price (descending) for display
  const sortedData = [...data].sort((a, b) => b.price - a.price);

  return (
    <div className="p-4 bg-[#1a2332] rounded-lg border border-slate-700">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-bold text-[#00E5FF]">📊 VOLUME PROFILE</h3>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-[#FFCA28] rounded"></div>
            <span className="text-[#7F8DA3]">POC</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-[#00E5FF] rounded"></div>
            <span className="text-[#7F8DA3]">Value Area</span>
          </div>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        <div className="bg-[#0F1522] border border-[#FFCA28] rounded p-2">
          <div className="text-xs text-[#7F8DA3]">POC</div>
          <div className="text-lg font-bold text-[#FFCA28] font-mono">{(typeof poc.price === 'number' && isFinite(poc.price)) ? poc.price.toFixed(0) : "0"}</div>
          <div className="text-xs text-[#7F8DA3]">{poc.volume.toLocaleString()} vol</div>
        </div>
        <div className="bg-[#0F1522] border border-[#00E5FF] rounded p-2">
          <div className="text-xs text-[#7F8DA3]">VAH</div>
          <div className="text-lg font-bold text-[#00E5FF] font-mono">{(typeof vah === 'number' && isFinite(vah)) ? vah.toFixed(0) : "0"}</div>
        </div>
        <div className="bg-[#0F1522] border border-[#00E5FF] rounded p-2">
          <div className="text-xs text-[#7F8DA3]">VAL</div>
          <div className="text-lg font-bold text-[#00E5FF] font-mono">{(typeof val === 'number' && isFinite(val)) ? val.toFixed(0) : "0"}</div>
        </div>
      </div>

      {/* Horizontal Histogram */}
      <div className="overflow-y-auto max-h-[400px] space-y-1">
        {sortedData.map((item, index) => {
          const barWidth = (item.volume / maxVolume) * 100;
          const isPOC = item.price === poc.price;
          const isInValueArea = item.price >= val && item.price <= vah;

          return (
            <div key={index} className="flex items-center gap-2">
              {/* Price Label */}
              <div
                className={`w-20 text-right font-mono text-sm font-bold ${
                  isPOC
                    ? "text-[#FFCA28]"
                    : isInValueArea
                    ? "text-[#00E5FF]"
                    : "text-[#7F8DA3]"
                }`}
              >
                {(typeof item.price === 'number' && isFinite(item.price)) ? item.price.toFixed(0) : "0"}
              </div>

              {/* Horizontal Bar */}
              <div className="flex-1 relative h-6">
                <div
                  className={`h-full rounded transition-all ${
                    isPOC
                      ? "bg-[#FFCA28]"
                      : isInValueArea
                      ? "bg-[#00E5FF]/60"
                      : "bg-[#A966FF]/40"
                  }`}
                  style={{ width: `${barWidth}%` }}
                ></div>
                {/* Volume Label */}
                <div className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-mono text-white/80">
                  {item.volume.toLocaleString()}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="mt-4 text-xs text-[#7F8DA3]">
        <p>
          <span className="text-[#FFCA28] font-bold">POC:</span> Nível com maior volume (
          {(() => { const pct = (poc.volume / totalVolume) * 100; return (typeof pct === 'number' && isFinite(pct)) ? pct.toFixed(1) : "0.0"; })()}% do total)
        </p>
        <p>
          <span className="text-[#00E5FF] font-bold">Value Area:</span> 70% do volume entre{" "}
          {(typeof val === 'number' && isFinite(val)) ? val.toFixed(0) : "0"} e {(typeof vah === 'number' && isFinite(vah)) ? vah.toFixed(0) : "0"}
        </p>
      </div>
    </div>
  );
}
