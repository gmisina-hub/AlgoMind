interface PivotCardProps {
  label: string;
  value: number;
  currentPrice: number;
  color: string;
}

export function PivotCard({ label, value, currentPrice, color }: PivotCardProps) {
  // Calculate distance from current price
  const distance = value - currentPrice;
  const distanceStr = (distance > 0 ? "+" : "") + formatNumber(distance) + " pts";
  const isNear = Math.abs(distance) < 100; // Within 100 points
  const isAbove = distance > 0;

  // Determine card border and background color
  const getBorderColor = () => {
    if (isNear) return "border-[#FFCA28] bg-[#FFCA28]/20"; // Yellow when near
    if (isAbove) return "border-[#00E5FF] bg-[#00E5FF]/10"; // Blue when above
    return "border-[#FF3B5C] bg-[#FF3B5C]/10"; // Red when below
  };

  return (
    <div
      className={`border-2 rounded-lg p-4 transition-all ${getBorderColor()} ${
        isNear ? "animate-pulse shadow-lg" : ""
      }`}
    >
      <div className="text-[#7F8DA3] text-xs mb-1 font-bold">{label}</div>
      <div className="text-3xl font-bold font-mono mb-2" style={{ color }}>
        {formatNumber(value)}
      </div>
      <div className="flex items-center justify-between text-xs">
        <span className={isAbove ? "text-[#00E5FF]" : "text-[#FF3B5C]"}>
          {isAbove ? "↑" : "↓"}
        </span>
        <span className="font-mono text-[#E8ECF2]">{distanceStr}</span>
      </div>
    </div>
  );
}

// Helper: format number with thousand separator (ponto)
function formatNumber(num: number | undefined): string {
  if (num === undefined || num === null || isNaN(num)) return "0";
  return num.toFixed(0).replace(/(\d)(?=(\d{3})+$)/g, '$1.');
}
