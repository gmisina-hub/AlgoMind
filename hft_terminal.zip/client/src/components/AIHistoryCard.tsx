/**
 * AIHistoryCard.tsx
 * Exibe histórico de recomendações da AI com KPIs de backtest
 */

import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";

export function AIHistoryCard() {
  // Buscar KPIs do histórico
  const { data: kpis, isLoading: loadingKPIs } = trpc.dashboard.getAIKPIs.useQuery(undefined, {
    refetchInterval: 60000, // Atualiza a cada 1 minuto
  });

  // Buscar últimas 10 recomendações
  const { data: history, isLoading: loadingHistory } = trpc.dashboard.getAIHistory.useQuery(
    { limit: 10 },
    {
      refetchInterval: 60000, // Atualiza a cada 1 minuto
    }
  );

  // Se não há dados, retornar card vazio
  if (loadingKPIs || loadingHistory || !kpis || kpis.totalRecommendations === 0) {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm p-6">
        {/* Card vazio */}
      </Card>
    );
  }

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
            <span className="text-2xl">📊</span>
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Histórico AI</h3>
            <p className="text-xs text-slate-400">
              {kpis?.totalRecommendations || 0} recomendações
            </p>
          </div>
        </div>
      </div>

      {/* KPIs de Backtest */}
      <>
          <div className="grid grid-cols-2 gap-3 mb-6">
            {/* Win Rate */}
            <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
              <div className="text-xs text-slate-400 mb-1">Win Rate</div>
              <div className={`text-2xl font-bold ${kpis.winRate >= 50 ? 'text-green-400' : 'text-red-400'}`}>
                {kpis.winRate.toFixed(1)}%
              </div>
            </div>

            {/* Profit Factor */}
            <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
              <div className="text-xs text-slate-400 mb-1">Profit Factor</div>
              <div className={`text-2xl font-bold ${kpis.profitFactor >= 1.5 ? 'text-green-400' : kpis.profitFactor >= 1 ? 'text-yellow-400' : 'text-red-400'}`}>
                {kpis.profitFactor.toFixed(2)}
              </div>
            </div>

            {/* Sharpe Ratio */}
            <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
              <div className="text-xs text-slate-400 mb-1">Sharpe Ratio</div>
              <div className={`text-2xl font-bold ${kpis.sharpeRatio >= 1 ? 'text-green-400' : kpis.sharpeRatio >= 0 ? 'text-yellow-400' : 'text-red-400'}`}>
                {kpis.sharpeRatio.toFixed(2)}
              </div>
            </div>

            {/* Max Drawdown */}
            <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
              <div className="text-xs text-slate-400 mb-1">Max Drawdown</div>
              <div className="text-2xl font-bold text-red-400">
                {kpis.maxDrawdown.toFixed(1)}%
              </div>
            </div>
          </div>

          {/* Total P&L */}
          <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700/50 mb-6">
            <div className="text-xs text-slate-400 mb-1">Total P&L (Simulado)</div>
            <div className={`text-3xl font-bold ${kpis.totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {kpis.totalPnL >= 0 ? '+' : ''}{kpis.totalPnL.toLocaleString('pt-BR')} pts
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Capital inicial: 10.000 pts
            </div>
          </div>

          {/* Distribuição de Recomendações */}
          <div className="grid grid-cols-3 gap-2 mb-6">
            <div className="bg-green-500/10 rounded-lg p-3 border border-green-500/30">
              <div className="text-xs text-green-400 mb-1">LONG</div>
              <div className="text-xl font-bold text-green-400">{kpis.longCount}</div>
            </div>
            <div className="bg-red-500/10 rounded-lg p-3 border border-red-500/30">
              <div className="text-xs text-red-400 mb-1">SHORT</div>
              <div className="text-xl font-bold text-red-400">{kpis.shortCount}</div>
            </div>
            <div className="bg-slate-500/10 rounded-lg p-3 border border-slate-500/30">
              <div className="text-xs text-slate-400 mb-1">NEUTRO</div>
              <div className="text-xl font-bold text-slate-400">{kpis.neutralCount}</div>
            </div>
          </div>

          {/* Últimas Recomendações */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
              Últimas 10 Recomendações
            </div>
            {history && history.length > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {history.map((rec, idx) => (
                  <div
                    key={idx}
                    className="bg-slate-800/30 rounded-lg p-3 border border-slate-700/30 hover:border-slate-600/50 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2 py-1 rounded text-xs font-bold ${
                            rec.recommendation === 'LONG'
                              ? 'bg-green-500/20 text-green-400'
                              : rec.recommendation === 'SHORT'
                              ? 'bg-red-500/20 text-red-400'
                              : 'bg-slate-500/20 text-slate-400'
                          }`}
                        >
                          {rec.recommendation}
                        </span>
                        <span className="text-xs text-slate-400">
                          {rec.confidence}%
                        </span>
                      </div>
                      <div className="text-xs text-slate-500">
                        {new Date(rec.timestamp).toLocaleString('pt-BR', {
                          day: '2-digit',
                          month: '2-digit',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </div>
                    <div className="text-xs text-slate-400 line-clamp-2">
                      {rec.context}
                    </div>
                    <div className="flex items-center gap-3 mt-2 text-xs">
                      <span className="text-slate-500">
                        Entry: <span className="text-cyan-400">{parseFloat(rec.entry).toFixed(0)}</span>
                      </span>
                      <span className="text-slate-500">
                        SL: <span className="text-red-400">{parseFloat(rec.stopLoss).toFixed(0)}</span>
                      </span>
                      <span className="text-slate-500">
                        TP: <span className="text-green-400">{parseFloat(rec.takeProfit).toFixed(0)}</span>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-slate-500 py-4">
                Nenhuma recomendação no histórico
              </div>
            )}
          </div>
      </>
    </Card>
  );
}
