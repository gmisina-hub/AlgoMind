/**
 * Dark Pool Detector Card
 * 
 * Exibe detecção de atividade institucional (dark pool) via volume spikes
 */

import { Card } from "@/components/ui/card";
import { Eye, TrendingUp, TrendingDown } from "lucide-react";

interface DarkPoolCardProps {
  detected: boolean;
  direction: "BUY" | "SELL" | "NEUTRAL";
  confidence: number;
  volumeSpike: number;
  avgVolume: number;
  isLoading?: boolean;
}

export function DarkPoolCard({
  detected,
  direction,
  confidence,
  volumeSpike,
  avgVolume,
  isLoading = false,
}: DarkPoolCardProps) {
  // Formatar número com ponto como separador de milhares
  const formatNumber = (num: number): string => {
    return num.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  if (isLoading) {
    return (
      <Card className="p-6 bg-slate-800/50 border-slate-700">
        <div className="flex items-center gap-3 mb-4">
          <Eye className="w-6 h-6 text-orange-400 animate-pulse" />
          <h3 className="text-lg font-semibold text-white">Dark Pool Detector</h3>
        </div>
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-400 mx-auto"></div>
          <p className="text-gray-400 mt-4">Monitorando volume...</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 bg-slate-800/50 border-slate-700">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <Eye className="w-6 h-6 text-orange-400" />
        <h3 className="text-lg font-semibold text-white">Dark Pool Detector</h3>
      </div>

      {/* Status de Detecção */}
      <div className={`p-4 rounded-lg border mb-4 ${
        detected
          ? direction === "BUY"
            ? "bg-green-500/10 border-green-500/30 animate-pulse"
            : "bg-red-500/10 border-red-500/30 animate-pulse"
          : "bg-gray-500/10 border-gray-500/30"
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {detected ? (
              direction === "BUY" ? (
                <TrendingUp className="w-6 h-6 text-green-400" />
              ) : (
                <TrendingDown className="w-6 h-6 text-red-400" />
              )
            ) : (
              <Eye className="w-6 h-6 text-gray-400" />
            )}
            <div>
              <p className="text-sm text-gray-400">Status</p>
              <p className={`text-xl font-bold ${
                detected
                  ? direction === "BUY"
                    ? "text-green-400"
                    : "text-red-400"
                  : "text-gray-400"
              }`}>
                {detected ? `Institutional ${direction}` : "Não Detectado"}
              </p>
            </div>
          </div>
          
          {detected && (
            <div className="text-right">
              <p className="text-sm text-gray-400">Confiança</p>
              <p className="text-2xl font-bold text-white">{confidence}%</p>
            </div>
          )}
        </div>
      </div>

      {/* Volume Spike */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-slate-700/50 p-3 rounded-lg">
          <p className="text-xs text-gray-400 mb-1">Volume Spike</p>
          <p className={`text-lg font-semibold ${
            volumeSpike >= 2.0 ? "text-orange-400" : "text-gray-300"
          }`}>
            {(typeof volumeSpike === 'number' && isFinite(volumeSpike)) ? volumeSpike.toFixed(1) : "0.0"}x
          </p>
        </div>
        <div className="bg-slate-700/50 p-3 rounded-lg">
          <p className="text-xs text-gray-400 mb-1">Média Volume</p>
          <p className="text-lg font-semibold text-white">{formatNumber(avgVolume)}</p>
        </div>
      </div>

      {/* Explicação */}
      <div className="mt-4 bg-slate-700/30 p-3 rounded-lg border border-slate-600">
        <p className="text-xs text-gray-400">
          {detected
            ? `🔍 Atividade institucional detectada! Volume ${(typeof volumeSpike === 'number' && isFinite(volumeSpike)) ? volumeSpike.toFixed(1) : "0.0"}x acima da média sugere entrada de "tubarões" (${direction === "BUY" ? "comprando" : "vendendo"}).`
            : "👀 Monitorando volume para detectar atividade institucional (dark pool)."}
        </p>
      </div>
    </Card>
  );
}
