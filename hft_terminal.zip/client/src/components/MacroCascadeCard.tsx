/**
 * Macro Cascade Card (Versão Compacta)
 * Exibe sinal macro geral + 3 indicadores principais
 */

import { Card } from "@/components/ui/card";

interface MacroCascadeCardProps {
  vix: {
    value: number;
    change: number;
  };
  dxy: {
    value: number;
    change: number;
  };
  sp500: {
    value: number;
    change: number;
  };
  overallSignal: "BULLISH" | "BEARISH" | "NEUTRAL";
  confidence: number;
  isLoading?: boolean;
}

export function MacroCascadeCard({
  vix,
  dxy,
  sp500,
  overallSignal,
  confidence,
  isLoading = false,
}: MacroCascadeCardProps) {
  if (isLoading) {
    return (
      <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm p-4">
        {/* Loading vazio */}
      </Card>
    );
  }

  const getSignalColor = () => {
    if (overallSignal === "BULLISH") return "text-green-400";
    if (overallSignal === "BEARISH") return "text-red-400";
    return "text-gray-400";
  };

  return (
    <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm p-4">
      {/* Header com Sinal */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <span className="text-xl">🌍</span>
          <h3 className="text-sm font-bold text-white">Macro Cascade</h3>
        </div>
        <div className="text-right">
          <div className="text-xs text-slate-400">Sinal Macro → WINFUT</div>
          <div className={`text-lg font-bold ${getSignalColor()}`}>
            {overallSignal}
          </div>
        </div>
      </div>

      {/* Confiança */}
      <div className="mb-4 bg-slate-800/50 rounded-lg p-2 border border-slate-700/50">
        <div className="text-xs text-slate-400 mb-1">Confiança</div>
        <div className={`text-xl font-bold ${getSignalColor()}`}>
          {confidence}%
        </div>
      </div>

      {/* 3 Indicadores Compactos */}
      <div className="space-y-2">
        {/* VIX */}
        <div className="bg-slate-800/30 rounded p-2 border border-slate-700/30">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-400">📊 VIX - Índice de Medo</div>
            <div className="text-right">
              <div className="text-sm font-bold text-white">{vix.value.toFixed(2)}</div>
              <div className={`text-xs ${vix.change >= 0 ? 'text-red-400' : 'text-green-400'}`}>
                {vix.change >= 0 ? '+' : ''}{vix.change.toFixed(2)}%
              </div>
            </div>
          </div>
        </div>

        {/* DXY */}
        <div className="bg-slate-800/30 rounded p-2 border border-slate-700/30">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-400">🇺🇸 DXY - Dólar Americano</div>
            <div className="text-right">
              <div className="text-sm font-bold text-white">{dxy.value.toFixed(2)}</div>
              <div className={`text-xs ${dxy.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {dxy.change >= 0 ? '+' : ''}{dxy.change.toFixed(2)}%
              </div>
            </div>
          </div>
        </div>

        {/* S&P500 */}
        <div className="bg-slate-800/30 rounded p-2 border border-slate-700/30">
          <div className="flex items-center justify-between">
            <div className="text-xs text-slate-400">📈 S&P500 - Bolsa EUA</div>
            <div className="text-right">
              <div className="text-sm font-bold text-white">{sp500.value.toFixed(2)}</div>
              <div className={`text-xs ${sp500.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {sp500.change >= 0 ? '+' : ''}{sp500.change.toFixed(2)}%
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
