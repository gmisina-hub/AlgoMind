import { useState, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface UploadStatus {
  state: "idle" | "uploading" | "processing" | "success" | "error";
  progress: number;
  message: string;
}

export function BacktestUpload() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadStatus, setUploadStatus] = useState<UploadStatus>({
    state: "idle",
    progress: 0,
    message: "",
  });

  const uploadBacktestMutation = trpc.backtest.uploadFileSimple.useMutation({
    onSuccess: (data: any) => {
      setUploadStatus({
        state: "success",
        progress: 100,
        message: `Backtest "${data.fileName}" enviado com sucesso!`,
      });
      toast.success("Backtest enviado com sucesso!");
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      // Reset after 3 seconds
      setTimeout(() => {
        setUploadStatus({
          state: "idle",
          progress: 0,
          message: "",
        });
      }, 3000);
    },
    onError: (error: any) => {
      console.error('[BacktestUpload] Error:', error);
      console.error('[BacktestUpload] Error message:', error.message);
      console.error('[BacktestUpload] Error data:', error.data);
      setUploadStatus({
        state: "error",
        progress: 0,
        message: error.message || error.data?.zodError?.fieldErrors || "Erro ao enviar backtest",
      });
      toast.error(error.message || "Erro ao enviar backtest");
    },
  });

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validar extensão
    if (!file.name.endsWith(".xlsx") && !file.name.endsWith(".xls")) {
      toast.error("Por favor, selecione um arquivo Excel (.xlsx ou .xls)");
      return;
    }

    // Validar tamanho (máx 50MB)
    if (file.size > 50 * 1024 * 1024) {
      toast.error("Arquivo muito grande (máximo 50MB)");
      return;
    }

    setUploadStatus({
      state: "uploading",
      progress: 30,
      message: "Lendo arquivo...",
    });

    try {
      // Ler arquivo como base64
      const reader = new FileReader();
      reader.onload = async (event) => {
        const fileData = event.target?.result as string;

        setUploadStatus({
          state: "processing",
          progress: 60,
          message: "Processando dados...",
        });

        // Enviar para servidor
        uploadBacktestMutation.mutate({
          fileName: file.name,
          fileContent: fileData,
        });
      };

      reader.readAsDataURL(file);
    } catch (error) {
      setUploadStatus({
        state: "error",
        progress: 0,
        message: error instanceof Error ? error.message : "Erro ao processar arquivo",
      });
      toast.error("Erro ao processar arquivo");
    }
  };

  const isLoading = uploadStatus.state === "uploading" || uploadStatus.state === "processing";

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader>
        <CardTitle>Upload de Backtest</CardTitle>
        <CardDescription>Envie seu arquivo Excel com dados de trades</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Upload Area */}
          <div
            className="border-2 border-dashed border-slate-600 rounded-lg p-8 text-center cursor-pointer hover:border-slate-500 transition-colors"
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileSelect}
              disabled={isLoading}
              className="hidden"
            />

            <div className="flex flex-col items-center gap-3">
              {isLoading ? (
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
              ) : (
                <FileSpreadsheet className="w-8 h-8 text-slate-400" />
              )}

              <div>
                <p className="text-sm font-medium text-white">
                  {isLoading ? "Processando..." : "Clique para selecionar ou arraste um arquivo"}
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Formatos suportados: .xlsx, .xls (máximo 50MB)
                </p>
              </div>
            </div>
          </div>

          {/* Status Message */}
          {uploadStatus.state !== "idle" && (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                {uploadStatus.state === "success" && (
                  <CheckCircle className="w-5 h-5 text-green-400" />
                )}
                {uploadStatus.state === "error" && (
                  <AlertCircle className="w-5 h-5 text-red-400" />
                )}
                {(uploadStatus.state === "uploading" || uploadStatus.state === "processing") && (
                  <Loader2 className="w-5 h-5 text-cyan-400 animate-spin" />
                )}
                <span className="text-sm text-slate-300">{uploadStatus.message}</span>
              </div>

              {/* Progress Bar */}
              {uploadStatus.progress > 0 && uploadStatus.state !== "success" && (
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-blue-400 h-2 rounded-full transition-all"
                    style={{ width: `${uploadStatus.progress}%` }}
                  ></div>
                </div>
              )}
            </div>
          )}

          {/* Info */}
          <div className="bg-slate-700/50 rounded-lg p-3 text-xs text-slate-300 space-y-1">
            <p className="font-semibold text-slate-200">Formato esperado:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Primeira linha com cabeçalhos (Asset, Data, Hora, Último, etc)</li>
              <li>Colunas de dados: Abertura, Máximo, Mínimo, Fechamento, Volume, etc</li>
              <li>Uma linha por ativo/período</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
