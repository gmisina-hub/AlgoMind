/**
 * Technical Levels Card - Unified (REESCRITO COM VALIDAÇÕES ULTRA-SEGURAS)
 * 
 * Exibe Pivot Points, Fibonacci e Métricas num design compacto e moderno
 */

import { TrendingUp, TrendingDown, Activity } from "lucide-react";

interface TechnicalLevelsCardProps {
  currentPrice: number;
  pivotPoints: {
    r2: number;
    r1: number;
    pp: number;
    s1: number;
    s2: number;
  };
  fibonacci: {
    high: number;
    fib618: number;
    fib50: number;
    fib382: number;
    fib236: number;
    low: number;
  };
  metrics: {
    rsi: number;
    trueRange: number;
    accumBalance: number;
  };
}

// Helper: Converte qualquer valor para número seguro (retorna 0 se inválido)
function toSafeNumber(value: any): number {
  if (value === undefined || value === null) return 0;
  const num = Number(value);
  if (isNaN(num) || !isFinite(num)) return 0;
  return num;
}

// Helper: Formata número com separador de milhar (SEMPRE retorna string)
function formatNumber(value: any): string {
  const num = toSafeNumber(value);
  const intPart = Math.floor(Math.abs(num));
  const formatted = intPart.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return num < 0 ? `-${formatted}` : formatted;
}

// Helper: Calcula distância entre dois valores (SEMPRE retorna string)
function getDistance(level: any, currentPrice: any): string {
  const l = toSafeNumber(level);
  const c = toSafeNumber(currentPrice);
  const dist = l - c;
  const sign = dist > 0 ? "+" : "";
  return `${sign}${formatNumber(dist)} pts`;
}

// Helper: Retorna cor baseada na distância
function getDistanceColor(level: any, currentPrice: any): string {
  const l = toSafeNumber(level);
  const c = toSafeNumber(currentPrice);
  const dist = Math.abs(l - c);
  if (dist < 100) return "text-red-400"; // Muito próximo
  if (dist < 300) return "text-yellow-400"; // Próximo
  return "text-gray-500"; // Longe
}

// Helper: Formata RSI com 1 casa decimal (SEMPRE retorna string)
function formatRSI(value: any): string {
  const num = toSafeNumber(value);
  const rounded = Math.round(num * 10) / 10;
  return rounded.toFixed(1);
}

// Helper: Retorna status do RSI
function getRSIStatus(value: any): string {
  const num = toSafeNumber(value);
  if (num > 70) return "Sobrecomprado";
  if (num < 30) return "Sobrevendido";
  return "Neutro";
}

// Helper: Retorna status da Agressão
function getAccumBalanceStatus(value: any): string {
  const num = toSafeNumber(value);
  return num > 0 ? "Comprador" : "Vendedor";
}

export function TechnicalLevelsCard({
  currentPrice,
  pivotPoints,
  fibonacci,
  metrics,
}: TechnicalLevelsCardProps) {
  // Validação de segurança: garantir que todos os valores existem
  const safeCurrentPrice = toSafeNumber(currentPrice);
  const safePivotPoints = {
    r2: toSafeNumber(pivotPoints?.r2),
    r1: toSafeNumber(pivotPoints?.r1),
    pp: toSafeNumber(pivotPoints?.pp),
    s1: toSafeNumber(pivotPoints?.s1),
    s2: toSafeNumber(pivotPoints?.s2),
  };
  const safeFibonacci = {
    high: toSafeNumber(fibonacci?.high),
    fib618: toSafeNumber(fibonacci?.fib618),
    fib50: toSafeNumber(fibonacci?.fib50),
    fib382: toSafeNumber(fibonacci?.fib382),
    fib236: toSafeNumber(fibonacci?.fib236),
    low: toSafeNumber(fibonacci?.low),
  };
  const safeMetrics = {
    rsi: toSafeNumber(metrics?.rsi),
    trueRange: toSafeNumber(metrics?.trueRange),
    accumBalance: toSafeNumber(metrics?.accumBalance),
  };

  return (
    <div className="bg-[#0F1522] border border-slate-800 rounded-lg p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-[#00E5FF]">📊 Níveis Técnicos</h3>
        <div className="text-sm text-[#7F8DA3]">
          Preço Atual: <span className="text-white font-mono font-bold">{formatNumber(safeCurrentPrice)}</span>
        </div>
      </div>

      {/* Grid 3 colunas */}
      <div className="grid grid-cols-3 gap-6">
        {/* Coluna 1: Pivot Points */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-[#00E5FF]" />
            <h4 className="text-sm font-bold text-[#00E5FF]">PIVOT POINTS</h4>
          </div>
          <div className="space-y-2">
            {[
              { label: "R2", value: safePivotPoints.r2, color: "bg-green-500/20 text-green-400 border-green-500/30" },
              { label: "R1", value: safePivotPoints.r1, color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" },
              { label: "PP", value: safePivotPoints.pp, color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
              { label: "S1", value: safePivotPoints.s1, color: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
              { label: "S2", value: safePivotPoints.s2, color: "bg-red-500/20 text-red-400 border-red-500/30" },
            ].map(({ label, value, color }) => (
              <div key={label} className={`flex items-center justify-between px-3 py-2 rounded border ${color}`}>
                <span className="font-bold text-sm">{label}</span>
                <div className="text-right">
                  <div className="font-mono text-sm font-bold">{formatNumber(value)}</div>
                  <div className={`text-xs ${getDistanceColor(value, safeCurrentPrice)}`}>
                    {getDistance(value, safeCurrentPrice)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Coluna 2: Fibonacci */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-4 h-4 text-[#A966FF]" />
            <h4 className="text-sm font-bold text-[#A966FF]">FIBONACCI</h4>
          </div>
          <div className="space-y-2">
            {[
              { label: "100%", value: safeFibonacci.high, color: "bg-green-500/20 text-green-400 border-green-500/30" },
              { label: "61.8%", value: safeFibonacci.fib618, color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" },
              { label: "50%", value: safeFibonacci.fib50, color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
              { label: "38.2%", value: safeFibonacci.fib382, color: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
              { label: "23.6%", value: safeFibonacci.fib236, color: "bg-red-500/20 text-red-400 border-red-500/30" },
              { label: "0%", value: safeFibonacci.low, color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
            ].map(({ label, value, color }) => (
              <div key={label} className={`flex items-center justify-between px-3 py-2 rounded border ${color}`}>
                <span className="font-bold text-sm">{label}</span>
                <div className="text-right">
                  <div className="font-mono text-sm font-bold">{formatNumber(value)}</div>
                  <div className={`text-xs ${getDistanceColor(value, safeCurrentPrice)}`}>
                    {getDistance(value, safeCurrentPrice)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Coluna 3: Métricas Proprietárias */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <TrendingDown className="w-4 h-4 text-[#FF3B5C]" />
            <h4 className="text-sm font-bold text-[#FF3B5C]">MÉTRICAS</h4>
          </div>
          <div className="space-y-4">
            {/* RSI */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
              <div className="text-xs text-gray-400 mb-1">RSI (14)</div>
              <div className="text-2xl font-bold text-yellow-400">{formatRSI(safeMetrics.rsi)}</div>
              <div className="text-xs text-gray-500 mt-1">{getRSIStatus(safeMetrics.rsi)}</div>
            </div>

            {/* True Range */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
              <div className="text-xs text-gray-400 mb-1">True Range</div>
              <div className="text-2xl font-bold text-pink-400">{formatNumber(safeMetrics.trueRange)} pts</div>
              <div className="text-xs text-gray-500 mt-1">Volatilidade Intraday</div>
            </div>

            {/* Agressão Acumulada */}
            <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-4">
              <div className="text-xs text-gray-400 mb-1">Agressão Acumulada</div>
              <div className={`text-2xl font-bold ${safeMetrics.accumBalance > 0 ? "text-green-400" : "text-red-400"}`}>
                {safeMetrics.accumBalance > 0 ? "+" : ""}{formatNumber(safeMetrics.accumBalance)}
              </div>
              <div className="text-xs text-gray-500 mt-1">{getAccumBalanceStatus(safeMetrics.accumBalance)}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
