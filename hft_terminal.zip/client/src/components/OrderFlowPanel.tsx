/**
 * Order Flow Panel - Heatmap de Volume Comprador vs Vendedor
 * 
 * Visualiza agressão de compra/venda em tempo real:
 * - Verde: Compra agressiva (volume comprador > vendedor)
 * - Vermelho: Venda agressiva (volume vendedor > comprador)
 * - Intensidade da cor proporcional ao desequilíbrio
 */

import React from "react";

interface OrderFlowData {
  price: number;
  aggressionBalance: number; // Saldo de Agressão (positivo = compra, negativo = venda)
  volume: number; // Volume total
  timestamp: Date;
}

interface OrderFlowPanelProps {
  data: OrderFlowData[];
}

export function OrderFlowPanel({ data }: OrderFlowPanelProps) {
  if (!data || data.length === 0) {
    return (
      <div className="p-4 bg-[#1a2332] rounded-lg border border-slate-700">
        <h3 className="text-lg font-bold text-[#00E5FF] mb-2">ORDER FLOW</h3>
        <p className="text-sm text-[#7F8DA3]">Aguardando dados...</p>
      </div>
    );
  }

  // Calculate aggression display for each price level
  const enrichedData = data.map((item) => {
    // Normalize aggression balance to 0-1 scale for intensity
    const maxBalance = Math.max(...data.map((d) => Math.abs(d.aggressionBalance)));
    const normalizedBalance = maxBalance > 0 ? item.aggressionBalance / maxBalance : 0;
    
    // Determine color and intensity
    const isBuyAggressive = item.aggressionBalance > 0;
    const intensity = Math.abs(normalizedBalance); // 0 to 1
    
    return {
      ...item,
      isBuyAggressive,
      intensity,
      normalizedBalance,
    };
  });

  return (
    <div className="p-4 bg-[#1a2332] rounded-lg border border-slate-700">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-bold text-[#00E5FF]">ORDER FLOW</h3>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-[#0AFF7C] rounded"></div>
            <span className="text-[#7F8DA3]">Compra Agressiva</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-[#FF3B5C] rounded"></div>
            <span className="text-[#7F8DA3]">Venda Agressiva</span>
          </div>
        </div>
      </div>

      {/* Heatmap Table */}
      <div className="overflow-y-auto max-h-[400px]">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-[#0A0F1A] border-b border-slate-700">
            <tr>
              <th className="text-left py-2 px-3 text-[#7F8DA3] font-bold">PREÇO</th>
              <th className="text-right py-2 px-3 text-[#A966FF] font-bold">VOLUME</th>
              <th className="text-center py-2 px-3 text-[#7F8DA3] font-bold">SALDO AGRESSÃO</th>
              <th className="text-center py-2 px-3 text-[#7F8DA3] font-bold">VISUAL</th>
            </tr>
          </thead>
          <tbody>
            {enrichedData.map((item, index) => {
              const bgColor = item.isBuyAggressive
                ? `rgba(10, 255, 124, ${item.intensity * 0.3})`
                : `rgba(255, 59, 92, ${item.intensity * 0.3})`;
              
              return (
                <tr
                  key={index}
                  className="border-b border-slate-800 hover:bg-[#1a2332]/50 transition-colors"
                  style={{ backgroundColor: bgColor }}
                >
                  <td className="py-2 px-3 font-mono text-white font-bold">
                    {(typeof item.price === 'number' && isFinite(item.price)) ? item.price.toFixed(0) : "0"}
                  </td>
                  <td className="py-2 px-3 text-right font-mono text-[#A966FF]">
                    {item.volume.toLocaleString()}
                  </td>
                  <td className="py-2 px-3 text-center">
                    <span
                      className={`font-mono font-bold ${
                        item.aggressionBalance > 0 ? "text-[#0AFF7C]" : "text-[#FF3B5C]"
                      }`}
                    >
                      {item.aggressionBalance > 0 ? "+" : ""}
                      {(typeof item.aggressionBalance === 'number' && isFinite(item.aggressionBalance)) ? item.aggressionBalance.toFixed(0) : "0"}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-center">
                    <div className="flex items-center justify-center">
                      {/* Visual bar */}
                      <div className="w-32 h-4 bg-slate-800 rounded-full overflow-hidden relative">
                        <div
                          className={`absolute h-full ${
                            item.isBuyAggressive ? "bg-[#0AFF7C]" : "bg-[#FF3B5C]"
                          }`}
                          style={{
                            width: `${item.intensity * 100}%`,
                            left: item.isBuyAggressive ? "50%" : `${(1 - item.intensity) * 50}%`,
                          }}
                        ></div>
                        {/* Center line */}
                        <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/30"></div>
                      </div>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
