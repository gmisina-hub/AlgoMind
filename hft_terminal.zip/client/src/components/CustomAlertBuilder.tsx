/**
 * Custom Alert Builder - Interface para criar alertas personalizados
 * 
 * Permite usuário criar regras como:
 * - "Avisar quando RSI > 70 E preço cruza R1"
 * - "Avisar quando Volume > 3000 E preço < VWAP"
 * - "Avisar quando True Range > 5% E RSI < 30"
 */

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";

interface AlertRule {
  id: string;
  name: string;
  conditions: AlertCondition[];
  enabled: boolean;
}

interface AlertCondition {
  field: string; // "rsi", "price", "volume", "trueRange", etc.
  operator: string; // ">", "<", ">=", "<=", "==", "crosses"
  value: number | string;
  connector?: "AND" | "OR"; // How to connect to next condition
}

export function CustomAlertBuilder() {
  const [rules, setRules] = useState<AlertRule[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newRule, setNewRule] = useState<AlertRule>({
    id: "",
    name: "",
    conditions: [{ field: "rsi", operator: ">", value: 70 }],
    enabled: true,
  });

  const addCondition = () => {
    setNewRule({
      ...newRule,
      conditions: [
        ...newRule.conditions,
        { field: "rsi", operator: ">", value: 70, connector: "AND" },
      ],
    });
  };

  const removeCondition = (index: number) => {
    setNewRule({
      ...newRule,
      conditions: newRule.conditions.filter((_, i) => i !== index),
    });
  };

  const updateCondition = (index: number, updates: Partial<AlertCondition>) => {
    const updated = [...newRule.conditions];
    updated[index] = { ...updated[index], ...updates };
    setNewRule({ ...newRule, conditions: updated });
  };

  const saveRule = () => {
    const ruleWithId = { ...newRule, id: Date.now().toString() };
    setRules([...rules, ruleWithId]);
    setNewRule({
      id: "",
      name: "",
      conditions: [{ field: "rsi", operator: ">", value: 70 }],
      enabled: true,
    });
    setIsCreating(false);
  };

  const toggleRule = (id: string) => {
    setRules(rules.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r)));
  };

  const deleteRule = (id: string) => {
    setRules(rules.filter((r) => r.id !== id));
  };

  return (
    <div className="p-4 bg-[#1a2332] rounded-lg border border-slate-700">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-[#00E5FF]">⚙️ ALERTAS CUSTOMIZÁVEIS</h3>
        <Button
          onClick={() => setIsCreating(!isCreating)}
          className="bg-[#00E5FF] text-[#0A0F1A] hover:bg-[#00E5FF]/80"
        >
          {isCreating ? "Cancelar" : "+ Novo Alerta"}
        </Button>
      </div>

      {/* Create New Rule */}
      {isCreating && (
        <div className="mb-4 p-4 bg-[#0F1522] border border-[#00E5FF] rounded-lg">
          <h4 className="text-md font-bold text-white mb-3">Criar Novo Alerta</h4>
          
          {/* Rule Name */}
          <div className="mb-3">
            <label className="block text-sm text-[#7F8DA3] mb-1">Nome do Alerta</label>
            <input
              type="text"
              value={newRule.name}
              onChange={(e) => setNewRule({ ...newRule, name: e.target.value })}
              placeholder="Ex: RSI Overbought + R1 Cross"
              className="w-full px-3 py-2 bg-[#1a2332] border border-slate-700 rounded text-white"
            />
          </div>

          {/* Conditions */}
          <div className="mb-3">
            <label className="block text-sm text-[#7F8DA3] mb-2">Condições</label>
            {newRule.conditions.map((condition, index) => (
              <div key={index} className="mb-2">
                {index > 0 && (
                  <select
                    value={condition.connector}
                    onChange={(e) =>
                      updateCondition(index, { connector: e.target.value as "AND" | "OR" })
                    }
                    className="w-20 px-2 py-1 bg-[#1a2332] border border-slate-700 rounded text-white text-sm mb-1"
                  >
                    <option value="AND">E</option>
                    <option value="OR">OU</option>
                  </select>
                )}
                <div className="flex items-center gap-2">
                  <select
                    value={condition.field}
                    onChange={(e) => updateCondition(index, { field: e.target.value })}
                    className="flex-1 px-3 py-2 bg-[#1a2332] border border-slate-700 rounded text-white"
                  >
                    <option value="rsi">RSI</option>
                    <option value="price">Preço</option>
                    <option value="volume">Volume</option>
                    <option value="trueRange">True Range</option>
                    <option value="vwap">VWAP</option>
                    <option value="r1">Resistência R1</option>
                    <option value="r2">Resistência R2</option>
                    <option value="s1">Suporte S1</option>
                    <option value="s2">Suporte S2</option>
                  </select>
                  <select
                    value={condition.operator}
                    onChange={(e) => updateCondition(index, { operator: e.target.value })}
                    className="w-24 px-3 py-2 bg-[#1a2332] border border-slate-700 rounded text-white"
                  >
                    <option value=">">{">"}</option>
                    <option value="<">{"<"}</option>
                    <option value=">=">{">="}</option>
                    <option value="<=">{"<="}</option>
                    <option value="==">{"=="}</option>
                    <option value="crosses">cruza</option>
                  </select>
                  <input
                    type="number"
                    value={condition.value}
                    onChange={(e) => updateCondition(index, { value: parseFloat(e.target.value) })}
                    className="w-32 px-3 py-2 bg-[#1a2332] border border-slate-700 rounded text-white"
                  />
                  {newRule.conditions.length > 1 && (
                    <button
                      onClick={() => removeCondition(index)}
                      className="px-3 py-2 bg-[#FF3B5C] text-white rounded hover:bg-[#FF3B5C]/80"
                    >
                      ✖
                    </button>
                  )}
                </div>
              </div>
            ))}
            <button
              onClick={addCondition}
              className="mt-2 px-3 py-1 bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF] rounded text-sm hover:bg-[#00E5FF]/30"
            >
              + Adicionar Condição
            </button>
          </div>

          {/* Save Button */}
          <Button
            onClick={saveRule}
            disabled={!newRule.name || newRule.conditions.length === 0}
            className="w-full bg-[#0AFF7C] text-[#0A0F1A] hover:bg-[#0AFF7C]/80"
          >
            Salvar Alerta
          </Button>
        </div>
      )}

      {/* Existing Rules */}
      <div className="space-y-2">
        {rules.length === 0 && !isCreating && (
          <p className="text-sm text-[#7F8DA3] text-center py-4">
            Nenhum alerta customizado criado. Clique em "+ Novo Alerta" para começar.
          </p>
        )}
        {rules.map((rule) => (
          <div
            key={rule.id}
            className={`p-3 rounded-lg border ${
              rule.enabled
                ? "bg-[#0F1522] border-[#0AFF7C]"
                : "bg-[#1a2332]/50 border-slate-700"
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-bold text-white">{rule.name}</h4>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => toggleRule(rule.id)}
                  className={`px-3 py-1 rounded text-xs font-bold ${
                    rule.enabled
                      ? "bg-[#0AFF7C] text-[#0A0F1A]"
                      : "bg-slate-700 text-[#7F8DA3]"
                  }`}
                >
                  {rule.enabled ? "ATIVO" : "INATIVO"}
                </button>
                <button
                  onClick={() => deleteRule(rule.id)}
                  className="px-3 py-1 bg-[#FF3B5C] text-white rounded text-xs hover:bg-[#FF3B5C]/80"
                >
                  Excluir
                </button>
              </div>
            </div>
            <div className="text-sm text-[#7F8DA3]">
              {rule.conditions.map((cond, idx) => (
                <span key={idx}>
                  {idx > 0 && <span className="mx-1 text-[#00E5FF]">{cond.connector}</span>}
                  <span className="text-white">
                    {cond.field} {cond.operator} {cond.value}
                  </span>
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
