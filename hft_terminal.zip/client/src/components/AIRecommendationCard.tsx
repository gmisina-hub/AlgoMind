/**
 * AI Recommendation Card
 * 
 * Exibe recomendação de trading gerada por AI com:
 * - Recomendação: LONG/SHORT/NEUTRO
 * - Confiança: 0-100%
 * - Entry, Stop Loss, Take Profit
 * - Contexto explicativo
 * - Timestamp da última análise
 */

import { Card } from "@/components/ui/card";
import { Brain, TrendingUp, TrendingDown, Minus } from "lucide-react";

interface AIRecommendationCardProps {
  recommendation: "LONG" | "SHORT" | "NEUTRO";
  confidence: number;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  context: string;
  timestamp?: number; // Unix timestamp em ms
  isLoading?: boolean;
}

export function AIRecommendationCard({
  recommendation,
  confidence,
  entry,
  stopLoss,
  takeProfit,
  context,
  timestamp,
  isLoading = false,
}: AIRecommendationCardProps) {
  // Cores baseadas na recomendação
  const getRecommendationColor = () => {
    if (recommendation === "LONG") return "text-green-400";
    if (recommendation === "SHORT") return "text-red-400";
    return "text-gray-400";
  };

  const getRecommendationBg = () => {
    if (recommendation === "LONG") return "bg-green-500/10 border-green-500/30";
    if (recommendation === "SHORT") return "bg-red-500/10 border-red-500/30";
    return "bg-gray-500/10 border-gray-500/30";
  };

  const getRecommendationIcon = () => {
    if (recommendation === "LONG") return <TrendingUp className="w-6 h-6" />;
    if (recommendation === "SHORT") return <TrendingDown className="w-6 h-6" />;
    return <Minus className="w-6 h-6" />;
  };

  // Formatar número com ponto como separador de milhares
  const formatNumber = (num: number): string => {
    return num.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  };

  // Formatar timestamp para hora local
  const formatTimestamp = (ts: number | undefined): string => {
    if (!ts) return "Aguardando...";
    const date = new Date(ts);
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  };

  if (isLoading) {
    return (
      <Card className="p-6 bg-slate-800/50 border-slate-700">
        <div className="flex items-center gap-3 mb-4">
          <Brain className="w-6 h-6 text-cyan-400 animate-pulse" />
          <h3 className="text-lg font-semibold text-white">AI Trading Assistant</h3>
        </div>
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mx-auto"></div>
          <p className="text-gray-400 mt-4">Analisando 20+ indicadores...</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 bg-slate-800/50 border-slate-700">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Brain className="w-6 h-6 text-cyan-400" />
          <h3 className="text-lg font-semibold text-white">AI Trading Assistant</h3>
        </div>
        <div className="text-xs text-gray-400">
          🕒 Última análise: {formatTimestamp(timestamp)}
        </div>
      </div>

      {/* Recomendação Principal */}
      <div className={`p-4 rounded-lg border mb-4 ${getRecommendationBg()}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={getRecommendationColor()}>
              {getRecommendationIcon()}
            </div>
            <div>
              <p className="text-sm text-gray-400">Recomendação</p>
              <p className={`text-2xl font-bold ${getRecommendationColor()}`}>
                {recommendation}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Confiança</p>
            <p className="text-2xl font-bold text-white">{confidence}%</p>
          </div>
        </div>
      </div>

      {/* Levels */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-blue-500/10 border border-blue-500/30 p-3 rounded">
          <p className="text-xs text-gray-400 mb-1">Entry</p>
          <p className="text-sm font-semibold text-blue-300">{formatNumber(entry)}</p>
        </div>
        <div className="bg-red-500/10 border border-red-500/30 p-3 rounded">
          <p className="text-xs text-gray-400 mb-1">Stop Loss</p>
          <p className="text-sm font-semibold text-red-300">{formatNumber(stopLoss)}</p>
        </div>
        <div className="bg-green-500/10 border border-green-500/30 p-3 rounded">
          <p className="text-xs text-gray-400 mb-1">Take Profit</p>
          <p className="text-sm font-semibold text-green-300">{formatNumber(takeProfit)}</p>
        </div>
      </div>

      {/* Contexto */}
      <div className="bg-slate-700/30 p-3 rounded">
        <p className="text-xs text-gray-400 mb-1">Contexto</p>
        <p className="text-sm text-gray-300">{context}</p>
      </div>
    </Card>
  );
}
