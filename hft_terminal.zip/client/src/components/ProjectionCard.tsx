interface ProjectionCardProps {
  type: "upper" | "center" | "lower";
  value: number;
  currentPrice: number;
  trend?: "bullish" | "bearish";
}

export function ProjectionCard({ type, value, currentPrice, trend }: ProjectionCardProps) {
  const distance = value - currentPrice;
  const distanceStr = (distance > 0 ? "+" : "") + formatNumber(distance) + " pts";

  if (type === "upper") {
    return (
      <div className="bg-gradient-to-br from-[#0AFF7C]/20 to-[#00E5FF]/20 border-2 border-[#0AFF7C] rounded-lg p-6">
        <div className="text-[#0AFF7C] text-sm mb-2 font-bold">📈 BANDA SUPERIOR (95%)</div>
        <div className="text-4xl font-bold font-mono text-[#0AFF7C] mb-2">
          {formatNumber(value)}
        </div>
        <div className="text-xs text-[#7F8DA3]">{distanceStr}</div>
      </div>
    );
  }

  if (type === "center") {
    const isBullish = trend === "bullish";
    return (
      <div
        className={`bg-gradient-to-br ${
          isBullish ? "from-[#0AFF7C]/20 to-[#00E5FF]/20" : "from-[#FF3B5C]/20 to-[#FF8C42]/20"
        } border-2 ${isBullish ? "border-[#0AFF7C]" : "border-[#FF3B5C]"} rounded-lg p-6`}
      >
        <div className="flex items-center gap-2 mb-2">
          <span className="text-3xl">{isBullish ? "🐂" : "🐻"}</span>
          <span className={`${isBullish ? "text-[#0AFF7C]" : "text-[#FF3B5C]"} text-sm font-bold`}>
            TENDÊNCIA {isBullish ? "BULLISH" : "BEARISH"}
          </span>
        </div>
        <div
          className={`text-4xl font-bold font-mono ${
            isBullish ? "text-[#0AFF7C]" : "text-[#FF3B5C]"
          } mb-2`}
        >
          {formatNumber(value)}
        </div>
        <div className="text-xs text-[#7F8DA3]">Projeção: {distanceStr}</div>
      </div>
    );
  }

  // type === "lower"
  return (
    <div className="bg-gradient-to-br from-[#FF3B5C]/20 to-[#A966FF]/20 border-2 border-[#FF3B5C] rounded-lg p-6">
      <div className="text-[#FF3B5C] text-sm mb-2 font-bold">📉 BANDA INFERIOR (95%)</div>
      <div className="text-4xl font-bold font-mono text-[#FF3B5C] mb-2">
        {formatNumber(value)}
      </div>
      <div className="text-xs text-[#7F8DA3]">{distanceStr}</div>
    </div>
  );
}

// Helper: format number with thousand separator (ponto)
function formatNumber(num: number | undefined): string {
  if (num === undefined || num === null || isNaN(num)) return "0";
  return num.toFixed(0).replace(/(\d)(?=(\d{3})+$)/g, '$1.');
}
