import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { MarketDataProvider } from "./contexts/MarketDataContext";
import DashboardLayout from "./components/DashboardLayout";
import Dashboard from "./pages/Dashboard";
import Analytics from "./pages/Analytics";
import Strategies from "./pages/Strategies";
import Risk from "./pages/Risk";
import Settings from "./pages/Settings";
import Backtest from "./pages/Backtest";
import RobotRanking from "./pages/RobotRanking";
import EquityCurve from "./pages/EquityCurve";
import Report from "./pages/Report";

import Login from "./pages/Login";
import { useAuth } from "@/_core/hooks/useAuth";
import { LayoutDashboard, BarChart3, Zap, AlertTriangle, Settings as SettingsIcon, TrendingUp, LineChart } from "lucide-react";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/" },
  { icon: BarChart3, label: "Analytics", path: "/analytics" },
  { icon: Zap, label: "Strategies", path: "/strategies" },
  { icon: AlertTriangle, label: "Risk", path: "/risk" },
  { icon: TrendingUp, label: "Backtest", path: "/backtest" },
  { icon: LineChart, label: "Ranking", path: "/ranking" },
  { icon: BarChart3, label: "Equity", path: "/equity" },
  { icon: BarChart3, label: "Relatórios", path: "/reports" },

  { icon: SettingsIcon, label: "Settings", path: "/settings" },
];

function Router() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 mx-auto mb-4 animate-pulse"></div>
          <p className="text-slate-400">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return (
    <MarketDataProvider>
      <DashboardLayout navItems={navItems}>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/analytics" component={Analytics} />
        <Route path="/strategies" component={Strategies} />
        <Route path="/risk" component={Risk} />
        <Route path="/settings" component={Settings} />
        <Route path="/backtest" component={Backtest} />
        <Route path="/ranking" component={RobotRanking} />
       <Route path={"/equity"} component={EquityCurve} />
      <Route path={"/reports"} component={Report} />

      <Route path={"/settings"} component={Settings} />   {/* Final fallback route */}
        <Route component={NotFound} />
      </Switch>
      </DashboardLayout>
    </MarketDataProvider>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
