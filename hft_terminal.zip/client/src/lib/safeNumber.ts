/**
 * client/src/lib/safeNumber.ts
 * Monkey patch Number.prototype.toFixed() para adicionar validação automática
 * 
 * PROBLEMA:
 * - .toFixed() crasheia quando chamado em NaN, undefined, null, Infinity
 * - Mesmo com 27 correções manuais, ainda existem locais não corrigidos
 * 
 * SOLUÇÃO RADICAL:
 * - Substituir Number.prototype.toFixed() globalmente
 * - Adicionar validação automática em QUALQUER chamada .toFixed()
 * - Funciona até em bibliotecas externas!
 */

// Salvar referência original
const originalToFixed = Number.prototype.toFixed;

// Substituir com versão segura
Number.prototype.toFixed = function(this: any, fractionDigits?: number): string {
  // Se this não é um número válido, retornar string padrão
  if (typeof this !== 'number' || !isFinite(this)) {
    const decimals = fractionDigits ?? 0;
    return '0.' + '0'.repeat(decimals);
  }
  
  // Caso contrário, usar implementação original
  return originalToFixed.call(this, fractionDigits);
};

console.log('[SafeNumber] Number.prototype.toFixed() monkey patched for safety');
