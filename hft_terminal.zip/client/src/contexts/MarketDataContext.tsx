import { createContext, useContext, ReactNode } from "react";
import { useDDEData, type DDEData } from "@/hooks/useDDEData";

interface MarketDataContextType {
  data: DDEData | null;
  isLoading: boolean;
  error: string | null;
  lastUpdate: Date | null;
}

const MarketDataContext = createContext<MarketDataContextType | undefined>(undefined);

export function MarketDataProvider({ children }: { children: ReactNode }) {
  const { data, isLoading, error, lastUpdate } = useDDEData(3000);

  return (
    <MarketDataContext.Provider value={{ data, isLoading, error, lastUpdate }}>
      {children}
    </MarketDataContext.Provider>
  );
}

export function useMarketData() {
  const context = useContext(MarketDataContext);
  if (!context) {
    throw new Error("useMarketData deve ser usado dentro de MarketDataProvider");
  }
  return context;
}
