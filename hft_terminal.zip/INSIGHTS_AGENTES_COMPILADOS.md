# Insights dos Agentes - Dashboard 10/10

## 🎯 ARQUITETURA GERAL

### Layout (Agente 3 - UX/UI)
- **Grid 12 colunas, 4 zonas principais:**
  1. **WINFUT Core** (50% topo): Candles + VWAP + RSI + TR + Fluxo
  2. **Internacionais** (25% inferior esquerdo): Sparklines ultra densos
  3. **Heatmap Correlações** (25% inferior direito)
  4. **Accumulated Balance + Volatilidade** (25% inferior total)

### Paleta Institucional
- Fundo: `#0A0F1A` / `#0F1522`
- Verde alta: `#0AFF7C`
- Vermelho baixa: `#FF3B5C`
- Texto primário: `#E8ECF2`
- Texto secundário: `#7F8DA3`
- VWAP: `#00E5FF`
- RSI: `#FFCA28`
- TR: `#A966FF`

---

## 📊 MÉTRICAS PROPRIETÁRIAS (Agente 2 - Quant)

### 1. zVWAP (VWAP Normalizado)
```typescript
zVWAP_D = (Preço - VWAP_Diário) / σ_VWAP_Diário
zVWAP_M = (Preço - VWAP_Mensal) / σ_VWAP_Mensal
Rel_VWAP = zVWAP_D - zVWAP_M  // Diferencia movimentos táticos vs estruturais
```

### 2. Flow Efficiency
```typescript
Flow_Efficiency = ΔPreço / ΔAccumBalance
// Mede absorção vs mercado leve (proxy de order flow)
// > 1: Mercado leve (pouca resistência)
// < 1: Absorção forte (muita resistência)
```

### 3. TR_Ratio (Regime de Volatilidade)
```typescript
TR_Ratio = TR_Atual / TR_Médio_Horário
// < 0.7: Low vol
// 0.7-1.3: Normal vol
// > 1.3: High vol
```

### 4. Global Risk Score (GRS)
```typescript
GRS = z_score(S&P) + z_score(VIX) + z_score(DXY) + z_score(Oil) + z_score(Gold)
// > 2: Risk-on forte
// -2 a 2: Neutro
// < -2: Risk-off forte
```

### 5. Cross-Asset Pressure
```typescript
β_WIN_SPX = regressão_rolling(WIN, S&P500, janela=30min)
Spread_WIN_SPX = (WIN - β * S&P500) / σ_spread
// > 2σ: WIN muito forte vs S&P (convergência provável)
// < -2σ: WIN muito fraco vs S&P (convergência provável)
```

---

## 🎨 VISUALIZAÇÕES PROFISSIONAIS (Agente 1)

### 1. Heatmap 2D de Volatilidade/Range
- **Eixo X**: Minutos (09:00-17:00)
- **Eixo Y**: Dias (últimos 20 dias)
- **Cor**: TR/ATR (vermelho = alta vol, verde = baixa vol)
- **Objetivo**: Revelar regimes, anomalias e "hot zones"

### 2. Volume Profile + VWAP + Fluxo (Pseudo-Footprint)
- **Gráfico combinado**:
  - Volume Profile (histograma horizontal por preço)
  - VWAP Diário + Mensal (linhas overlay)
  - Accumulated Balance (área colorida)
- **Objetivo**: Identificar absorção, exaustão e desequilíbrio institucional

### 3. WIN × Nasdaq × DXY Invertido (Divergências Intermercado)
- **Gráfico de linha triplo**:
  - WIN (linha cyan)
  - Nasdaq (linha verde)
  - DXY invertido (linha vermelha)
- **Destaque automático**: Divergências (WIN sobe, Nasdaq cai → sinal forte de reversão)

### 4. Market Pressure Gauge
- **Indicador visual** (gauge ou barra vertical):
  - Combina: Fluxo + VWAP deviation + Variação de preço
  - Verde: Pressão compradora forte
  - Vermelho: Pressão vendedora forte

### 5. Scatter Plot Regime
- **Eixo X**: VWAP deviation
- **Eixo Y**: True Range
- **Cor**: RSI
- **Objetivo**: Mapear compressão, explosão e tendência

### 6. Radar Intermercado (Risk-On/Risk-Off)
- **Gráfico radial** com 6 eixos:
  - DXY, VIX, Nasdaq, S&P500, Oil, Gold
- **Cor**: Verde (risk-on) vs Vermelho (risk-off)

### 7. Matriz de Correlação Rolling
- **Heatmap** com correlações 5m/30m/1h
- **Detectores de ruptura**: Destaque quando correlação muda > 0.3

### 8. VWAP Zones (Mapa Probabilístico)
- **Bandas VWAP**:
  - VWAP Diário ± 1σ, ± 2σ
  - VWAP Mensal ± 1σ, ± 2σ
- **Objetivo**: Identificar zonas de reversão e pullback

---

## 🚨 ALERTAS QUANTITATIVOS ACIONÁVEIS (Agente 2)

1. **TR_Ratio > 1.5** → Volatilidade alta (ajustar stops)
2. **|zVWAP_D| > 2** → Estresse extremo (reversão provável)
3. **Divergência Fluxo + RSI extremo** → Exaustão de compra/venda
4. **Mudança sustentada do GRS** → Troca de regime risk-on/risk-off
5. **Spread SPX-WIN > 2σ** → Convergência provável (arbitragem)

---

## 🎨 REGRAS DE UX/UI (Agente 3)

### Atualização em Tempo Real
- **Sem piscadas**: Apenas micro flashes de 50ms em eventos-chave
- **Fades suaves**: 120-300ms para atualizações
- **Cores interpoladas**: Transições graduais
- **60fps**: Smooth updates sem ruído visual

### Legibilidade
- **2 fontes máximo**: Monospace para números, Sans-serif para texto
- **2 tons**: Primário (#E8ECF2) e Secundário (#7F8DA3)
- **Fundo escuro único**: #0A0F1A
- **Destaque por brilho**: 20% de intensidade, não animação

### Interatividade
- **Tooltips**: Delay de 80ms
- **Crosshair sincronizado**: Entre todos os módulos
- **Overlays**: VWAP bands, desvio padrão, liquidez por horário
- **Replay**: Microestrutura dos últimos 15s

---

## 📐 ESTRUTURA MODULAR

### Decisão > Indicador (Agente 1)
Dashboard organizado por **tipo de decisão**, não por indicador:
1. **Estrutura**: VWAP Zones, Volume Profile
2. **Força**: Market Pressure, Flow Efficiency
3. **Confirmação**: Divergências, Correlações
4. **Risco**: TR_Ratio, GRS, Alertas

### Zonas de Decisão (Agente 3)
Cada módulo forma uma **zona de decisão independente**:
1. **WIN Core**: Microestrutura completa
2. **Mercados Globais**: Contexto macro
3. **Correlações**: Lead/lag relationships
4. **Fluxo**: Order flow e absorção
5. **Alertas**: Sinais acionáveis

---

## 🎯 PLAYBOOKS VISUAIS (Agente 1)

### Setup de Entrada/Saída
Combinar visualmente:
- VWAP (tático vs estrutural)
- RSI (momentum)
- Fluxo (absorção)
- Divergências com Nasdaq (confirmação)

### Exemplo de Playbook
```
COMPRA:
1. Preço toca VWAP_D - 1σ (suporte)
2. RSI < 30 (oversold)
3. Flow Efficiency < 0.5 (absorção forte)
4. Nasdaq diverge positivo (sobe enquanto WIN cai)
→ ENTRADA LONG

VENDA:
1. Preço toca VWAP_D + 1σ (resistência)
2. RSI > 70 (overbought)
3. Flow Efficiency > 2 (mercado leve, sem comprador)
4. Nasdaq diverge negativo (cai enquanto WIN sobe)
→ ENTRADA SHORT
```

---

## 🏆 INSPIRAÇÕES VISUAIS

- **Bloomberg**: Densidade de informação
- **Refinitiv**: Limpeza e organização
- **TradingView**: UX intuitiva
- **Bookmap**: Visualização de fluxo
- **BlackRock**: Heatmaps elegantes

---

## ✅ PRINCÍPIOS FINAIS

1. **Precisão > Beleza**
2. **Sem scroll**: Tudo em uma tela
3. **Movimentação sutil**: Pulsos leves, não piscadas
4. **Modularidade**: Cada zona é independente
5. **Acionável**: Cada visualização gera decisão
