# Análise Técnica - Feedback do Usuário

## 1. AI Trading Assistant - Erro "Erro ao gerar recomendação"

### Causa Raiz
- **Limite de API LLM excedido** (pacote gratuito)
- Código usa `invokeLLM()` que chama API Manus LLM
- Erro ocorre no catch block (linha 150 de `ai-trading-assistant.ts`)
- Usuário mencionou "final do dia" → muitas chamadas acumuladas

### Evidências
```typescript
catch (error) {
  console.error("[AI Trading Assistant] Error generating recommendation:", error);
  return {
    recommendation: "NEUTRO",
    confidence: 0,
    context: "Erro ao gerar recomendação. Aguarde próxima análise.",
    timestamp: Date.now(),
  };
}
```

### Soluções Propostas
1. ✅ **Melhorar mensagem de erro** para indicar limite excedido
2. ✅ **Implementar retry com backoff exponencial** (3 tentativas com 2s, 4s, 8s)
3. ✅ **Cache de recomendações** (evitar chamadas desnecessárias se contexto não mudou significativamente)
4. ✅ **Contador de requests** no dashboard (mostrar quantas chamadas restam)
5. ✅ **Fallback inteligente** (usar última recomendação válida ao invés de NEUTRO 0%)

---

## 2. Armazenamento de Ticks - Banco vs Memória

### Arquitetura Atual
**Ticks são salvos no BANCO DE DADOS (MySQL/TiDB)**

```typescript
// intraday-polling.ts (linha 64)
async function pollAndSave() {
  const data = await getBrazilianMarketData();
  await insertIntradayTick({
    symbol: "WINFUT",
    timestamp: Date.now(),
    price: data.winfut.last,
    volume: data.winfut.volume,
    ...
  });
}
```

### Análise de Performance

#### Prós de usar Banco
✅ **Persistência permanente** - Dados não se perdem em restart/crash
✅ **Histórico completo** - Essencial para backtesting e análise histórica
✅ **Escalável** - Suporta múltiplos símbolos e usuários
✅ **Queries complexas** - Volume Profile, Order Flow, agregações

#### Contras de usar Banco
❌ **Latência de escrita** - ~10-50ms por insert (vs <1ms em memória)
❌ **Custo de I/O** - Pressão no servidor de banco
❌ **Volume de dados** - 8.640 ticks/dia com polling de 10s (259.200 ticks/mês)

#### Prós de usar Memória (Redis/In-Memory)
✅ **Latência ultra-baixa** - <1ms para read/write
✅ **Zero I/O no banco** - Menos pressão no servidor
✅ **Ideal para real-time** - Dashboard atualiza instantaneamente

#### Contras de usar Memória
❌ **Dados voláteis** - Perda em restart (precisa backup periódico)
❌ **Limite de RAM** - Não escala infinitamente
❌ **Complexidade** - Precisa sincronizar memória → banco periodicamente

### Recomendação Final

🎯 **MANTER NO BANCO** mas com otimizações:

1. **Batch Inserts** (prioridade ALTA)
   - Acumular 10-20 ticks em memória
   - Inserir todos de uma vez a cada 2 minutos
   - Reduz I/O em 90%

2. **Índices otimizados** (prioridade MÉDIA)
   ```sql
   CREATE INDEX idx_symbol_timestamp ON intraday_ticks(symbol, timestamp DESC);
   CREATE INDEX idx_date ON intraday_ticks(date);
   ```

3. **Limpeza automática** (prioridade BAIXA)
   - Deletar ticks com >30 dias automaticamente
   - Manter apenas dados relevantes

4. **Cache em memória** (prioridade MÉDIA)
   - Últimos 1000 ticks em memória para dashboard
   - Banco apenas para histórico

### Decisão
✅ **Manter arquitetura atual** (banco de dados)
✅ **Implementar batch inserts** (quick-win)
✅ **Adicionar índices** (quick-win)
⏸️ **Cache em memória** (future enhancement)

---

## 3. Macro Cascade - Nenhum Sinal Gerado

### Problema Reportado
- Índices sendo analisados mas **nenhum sinal** gerado hoje
- Usuário questiona se lógica está correta

### Análise Necessária
1. Verificar thresholds de geração de sinais
2. Revisar fórmula de cálculo do sinal macro
3. Confirmar se VIX, DXY, S&P500 estão sendo processados corretamente
4. Validar se sinais estão sendo filtrados excessivamente

### Ação
- Investigar `macro-cascade.ts` para entender lógica de sinais
- Ajustar sensibilidade se necessário
- Reduzir tamanho visual do componente (conforme feedback)

---

## 4. Volume Profile - HVN/LVN Não Preenchidos

### Problema Reportado
- POC está sendo calculado corretamente ✅
- HVN (High Volume Nodes) e LVN (Low Volume Nodes) **não foram preenchidos**

### Causa Provável
- Dados insuficientes para calcular HVN/LVN
- Threshold muito alto para identificar nós de alto/baixo volume
- Bug na lógica de identificação de HVN/LVN

### Ação Conforme Feedback
❌ **Remover HVN e LVN completamente**
✅ **Manter apenas POC** (Point of Control)
✅ **Reduzir tamanho do card** (próximo ao Macro Cascade)

---

## 5. Dark Pool - Não Funciona

### Problema Reportado
- "Morto! Não funciona!"
- Usuário não quer investir nisso

### Ação
❌ **Remover completamente do dashboard**
- Deletar `DarkPoolCard.tsx`
- Remover lógica de backend (se houver)
- Liberar espaço no layout

---

## Próximos Passos

### Fase 1: Investigação ✅ CONCLUÍDA
- [x] Analisar erro AI Trading Assistant
- [x] Avaliar arquitetura de armazenamento de ticks
- [x] Documentar decisões técnicas

### Fase 2: Histórico de Recomendações
- [ ] Criar tabela `ai_recommendations_history`
- [ ] Salvar cada recomendação automaticamente
- [ ] Criar componente com KPIs (win rate, profit factor, etc.)

### Fase 3: Otimização de Layout
- [ ] Esconder botão Auto-Refresh
- [ ] Reduzir Macro Cascade
- [ ] Remover HVN/LVN do Volume Profile
- [ ] Remover Dark Pool completamente

### Fase 4: Mercados Internacionais INSTITUCIONAL
- [ ] Reorganizar em 4 boxes bem definidos
- [ ] Aplicar estilo Bloomberg/prop desk
- [ ] Grid harmonioso e profissional

### Fase 5: Estilo Institucional Geral
- [ ] Revisar paleta de cores (navy-dark, cyan-neon)
- [ ] Melhorar hierarquia visual
- [ ] Adicionar profundidade com sombras
- [ ] "Cara de mesa institucional"
