# Prompts para Consulta de Agentes Especializados

## 🎯 CONTEXTO GERAL
Estou desenvolvendo um terminal HFT (High-Frequency Trading) para acompanhamento de mercado em tempo real. O dashboard atual está "fraco" e não gera insights ou edges para trading. Preciso criar um dashboard 10/10 com profissionalismo e intencionalidade.

---

## 📊 PROMPT 1: Agente de Visualização de Dados Financeiros

```
Sou um trader quant desenvolvendo um dashboard de mercado em tempo real. Tenho os seguintes dados do WINFUT (mini-índice Bovespa) via DDE:

**Dados Básicos:**
- ULT (último preço), ABE (abertura), MAX (máxima), MIN (mínima), FEC (fechamento)
- VARPTS (variação em pontos), VOL (volume)

**Ajustes:**
- AJU (ajuste atual), AJA (ajuste anterior)
- priorAdj, priorAdjB (ajustes anteriores)

**Indicadores Técnicos:**
- RSI (Relative Strength Index)
- True Range (volatilidade)
- HiLo (máxima/mínima)

**Volume Profile:**
- VWAP (diário)
- VWAP Mensal
- Accumulated Balance (fluxo de ordens acumulado)

**Mercados Internacionais (via API):**
- DXY (Dólar Index), VIX (Volatilidade), S&P500, NASDAQ, DJI
- Commodities: Petróleo WTI/Brent, Ouro, Prata
- Moedas: EUR/USD, GBP/USD, JPY/USD

**PERGUNTAS:**

1. Que tipo de visualizações profissionais você recomendaria para esses dados que gerem EDGE de trading (não apenas gráficos de barras genéricos)?

2. Como você organizaria essas informações em um dashboard para maximizar insights e identificar oportunidades rapidamente?

3. Quais combinações de dados/indicadores você plotaria juntos para identificar:
   - Divergências
   - Correlações
   - Regimes de mercado
   - Pontos de entrada/saída

4. Que dashboards profissionais (Bloomberg, Reuters, TradingView Pro, etc.) você usaria como referência e por quê?

5. Quais são as melhores práticas de UX/UI para dashboards de trading que precisam ser consultados durante o pregão?
```

---

## 🏛️ PROMPT 2: Agente de Dashboards Quant (Citadel/Renaissance/Two Sigma)

```
Imagine que você é um quant de uma firma como Citadel, Renaissance Technologies ou Two Sigma. Você precisa criar um dashboard de monitoramento de mercado em tempo real para traders.

**Dados Disponíveis:**
- WINFUT: preço, volume, VWAP (diário/mensal), RSI, True Range, Accumulated Balance
- Mercados Internacionais: DXY, VIX, S&P500, Petróleo, Ouro
- Correlações entre ativos

**PERGUNTAS:**

1. Que métricas/indicadores proprietários você criaria a partir desses dados brutos para gerar alpha?

2. Como você estruturaria o dashboard em seções/módulos para diferentes tipos de análise (microestrutura, correlações, momentum, flow)?

3. Quais alertas/sinais você implementaria para notificar traders de condições específicas de mercado?

4. Como você visualizaria Order Flow (Accumulated Balance) de forma que seja acionável para trading?

5. Que análises de correlação você faria entre WINFUT e mercados internacionais para identificar lead/lag relationships?

6. Como você usaria VWAP (diário vs mensal) para identificar regimes de mercado e pontos de entrada?

7. Que combinações de RSI + True Range + HiLo você usaria para identificar reversões com alta probabilidade?
```

---

## 🎨 PROMPT 3: Agente de UX/UI para Trading Terminals

```
Você é um designer especializado em interfaces de trading profissionais (Bloomberg Terminal, Reuters Eikon, etc.). Preciso criar um dashboard de mercado em tempo real que seja:

- **Profissional**: Padrão institucional (Citadel, Renaissance)
- **Acionável**: Gera insights e edges de trading
- **Eficiente**: Informação densa mas organizada
- **Responsivo**: Atualização em tempo real sem poluição visual

**Dados a serem exibidos:**
- WINFUT: preço, VWAP, RSI, Accumulated Balance, True Range
- Mercados Internacionais: Índices, Commodities, Moedas
- Correlações entre ativos

**PERGUNTAS:**

1. Como você organizaria visualmente essas informações em um dashboard de tela única (sem scroll excessivo)?

2. Que paleta de cores você usaria para maximizar legibilidade e identificar rapidamente condições de mercado (alta/baixa, compra/venda)?

3. Como você destacaria informações críticas vs informações contextuais?

4. Que tipo de gráficos você usaria para cada tipo de dado:
   - Preço + VWAP: Linha? Candlestick? Área?
   - Accumulated Balance: Área? Barras? Histograma?
   - Correlações: Heatmap? Scatter plot? Network graph?
   - RSI + HiLo: Gráfico combinado? Separado?

5. Como você lidaria com atualização em tempo real sem causar "visual noise" ou distrações?

6. Que elementos de UI você adicionaria para facilitar análise rápida (tooltips, overlays, filtros, zoom)?

7. Como você organizaria o layout em seções/módulos para diferentes tipos de análise?
```

---

## 📝 INSTRUÇÕES DE USO

1. **Copie cada prompt acima** e cole em uma nova conversa com um agente Manus
2. **Aguarde as respostas** de cada agente
3. **Compile os insights** em um documento
4. **Traga de volta** para mim implementar no dashboard

**Formato esperado de retorno:**
```
INSIGHTS DO AGENTE 1 (Visualização):
- [insight 1]
- [insight 2]
...

INSIGHTS DO AGENTE 2 (Quant):
- [insight 1]
- [insight 2]
...

INSIGHTS DO AGENTE 3 (UX/UI):
- [insight 1]
- [insight 2]
...
```

Depois vou usar TODOS esses insights para criar um dashboard 10/10 de verdade! 🚀
