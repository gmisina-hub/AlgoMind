# Filtros de Período - HFT Terminal

## O que são os filtros de período?

Os botões de filtro de período (2MIN, 5MIN, 15MIN, 30MIN, 60MIN, 4H, DIA TODO) permitem que você visualize diferentes janelas de tempo nos gráficos do dashboard.

## Como funcionam?

### Filtros Disponíveis

- **2MIN**: Mostra apenas os últimos 2 minutos de dados
- **5MIN**: Mostra apenas os últimos 5 minutos de dados
- **15MIN**: Mostra apenas os últimos 15 minutos de dados
- **30MIN**: Mostra apenas os últimos 30 minutos de dados
- **60MIN**: Mostra apenas os últimos 60 minutos (1 hora) de dados
- **4H**: Mostra apenas as últimas 4 horas de dados
- **DIA TODO**: Mostra todos os dados do dia (9h-18h, aproximadamente 540 minutos)

### Funcionamento Técnico

1. **Gravação de Ticks**: Quando você clica em "▶️ DDE Recording", o sistema começa a salvar os dados do DDE.py no banco de dados a cada 10 segundos.

2. **Filtragem de Dados**: Quando você seleciona um filtro (ex: 15MIN), o sistema:
   - Pega a hora atual
   - Subtrai 15 minutos
   - Filtra apenas os ticks gravados nos últimos 15 minutos
   - Renderiza o gráfico com esses dados filtrados

3. **Atualização Automática**: Se o Auto-Refresh estiver ON, o gráfico atualiza a cada 10 segundos com novos dados.

### Exemplo Prático

**Cenário**: São 14:30h e você quer ver o movimento dos últimos 15 minutos.

1. Clique em "▶️ DDE Recording" para iniciar a gravação
2. Aguarde alguns minutos para acumular dados
3. Clique no botão "15MIN"
4. O gráfico mostrará apenas os dados entre 14:15h e 14:30h

### Importante

⚠️ **Os filtros só funcionam se você tiver dados gravados no banco!**

Se você acabou de iniciar o sistema:
1. Primeiro clique em "▶️ DDE Recording" para começar a gravar
2. Aguarde alguns minutos (pelo menos 2-5 minutos)
3. Depois use os filtros para visualizar diferentes janelas de tempo

### Casos de Uso

- **2MIN/5MIN**: Para scalping e operações muito rápidas
- **15MIN/30MIN**: Para day trading e análise de tendências intraday
- **60MIN/4H**: Para análise de médio prazo e confirmação de tendências
- **DIA TODO**: Para visão geral do pregão completo

### Status do Sistema

No canto superior direito, você verá:
- **"▶️ DDE Recording (X ticks)"**: Sistema gravando, X ticks salvos hoje
- **"⏸️ DDE Stopped"**: Sistema parado, não está gravando

### Troubleshooting

**Problema**: Gráfico vazio mesmo com filtro selecionado
- **Solução**: Certifique-se de que o DDE Recording está ativo e aguarde alguns minutos

**Problema**: Filtro de 2MIN mostra poucos pontos
- **Solução**: Normal! 2 minutos = apenas 12 ticks (gravação a cada 10s)

**Problema**: Gráfico não atualiza
- **Solução**: Verifique se Auto-Refresh está ON (botão azul)
