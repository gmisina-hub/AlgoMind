# Reorganização Harmoniosa dos Blocos - Dashboard HFT

## Estrutura Atual
1. KPIs (6 cards)
2. Resumo Financeiro Detalhado
3. Curva de Equity + Resumo por Subconta + Ações Estratégicas
4. Ranking de Robôs + Mapa de Risco
5. Métricas de Performance por Robô
6. Heatmaps (Horário + Dia da Semana)

## Nova Estrutura Proposta (Agrupada por Temas)

### SEÇÃO 1: VISÃO GERAL - KPIs Principais
- 6 KPI cards (P&L, Bruto, Custos, WinRate, Payoff, Max DD)

### SEÇÃO 2: ANÁLISE TEMPORAL (lado a lado)
- **Esquerda**: Curva de Equity & Resultado Diário
- **Direita**: Resumo por Subconta + Ações Estratégicas

### SEÇÃO 3: ANÁLISE DE PERFORMANCE (lado a lado)
- **Esquerda**: Resumo Financeiro Detalhado (Período Manhã/Tarde, Maior Op Vencedora/Perdedora, etc)
- **Direita**: Métricas de Performance por Robô (tabela com % Vencedoras, Payoff, etc)

### SEÇÃO 4: HEATMAPS - PADRÕES TEMPORAIS (lado a lado)
- **Esquerda**: Heatmap Robô × Horário
- **Direita**: Heatmap Robô × Dia da Semana

### SEÇÃO 5: RANKING E RISCO (lado a lado)
- **Esquerda**: Ranking de Robôs
- **Direita**: Mapa de Risco

## Benefícios
- Temas relacionados ficam próximos
- Análise temporal agrupada (equity + heatmaps)
- Performance e métricas juntas
- Risco e ranking lado a lado para comparação
- Fluxo lógico: Visão Geral → Temporal → Performance → Padrões → Risco
